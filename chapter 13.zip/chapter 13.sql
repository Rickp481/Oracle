/****************************************************************************************************************/
/*														*/
/*	Chapter 13.SQL												*/
/*	Rick Phillips												*/
/*	9/22/2021												*/
/*														*/
/****************************************************************************************************************/

-- scope refers to that section of a program over which a variable is defined

-- an example of a single procedure and the scope of variables being that entire procedure
create or replace NONEDITIONABLE procedure scope_example_1 as
    
    type person is record
    (
        person_id       number(9,0),
        first_name      varchar(50),
        last_name       varchar(50),
        date_of_birth   date,  
        gender          char(1)
    );
    my_person   person;

begin

    -- the scope of the my_person data type is this entire routine
    my_person.person_id := 1;
    my_person.first_name := 'Rick';
    my_person.last_name := 'Phillips';
    my_person.date_of_birth := to_date('02-16-1958','MM-DD-YYYY');
    my_person.gender := 'M';

    dbms_output.put_line (
        'The my_person data type is stored in memory as ' ||
        ' ID = ' || my_person.person_id ||
        ' Name = ' || my_person.first_name || ' ' || my_person.last_name ||
        ' Age = ' || floor(months_between(sysdate, my_person.date_of_birth)/12) ||
        ' Gender = ' || my_person.gender 
        );

    -- this updates that same memory location
    my_person.person_id := my_person.person_id + 1000;

    dbms_output.put_line (
        'The my_person data type is stored in memory as ' ||
        ' ID = ' || my_person.person_id ||
        ' Name = ' || my_person.first_name || ' ' || my_person.last_name ||
        ' Age = ' || floor(months_between(sysdate, my_person.date_of_birth)/12) ||
        ' Gender = ' || my_person.gender 
        );

end;

-- this routine will not compile because we havve multiple declarations of my_person
create or replace procedure scope_example_1b as
    
    type person is record
    (
        person_id       number(9,0),
        first_name      varchar(50),
        last_name       varchar(50),
        date_of_birth   date,  
        gender          char(1)
    );
    my_person   person;
    my_person2  person;
    my_person3  person;
    my_person   person;
    
begin

    -- the scope of the my_person data type is this entire routine
    my_person.person_id := 1;
    my_person.first_name := 'Rick';
    my_person.last_name := 'Phillips';
    my_person.date_of_birth := to_date('02-16-1958','MM-DD-YYYY');
    my_person.gender := 'M';

    dbms_output.put_line (
        'The my_person data type is stored in memory as ' ||
        ' ID = ' || my_person.person_id ||
        ' Name = ' || my_person.first_name || ' ' || my_person.last_name ||
        ' Age = ' || floor(months_between(sysdate, my_person.date_of_birth)/12) ||
        ' Gender = ' || my_person.gender 
        );

    -- this updates that same memory location
    my_person.person_id := my_person.person_id + 1000;

    dbms_output.put_line (
        'The my_person data type is stored in memory as ' ||
        ' ID = ' || my_person.person_id ||
        ' Name = ' || my_person.first_name || ' ' || my_person.last_name ||
        ' Age = ' || floor(months_between(sysdate, my_person.date_of_birth)/12) ||
        ' Gender = ' || my_person.gender 
        );

end;

-- same memory locations vs null memory allocation
-- same memory locations for equal instances and null for unassigned instances
create or replace procedure scope_example_1c as
    
    type person is record
    (
        person_id       number(9,0),
        first_name      varchar(50),
        last_name       varchar(50),
        date_of_birth   date,  
        gender          char(1)
    );
    my_person   person;
    my_person2  person;
    my_person3  person;
    
begin

    -- the scope of the my_person data type is this entire routine
    my_person.person_id := 1;
    my_person.first_name := 'Rick';
    my_person.last_name := 'Phillips';
    my_person.date_of_birth := to_date('02-16-1958','MM-DD-YYYY');
    my_person.gender := 'M';

    dbms_output.put_line (
        'The my_person data type is stored in memory as ' ||
        ' ID = ' || my_person.person_id ||
        ' Name = ' || my_person.first_name || ' ' || my_person.last_name ||
        ' Age = ' || floor(months_between(sysdate, my_person.date_of_birth)/12) ||
        ' Gender = ' || my_person.gender 
        );

    -- my_person2 and my_person now point at same memory locaations
    my_person2 := my_person;

    dbms_output.put_line (
        'The my_person2 data type is stored in memory as ' ||
        ' ID = ' || my_person2.person_id ||
        ' Name = ' || my_person2.first_name || ' ' || my_person.last_name ||
        ' Age = ' || floor(months_between(sysdate, my_person2.date_of_birth)/12) ||
        ' Gender = ' || my_person2.gender 
        );

    -- my_person3 does not have a memory location so all its components are null
    dbms_output.put_line (
        'The my_person3 data type is not yet stored in memory ' ||
        ' ID = ' || my_person3.person_id ||
        ' Name = ' || my_person3.first_name || ' ' || my_person.last_name ||
        ' Age = ' || floor(months_between(sysdate, my_person3.date_of_birth)/12) ||
        ' Gender = ' || my_person3.gender 
        );
end;

-- add the complexity associated with a package
create or replace package scope_package1 as

    -- both of these procedures are exposed
    procedure       scope_example1;
    procedure       scope_example2;
    
end scope_package1;

create or replace package body scope_package1 as

    procedure scope_example1 is
    
        type person is record
        (
            person_id       number(9,0),
            first_name      varchar(50),
            last_name       varchar(50),
            date_of_birth   date,  
            gender          char(1)
        );
        my_person   person;

    begin

        -- the scope of the my_person data type is this entire routine
        my_person.person_id := 1;
        my_person.first_name := 'Rick';
        my_person.last_name := 'Phillips';
        my_person.date_of_birth := to_date('02-16-1958','MM-DD-YYYY');
        my_person.gender := 'M';

        dbms_output.put_line (
            'The my_person data type is stored in memory as ' ||
            ' ID = ' || my_person.person_id ||
            ' Name = ' || my_person.first_name || ' ' || my_person.last_name ||
            ' Age = ' || floor(months_between(sysdate, my_person.date_of_birth)/12) ||
            ' Gender = ' || my_person.gender 
            );

        -- this updates that same memory location
        my_person.person_id := my_person.person_id + 1000;

        dbms_output.put_line (
            'The my_person data type is stored in memory as ' ||
            ' ID = ' || my_person.person_id ||
            ' Name = ' || my_person.first_name || ' ' || my_person.last_name ||
            ' Age = ' || floor(months_between(sysdate, my_person.date_of_birth)/12) ||
            ' Gender = ' || my_person.gender 
            );

    end scope_example1;

    procedure scope_example2 is
    
        type person is record
        (
            person_id       number(9,0),
            first_name      varchar(50),
            last_name       varchar(50),
            date_of_birth   date,  
            gender          char(1)
        );
        my_person   person;

    begin

        -- the scope of the my_person data type is this entire routine
        my_person.person_id := 10;
        my_person.first_name := 'Mary';
        my_person.last_name := 'Phillips';
        my_person.date_of_birth := to_date('09-02-1958','MM-DD-YYYY');
        my_person.gender := 'F';

        dbms_output.put_line (
            'The my_person data type is stored in memory as ' ||
            ' ID = ' || my_person.person_id ||
            ' Name = ' || my_person.first_name || ' ' || my_person.last_name ||
            ' Age = ' || floor(months_between(sysdate, my_person.date_of_birth)/12) ||
            ' Gender = ' || my_person.gender 
            );

        -- this updates that same memory location
        my_person.person_id := my_person.person_id + 1000;

        dbms_output.put_line (
            'The my_person data type is stored in memory as ' ||
            ' ID = ' || my_person.person_id ||
            ' Name = ' || my_person.first_name || ' ' || my_person.last_name ||
            ' Age = ' || floor(months_between(sysdate, my_person.date_of_birth)/12) ||
            ' Gender = ' || my_person.gender 
            );

    end scope_example2;

end scope_package1;

-- hidden subprograms and global variables 
create or replace package scope_example2 as

        -- both of these procedures are exposed
        procedure       scope_example1;
        procedure       scope_example2;
        
end scope_example2;

create or replace package body scope_example2 as

    -- the scope of this variable is the entire package; i.e. it is a global variable
    my_variable         varchar(100) := 'package';
    
    procedure scope_example1 is
    begin
        dbms_output.put_line('my_variable = ' || my_variable);
    end scope_example1;

    procedure scope_example2 is
        
        -- the scope of this variable is the scope_example2 procedure
        -- any assignments of this variable will override the global value
        my_variable     varchar(100) := 'has a different value within the scope of the scope example2 procedure';

        -- the scope of this procedure is local to the scope_example2 procedure
        procedure   scope_example3 is
            
            my_variable     varchar(100) := 'scope is limited to scope_example3';
            
        begin
            dbms_output.put_line ('my_variable within scope_example3 procedure = ' || my_variable);
        end;

    begin
            dbms_output.put_line ('my_variable within scope_example2 procedure = ' || my_variable);
            scope_example3;
    end scope_example2;

end scope_example2;

create or replace procedure test_scope as
begin

    scope_example2.scope_example1;
    scope_example2.scope_example2;
    
end;

-- explicitly handled errors
create or replace procedure explicit_error_handler is
    my_var  integer;
    my_var2 integer := 0;
begin
    
    my_var := 10/my_var2;

    exception
        when zero_divide then
            dbms_output.put_line ('Division by zero, stop giving this routine bad data.');
            my_var := null;
            
end explicit_error_handler;

-- implicit error handler
create or replace implicit_error_handler is
    my_var  integer;
    my_var2 integer := 0;
begin
    
    if my_var2 != 0 then
        my_var := 10/my_var2;
    end if;
    
    exception
        when others then
            raise_application_error (-20001,'An error has occurred in procedure procedure_name.  Please contact DBA immediately.');
            
end error_examples;


