/****************************************************************************************/
/*											*/
/*	Chapter 20									*/
/*	Rick Phillips									*/
/*	5-31-2022									*/
/*											*/
/*	Note: all my xml files are located in c:\my_xml_files and are named like	*/
/*	      student_activity_dd_mm_yyyy_vX where dd_mm_yyyy is a date and X is	*/
/*	      an incrementing integer starting with zero				*/
/****************************************************************************************/

-- as online_training_testing
-- this table is where we will put the names of all the files out there waiting for us to parse
create table temp_xml_files
    (file_name      varchar(200));
commit;

-- now as SYS we are going to create a procedure which Oracle would have you believe cannot exist
create or replace procedure get_new_files as

    ns              varchar(1024);
    my_directory    varchar(1024) := 'c:\my_xml_files';
    
begin

    -- start by clearing out all old file names from online_training_testing.temp_xml_files
    delete from online_training_testing.temp_xml_files;
    
    -- this next function is apparently top secret so of course everyone on the internet knows about it
    -- it reads the contents of my_directory into an X-table called X$FRBMSFT (Psst - don't tell anybody)
    sys.dbms_backup_restore.searchfiles (my_directory, ns);
    
    -- move the filenames from our local X-table to online_training_testing.temp_xml_files
    for each_file in
        (select     fname_krbmsft as name
        from        X$KRBMSFT) loop

        insert into online_training_testing.temp_xml_files
            (file_name)
        values
            (each_file.name);  -- our each_file collection has a name element

    end loop;

    commit;
    
    exception
        when others then
            raise_application_error (-20001, sqlcode || ' ' || sqlerrm);
end;

grant execute on get_new_files to online_training_testing;
commit;

-- now back as online_training_testing using our thick client
create or replace package online_training_xml as

    function    get_next_filename
                (filename_base  in  varchar)
                return          varchar;
                
end online_training_xml;

create or replace package body online_training_xml as

    -- this guy gets next available version number for an input filename
    function    get_next_filename
                (filename_base  in  varchar)
                return          varchar
                as

        this_date           varchar(20);
        my_filename         varchar(50);
        filename_counter    integer;

        begin
    
            -- get today's date in dd_mm_yyyy format
            select to_char(sysdate,'dd_mm_yyyy') into this_date from dual;
            
            -- start building new filename
            my_filename := filename_base || '_' || this_date || '_v';
            
            -- run the sys.get_new_files routine which will populate the temp_xml_files table
            -- remember this routine is top secret so don't tell anybody 
            sys.get_new_files;

            -- get the version number
            select  count(*) + 1 into filename_counter
            from    temp_xml_files
            where   file_name like '%' || my_filename || '%';
            
            -- finish our filename creation
            my_filename := my_filename || to_char(filename_counter) || '.xml';

            return my_filename;
        end get_next_filename;        

end online_training_xml;

-- AS SYS!!
-- as sys we need to create a directory object and grant public
create or replace directory utl_dir as 'c:\my_xml_files';
grant read, write on directory utl_dir to public;
commit;

-- now we write a generalized file write routine
create or replace package online_training_xml as

    function    get_next_filename
                (filename_base  in  varchar)
                return          varchar;
                
    procedure   write_xml_file
                (output_xml     in      clob,
                 filename       in      varchar);

end online_training_xml;

create or replace package body online_training_xml as

    -- this guy gets next available version number for an input filename
    function    get_next_filename
                (filename_base  in  varchar)
                return          varchar
                as

        this_date           varchar(20);
        my_filename         varchar(50);
        filename_counter    integer;

        begin

            -- get today's date in dd_mm_yyyy format
            select to_char(sysdate,'dd_mm_yyyy') into this_date from dual;

            -- start building new filename
            my_filename := filename_base || '_' || this_date || '_v';

            -- run the sys.get_new_files routine which will populate the temp_xml_files table
            -- remember this routine is top secret so don't tell anybody 
            sys.get_new_files;

            -- get the version number
            select  count(*) + 1 into filename_counter
            from    temp_xml_files
            where   file_name like '%' || my_filename || '%';

            -- finish our filename creation
            my_filename := my_filename || to_char(filename_counter) || '.xml';

            return my_filename;
        end get_next_filename;        
        
        -- this guy writes a clob to an external file
        procedure   write_xml_file
            (output_xml     in      clob,
             filename       in      varchar)
             as

            fhandle         utl_file.file_type;
            
        begin

            -- open a new output file in specific xml directory object
            -- remember that directory objects are quoted and upper case
            fhandle := utl_file.fopen ('UTL_DIR', filename, 'w');   

            -- stick the xmltype in the file
            utl_file.put (fhandle, output_xml);
            
            -- close the file
            utl_file.fclose (fhandle);

        end write_xml_file;

end online_training_xml;

create or replace NONEDITIONABLE procedure test_v1 as

    my_test     clob := 'Mary had a little lamb, its fleece was white as snow';

begin

        online_training_xml.write_xml_file (my_test,'write_file_test');

end;

-- need some data for the next routine
insert into person_course_roles
    (person_id, course_id, role, action_type, action_type_date)
values
    (1, 1, 'Instructor', 'Teach', sysdate);
    
insert into person_course_roles
    (person_id, course_id, role, action_type, action_type_date)
values
    (1, 2, 'Instructor', 'Teach', sysdate);

commit;

-- next routine is a generalized xmltype builder
create or replace NONEDITIONABLE package online_training_xml as

    function    get_next_filename
                (filename_base  in  varchar)
                return          varchar;

    procedure   write_xml_file
                (output_xml     in      clob,
                 filename       in      varchar);
                 
    procedure   build_xmltype
                (select_sql     in          varchar,
                 rowset_tag     in          varchar,
                 row_tag        in          varchar,
                 return_xml     out         clob);

end online_training_xml;
 
create or replace NONEDITIONABLE package body online_training_xml as

    -- this guy gets next available version number for an input filename
    function    get_next_filename
                (filename_base  in  varchar)
                return          varchar
                as

        this_date           varchar(20);
        my_filename         varchar(50);
        filename_counter    integer;

        begin

            -- get today's date in dd_mm_yyyy format
            select to_char(sysdate,'dd_mm_yyyy') into this_date from dual;

            -- start building new filename
            my_filename := filename_base || '_' || this_date || '_v';

            -- run the sys.get_new_files routine which will populate the temp_xml_files table
            -- remember this routine is top secret so don't tell anybody 
            sys.get_new_files;

            -- get the version number
            select  count(*) + 1 into filename_counter
            from    temp_xml_files
            where   file_name like '%' || my_filename || '%';

            -- finish our filename creation
            my_filename := my_filename || to_char(filename_counter) || '.xml';

            return my_filename;
        end get_next_filename;        

        -- this guy writes a clob to an external file
        procedure   write_xml_file
            (output_xml     in      clob,
             filename       in      varchar)
             as

            fhandle         utl_file.file_type;

        begin

            -- open a new output file in specific xml directory object
            -- remember that directory objects are quoted and upper case
            fhandle := utl_file.fopen ('UTL_DIR', filename, 'w');   

            -- stick the xmltype in the file
            utl_file.put (fhandle, output_xml);

            -- close the file
            utl_file.fclose (fhandle);

        end write_xml_file;

        procedure   build_xmltype
            (select_sql     in          varchar,
             rowset_tag     in          varchar,
             row_tag        in          varchar,
             return_xml     out         clob)
             as

            QueryContext        dbms_xmlgen.ctxhandle;

        begin
        
            -- create a new context handle from select statement input to procedure
            QueryContext := dbms_xmlgen.newcontext(select_sql);
            
            -- set the row and rowset tags
            dbms_xmlgen.setrowsettag (QueryContext, rowset_tag);
            dbms_xmlgen.setrowtag (QueryContext, row_tag);
            
             -- retrieve the actual xml content
            return_xml := dbms_xmlgen.getxml(QueryContext);

           -- close up the context handle
            dbms_xmlgen.closecontext (QueryContext);

        end build_xmltype;

end online_training_xml;

-- my test routine for the above iteration of code
create or replace procedure test_v1 as

    my_sql  varchar(1000) :=    
        'select  a.course_id, a.title as course_title, b.title as textbook_title, d.last_name ' ||
        'from    courses a, textbooks b, person_course_roles c, persons d ' ||
        'where   a.textbook_id = b.textbook_id ' ||
        'and     a.course_id = c.course_id ' ||
        'and     c.person_id = d.person_id ' ||
        'and     c.role = ''Instructor'' ' ||
        'order by a.title';

    my_xml  clob;    

begin

    online_training_xml.build_xmltype (my_sql,'courses','course',my_xml);

    dbms_output.put_line (my_xml);

end;

-- integrate the above test case into our package as create_available_courses
create or replace package online_training_xml as

    function    get_next_filename
                (filename_base  in  varchar)
                return          varchar;

    procedure   write_xml_file
                (output_xml     in      clob,
                 filename       in      varchar);
                 
    procedure   build_xmltype
                (select_sql     in          varchar,
                 rowset_tag     in          varchar,
                 row_tag        in          varchar,
                 return_xml     out         clob);

    procedure create_available_courses;

end online_training_xml;

create or replace NONEDITIONABLE package body online_training_xml as

    -- this guy gets next available version number for an input filename
    function    get_next_filename
                (filename_base  in  varchar)
                return          varchar
                as

        this_date           varchar(20);
        my_filename         varchar(50);
        filename_counter    integer;

        begin

            -- get today's date in dd_mm_yyyy format
            select to_char(sysdate,'dd_mm_yyyy') into this_date from dual;

            -- start building new filename
            my_filename := filename_base || '_' || this_date || '_v';

            -- run the sys.get_new_files routine which will populate the temp_xml_files table
            -- remember this routine is top secret so don't tell anybody 
            sys.get_new_files;

            -- get the version number
            select  count(*) + 1 into filename_counter
            from    temp_xml_files
            where   file_name like '%' || my_filename || '%';

            -- finish our filename creation
            my_filename := my_filename || to_char(filename_counter) || '.xml';

            return my_filename;
        end get_next_filename;        

        -- this guy writes a clob to an external file
        procedure   write_xml_file
            (output_xml     in      clob,
             filename       in      varchar)
             as

            fhandle         utl_file.file_type;

        begin

            -- open a new output file in specific xml directory object
            -- remember that directory objects are quoted and upper case
            fhandle := utl_file.fopen ('UTL_DIR', filename, 'w');   

            -- stick the xmltype in the file
            utl_file.put (fhandle, output_xml);

            -- close the file
            utl_file.fclose (fhandle);

        end write_xml_file;

        procedure   build_xmltype
            (select_sql     in          varchar,
             rowset_tag     in          varchar,
             row_tag        in          varchar,
             return_xml     out         clob)
             as

            QueryContext        dbms_xmlgen.ctxhandle;

        begin
        
            -- create a new context handle from select statement input to procedure
            QueryContext := dbms_xmlgen.newcontext(select_sql);
            
            -- set the row and rowset tags
            dbms_xmlgen.setrowsettag (QueryContext, rowset_tag);
            dbms_xmlgen.setrowtag (QueryContext, row_tag);
            
             -- retrieve the actual xml content
            return_xml := dbms_xmlgen.getxml(QueryContext);

           -- close up the context handle
            dbms_xmlgen.closecontext (QueryContext);

        end build_xmltype;

        procedure create_available_courses as
            
            my_sql  varchar(1000) :=    
                'select  a.course_id, a.title as course_title, b.title as textbook_title, d.last_name ' ||
                'from    courses a, textbooks b, person_course_roles c, persons d ' ||
                'where   a.textbook_id = b.textbook_id ' ||
                'and     a.course_id = c.course_id ' ||
                'and     c.person_id = d.person_id ' ||
                'and     c.role = ''Instructor'' ' ||
                'order by a.title';
            my_xml  clob;    
        
        begin

            build_xmltype(my_sql,'courses','course',my_xml);
            write_xml_file (my_xml, 'available_courses');
            
        end create_available_courses;

end online_training_xml;

-- my test routine for this iteration of the code
create or replace NONEDITIONABLE procedure test_v1 as

begin

    online_training_xml.create_available_courses;

end;

-- Rick does NOT approve of this method for xml files with 1:M relationships
select dbms_xmlgen.getxml ('
    select a.person_id, a.first_name, a.last_name,
        cursor
        (select     b.course_id, c.title as course_title, b.action_type_date+365 as expiration_date
         from       person_course_roles b, courses c
         where      a.person_id = b.person_id
         and        b.course_id = c.course_id
         and        b.action_type_date >= sysdate - 365
         and	    b.role = ''STUDENT''
         and	    b.action_type = ''Enroll''
         order by   b.course_id) course
    from    persons a
    order by a.person_id')
from dual;

-- this version of the select produces the exact same results
select dbms_xmlgen.getxml ('
    select a.person_id, a.first_name, a.last_name,
        cursor
        (select     b.course_id, c.title as course_title, b.action_type_date+365 as expiration_date
         from       person_course_roles b, courses c
         where      a.person_id = b.person_id
         and        b.course_id = c.course_id
         and        b.action_type_date >= sysdate - 365
         and	    b.role = ''STUDENT''
         and	    b.action_type = ''Enroll''
         group by b.course_id, c.title, b.action_type_date having count(*) > 0
         order by   b.course_id) course
    from    persons a
    order by a.person_id')
from dual;

-- go back to the style I like with nested loops
create or replace package online_training_xml as

    function    get_next_filename
                (filename_base  in  varchar)
                return          varchar;

    procedure   write_xml_file
                (output_xml     in      clob,
                 filename       in      varchar);
                 
    procedure   build_xmltype
                (select_sql     in          varchar,
                 rowset_tag     in          varchar,
                 row_tag        in          varchar,
                 return_xml     out         clob);

    procedure create_available_courses;

    procedure create_current_students;
    
end online_training_xml;

create or replace NONEDITIONABLE package body online_training_xml as

    -- this guy gets next available version number for an input filename
    function    get_next_filename
                (filename_base  in  varchar)
                return          varchar
                as

        this_date           varchar(20);
        my_filename         varchar(50);
        filename_counter    integer;

        begin

            -- get today's date in dd_mm_yyyy format
            select to_char(sysdate,'dd_mm_yyyy') into this_date from dual;

            -- start building new filename
            my_filename := filename_base || '_' || this_date || '_v';

            -- run the sys.get_new_files routine which will populate the temp_xml_files table
            -- remember this routine is top secret so don't tell anybody 
            sys.get_new_files;

            -- get the version number
            select  count(*) + 1 into filename_counter
            from    temp_xml_files
            where   file_name like '%' || my_filename || '%';

            -- finish our filename creation
            my_filename := my_filename || to_char(filename_counter) || '.xml';

            return my_filename;
        end get_next_filename;        

        -- this guy writes a clob to an external file
        procedure   write_xml_file
            (output_xml     in      clob,
             filename       in      varchar)
             as

            fhandle         utl_file.file_type;

        begin

            -- open a new output file in specific xml directory object
            -- remember that directory objects are quoted and upper case
            fhandle := utl_file.fopen ('UTL_DIR', filename, 'w');   

            -- stick the xmltype in the file
            utl_file.put (fhandle, output_xml);

            -- close the file
            utl_file.fclose (fhandle);

        end write_xml_file;

        procedure   build_xmltype
            (select_sql     in          varchar,
             rowset_tag     in          varchar,
             row_tag        in          varchar,
             return_xml     out         clob)
             as

            QueryContext        dbms_xmlgen.ctxhandle;

        begin
        
            -- create a new context handle from select statement input to procedure
            QueryContext := dbms_xmlgen.newcontext(select_sql);
            
            -- set the row and rowset tags
            dbms_xmlgen.setrowsettag (QueryContext, rowset_tag);
            dbms_xmlgen.setrowtag (QueryContext, row_tag);
            
             -- retrieve the actual xml content
            return_xml := dbms_xmlgen.getxml(QueryContext);

           -- close up the context handle
            dbms_xmlgen.closecontext (QueryContext);

        end build_xmltype;

        procedure create_available_courses as
            
            my_sql  varchar(1000) :=    
                'select  a.course_id, a.title as course_title, b.title as textbook_title, d.last_name ' ||
                'from    courses a, textbooks b, person_course_roles c, persons d ' ||
                'where   a.textbook_id = b.textbook_id ' ||
                'and     a.course_id = c.course_id ' ||
                'and     c.person_id = d.person_id ' ||
                'and     c.role = ''Instructor'' ' ||
                'order by a.title';
            my_xml  clob;    
        
        begin

            build_xmltype(my_sql,'courses','course',my_xml);
            write_xml_file (my_xml, 'available_courses');
            
        end create_available_courses;

        procedure create_current_students as

            my_string       varchar(1000);
            my_person_id    integer;
            my_course_id    integer;
            my_clob         clob;
            my_record_count integer;
            my_section_id   integer;
            my_chapter_id   integer;
            my_page_id      integer;
            my_filename     varchar(100);

            cursor c1 is
            select      distinct '<student person_id=' || chr(34) || a.person_id || chr(34) || '><first_name>' ||
                        a.first_name || '</first_name><last_name>' || a.last_name || '</last_name><courses>' as fragment, a.person_id
            from        persons a, person_course_roles b
            where       a.person_id = b.person_id
            and         b.role = 'STUDENT'
            and         b.action_type = 'Enroll'
            and         b.action_type_date+365 >= sysdate
            order by    a.person_id;

            cursor c2 (person_id_in  number) is
            select      '<course course_id=' || chr(34) || b.course_id || chr(34) || '><title>' || c.title || '</title>' ||
                        '<subscription_expires>' || to_date(b.action_type_date+365,'DD-Mon-YYYY') || '</subscription_expires>' as fragment, b.course_id
            from        persons a, person_course_roles b, courses c
            where       a.person_id = b.person_id
            and         b.course_id = c.course_id
            and         a.person_id = person_id_in
            and         b.role = 'STUDENT'
            and         b.action_type = 'Enroll'
            and         b.action_type_date+365 >= sysdate
            order by    b.course_id;
     
     begin       
            -- put out the root tag stuff
            my_clob := '<?xml version=' || chr(34) || '1.0' || chr(34) || '?>' || '<students>';

            open c1;
            loop
                fetch c1 into my_string, my_person_id;
                exit when c1%notfound;        
                my_clob := my_clob || my_string;        

                open c2 (my_person_id);
                loop
                    fetch c2 into my_string,my_course_id;
                    exit when c2%notfound;
                    my_clob := my_clob || my_string;        

                    select  count(*) into my_record_count
                    from    person_pages
                    where   person_id = my_person_id
                    and     course_id = my_course_id
                    and     end_datetime is not null;
                    
                    if my_record_count = 0 then -- they have not yet completed a single page of this course
                        my_clob := my_clob || '<last_page_viewed/></course>';
                    else  -- they have viewed pages get the ID of the most recent one
                        select  a.section_id, a.chapter_id, max(a.page_id) into my_section_id, my_chapter_id, my_page_id
                        from    person_pages a
                        where   person_id = my_person_id
                        and     course_id = my_course_id
                        and     end_datetime is not null
                        and     end_datetime =
                                (select     max(end_datetime)
                                from        person_pages b
                                where       a.person_id = b.person_id
                                and         a.course_id = b.course_id
                                and         b.end_datetime is not null)
                        group by a.section_id, a.chapter_id;

                        my_clob := my_clob || '<section_id>' || my_section_id || '</section_id>' ||
                                        '<chapter_id>' || my_chapter_id || '</chapter_id>' ||
                                        '<last_page_viewed>' || my_page_id || '</last_page_viewed></course>';
                    end if;
                    
                end loop;
                close c2;

                my_clob := my_clob || '</courses></student>'; 

            end loop;
            close c1;

            -- close up that root tag
            my_clob := my_clob || '</students>'; 

            -- write that puppy out to a file
            write_xml_file(my_clob,get_next_filename ('current_students'));

    end create_current_students;

end online_training_xml;

end online_training_xml;

create or replace NONEDITIONABLE procedure test_v1 as

begin

    online_training_xml.create_current_students;

end;

create or replace NONEDITIONABLE package online_training_xml as

    function    get_next_filename
                (filename_base  in  varchar)
                return          varchar;

    procedure   write_xml_file
                (output_xml     in      clob,
                 filename       in      varchar);
                 
    procedure   build_xmltype
                (select_sql     in          varchar,
                 rowset_tag     in          varchar,
                 row_tag        in          varchar,
                 return_xml     out         clob);

    procedure create_available_courses;

    procedure create_current_students;
    
    procedure read_learning_activity;

end online_training_xml;

create or replace NONEDITIONABLE package body online_training_xml as

    -- this guy gets next available version number for an input filename
    function    get_next_filename
                (filename_base  in  varchar)
                return          varchar
                as

        this_date           varchar(20);
        my_filename         varchar(50);
        filename_counter    integer;

        begin

            -- get today's date in dd_mm_yyyy format
            select to_char(sysdate,'dd_mm_yyyy') into this_date from dual;

            -- start building new filename
            my_filename := filename_base || '_' || this_date || '_v';

            -- run the sys.get_new_files routine which will populate the temp_xml_files table
            -- remember this routine is top secret so don't tell anybody 
            sys.get_new_files;

            -- get the version number
            select  count(*) + 1 into filename_counter
            from    temp_xml_files
            where   file_name like '%' || my_filename || '%';

            -- finish our filename creation
            my_filename := my_filename || to_char(filename_counter) || '.xml';

            return my_filename;
        end get_next_filename;        

        -- this guy writes a clob to an external file
        procedure   write_xml_file
            (output_xml     in      clob,
             filename       in      varchar)
             as

            fhandle         utl_file.file_type;

        begin

            -- open a new output file in specific xml directory object
            -- remember that directory objects are quoted and upper case
            fhandle := utl_file.fopen ('UTL_DIR', filename, 'w');   

            -- stick the xmltype in the file
            utl_file.put (fhandle, output_xml);

            -- close the file
            utl_file.fclose (fhandle);

        end write_xml_file;

        procedure   build_xmltype
            (select_sql     in          varchar,
             rowset_tag     in          varchar,
             row_tag        in          varchar,
             return_xml     out         clob)
             as

            QueryContext        dbms_xmlgen.ctxhandle;

        begin
        
            -- create a new context handle from select statement input to procedure
            QueryContext := dbms_xmlgen.newcontext(select_sql);
            
            -- set the row and rowset tags
            dbms_xmlgen.setrowsettag (QueryContext, rowset_tag);
            dbms_xmlgen.setrowtag (QueryContext, row_tag);
            
             -- retrieve the actual xml content
            return_xml := dbms_xmlgen.getxml(QueryContext);

           -- close up the context handle
            dbms_xmlgen.closecontext (QueryContext);

        end build_xmltype;

        procedure create_available_courses as
            
            my_sql  varchar(1000) :=    
                'select  a.course_id, a.title as course_title, b.title as textbook_title, d.last_name ' ||
                'from    courses a, textbooks b, person_course_roles c, persons d ' ||
                'where   a.textbook_id = b.textbook_id ' ||
                'and     a.course_id = c.course_id ' ||
                'and     c.person_id = d.person_id ' ||
                'and     c.role = ''Instructor'' ' ||
                'order by a.title';
            my_xml  clob;    
        
        begin

            build_xmltype(my_sql,'courses','course',my_xml);
            write_xml_file (my_xml, 'available_courses');
            
        end create_available_courses;

        procedure create_current_students as

            my_string       varchar(1000);
            my_person_id    integer;
            my_course_id    integer;
            my_clob         clob;
            my_record_count integer;
            my_section_id   integer;
            my_chapter_id   integer;
            my_page_id      integer;
            my_filename     varchar(100);

            cursor c1 is
            select      distinct '<student person_id=' || chr(34) || a.person_id || chr(34) || '><first_name>' ||
                        a.first_name || '</first_name><last_name>' || a.last_name || '</last_name><courses>' as fragment, a.person_id
            from        persons a, person_course_roles b
            where       a.person_id = b.person_id
            and         b.role = 'STUDENT'
            and         b.action_type = 'Enroll'
            and         b.action_type_date+365 >= sysdate
            order by    a.person_id;

            cursor c2 (person_id_in  number) is
            select      '<course course_id=' || chr(34) || b.course_id || chr(34) || '><title>' || c.title || '</title>' ||
                        '<subscription_expires>' || to_date(b.action_type_date+365,'DD-Mon-YYYY') || '</subscription_expires>' as fragment, b.course_id
            from        persons a, person_course_roles b, courses c
            where       a.person_id = b.person_id
            and         b.course_id = c.course_id
            and         a.person_id = person_id_in
            and         b.role = 'STUDENT'
            and         b.action_type = 'Enroll'
            and         b.action_type_date+365 >= sysdate
            order by    b.course_id;
     
     begin       
            -- put out the root tag stuff
            my_clob := '<?xml version=' || chr(34) || '1.0' || chr(34) || '?>' || '<students>';

            open c1;
            loop
                fetch c1 into my_string, my_person_id;
                exit when c1%notfound;        
                my_clob := my_clob || my_string;        

                open c2 (my_person_id);
                loop
                    fetch c2 into my_string,my_course_id;
                    exit when c2%notfound;
                    my_clob := my_clob || my_string;        

                    select  count(*) into my_record_count
                    from    person_pages
                    where   person_id = my_person_id
                    and     course_id = my_course_id
                    and     end_datetime is not null;
                    
                    if my_record_count = 0 then -- they have not yet completed a single page of this course
                        my_clob := my_clob || '<last_page_viewed/></course>';
                    else  -- they have viewed pages get the ID of the most recent one
                        select  a.section_id, a.chapter_id, max(a.page_id) into my_section_id, my_chapter_id, my_page_id
                        from    person_pages a
                        where   person_id = my_person_id
                        and     course_id = my_course_id
                        and     end_datetime is not null
                        and     end_datetime =
                                (select     max(end_datetime)
                                from        person_pages b
                                where       a.person_id = b.person_id
                                and         a.course_id = b.course_id
                                and         b.end_datetime is not null)
                        group by a.section_id, a.chapter_id;

                        my_clob := my_clob || '<section_id>' || my_section_id || '</section_id>' ||
                                        '<chapter_id>' || my_chapter_id || '</chapter_id>' ||
                                        '<last_page_viewed>' || my_page_id || '</last_page_viewed></course>';
                    end if;
                    
                end loop;
                close c2;

                my_clob := my_clob || '</courses></student>'; 

            end loop;
            close c1;

            -- close up that root tag
            my_clob := my_clob || '</students>'; 

            -- write that puppy out to a file
            write_xml_file(my_clob,get_next_filename ('current_students'));

    end create_current_students;

    procedure read_learning_activity as

        my_today        varchar(25) := to_char(sysdate, 'DD-MM-YYYY');

        -- retrive all learning_activity files created today
        -- remember however we don't need the directory path thus the substr function
        cursor c1 is
            select  substr(file_name,17)
            from    temp_xml_files
            where   file_name like '%learning_activity%'
            and     instr(file_name,to_char(sysdate,'DD_MM_YYYY')) > 0;

        cursor c2 (my_filename_in varchar) is
            select  b.person_id
            from    xml_documents a,
                    xmltable(   'students/student'
                                passing a.xml_document
                                columns person_id integer path '@person_id') b
            where   a.document_name = my_filename_in;
    
        cursor c3 (my_filename_in varchar, my_path_in varchar) is
            select  b.course_id, b.section_id, b.chapter_id, b.page_id, b.start_datetime, b.end_datetime
            from    xml_documents a,
                    xmltable (  my_path_in 
                                passing a.xml_document
                                columns course_id integer path '@course_id',
                                        section_id integer path '@section_id',
                                        chapter_id integer path '@chapter_id',
                                        page_id integer path '@page_id',
                                        start_datetime varchar(100) path 'start_datetime',
                                        end_datetime varchar(100) path 'end_datetime') b
            where   a.document_name = my_filename_in;
    
        my_filename     varchar(100);
        my_xml          xmltype;
        my_person_id    integer;
        my_path         varchar(100);
        my_course_id    integer;
        my_section_id   integer;
        my_chapter_id   integer;
        my_page_id      integer;
        my_start_datetime   varchar(100);
        my_end_datetime     varchar(100);
    
    begin

        -- populate the temp_xml_files table with all filenames in our xml dir    
        sys.get_new_files;

        -- incase this was run previously today
        delete from xml_documents
        where  document_name in
                (select     substr(file_name,17)
                from        temp_xml_files);
            
        open c1;
        loop
            fetch c1 into my_filename;
            exit when c1%notfound;

            -- go out to that file and retrieve the xml clob into our xml_documents table
            insert into xml_documents
                (document_name, date_parsed, xml_document)
            values
                (my_filename, sysdate, xmltype(bfilename('MY_XML_FILES', my_filename), NLS_Charset_ID('AL32UTF8'))); 
        
            -- now we atart parsing that xml clob
            open c2 (my_filename);
            loop
                fetch c2 into my_person_id;
                exit when c2%notfound;
            
                my_path := 'students/student[@person_id=' || my_person_id || ']/pages/page';
                
                open c3 (my_filename, my_path);
                loop
                    fetch c3 into my_course_id, my_section_id, my_chapter_id, my_page_id, my_start_datetime, my_end_datetime;
                    exit when c3%notfound;
        
                    -- we can now store to our person_pages table
                    -- we will check for prior existence just in case routine was run previously this same day
                    insert into person_pages
                        (person_id, course_id, section_id, chapter_id, page_id, start_datetime, end_datetime)
                    select
                        my_person_id, my_course_id, my_section_id, my_chapter_id, my_page_id, to_date(my_start_datetime,'DD-MM-YYYY HH24:MI:SS'), 
                        to_date(my_end_datetime,'DD-MM-YYYY HH24:MI:SS')
                    from dual
                    where   not exists
                            (select 1
                             from   person_pages
                             where  person_id = my_person_id
                             and    course_id = my_course_id
                             and    section_id = my_section_id
                             and    chapter_id = my_chapter_id
                             and    page_id = my_page_id);
                
                end loop;
                close c3;

            end loop;
            close c2;
        
        end loop;
        close c1;
    
        commit;

    end read_learning_activity;

end online_training_xml;

-- I tested it by just executing it because I could verify results by select * from person_pages
