/********************************************************************************/
/*										*/
/*	Rick Phillips								*/
/*	Chapter 8	 							*/
/*	3-26-2021								*/
/*										*/
/********************************************************************************/

-- operators
create or replace procedure plsql_operators as

    string1             varchar2(50) := 'Hello';
    string2             varchar2(50) := 'World';
    int1                number(9,0) := 10;
    real1               number(9,2) := 5.25;
    real2               number(9,2);
    comparison_result   boolean;

begin

    dbms_output.put_line ('the mathematical operators');
    real2 := int1 + real1;  -- note assignment operator
    dbms_output.put_line('addition operator is + ' || real2);
    real2 := int1 - real1;
    dbms_output.Put_line('subtraction operator is - ' || real2);
    real2 := int1 * real1;
    dbms_output.Put_line('multiplication operator is * ' || real2);
    real2 := int1 / real1;
    dbms_output.Put_line('division operator is / ' || real2);
    real2 := int1 ** real1;
    dbms_output.Put_line('exponent operator is ** ' || real2);

    -- relational operators
    dbms_output.put_line (' ');
    dbms_output.put_line ('the relational operators');
    real2 := real1;
    -- equality test
    if (real1 = real2) then
        dbms_output.put_line ('real1 (5.25) = real2 (5.25) resolves to true');
    else
        dbms_output.put_line ('real1 (5.25) = real2 (5.25) resolves to false');
    end if;
    real2 := 10;
    -- two forms of inequality test
    if (real1 != real2) then
        dbms_output.put_line ('real1 (5.25) != real2 (10) resolves to true');
    else
        dbms_output.put_line ('real1 (5.25) != real2 (10) resolves to false');
    end if;
    if (real1 <> real2) then
        dbms_output.put_line ('real1 (5.25) <> real2 (10) resolves to true');
    else
        dbms_output.put_line ('real1 (5.25) <> real2 (10) resolves to false');
    end if;
    -- greater than and greater than or equal
    if (real1 > real2) then
        dbms_output.put_line ('real1 (5.25) > real2 (10) resolves to true');
    else
        dbms_output.put_line ('real1 (5.25) > real2 (10) resolves to false');
    end if;
    if (real1 >= real2) then
        dbms_output.put_line ('real1 (5.25) >= real2 (10) resolves to true');
    else
        dbms_output.put_line ('real1 (5.25) >= real2 (10) resolves to false');
    end if;
    -- less than and less than or equal
    if (real1 < real2) then
        dbms_output.put_line ('real1 (5.25) < real2 (10) resolves to true');
    else
        dbms_output.put_line ('real1 (5.25) < real2 (10) resolves to false');
    end if;
    if (real1 <= real2) then
        dbms_output.put_line ('real1 (5.25) <= real2 (10) resolves to true');
    else
        dbms_output.put_line ('real1 (5.25) <= real2 (10) resolves to false');
    end if;

-- comparison operators
if (string1 like 'He%') then
    dbms_output.put_line ('string1 (Hello) like ''He%'') resolves to true');
else
    dbms_output.put_line ('string1 (Hello) like ''He%'') resolves to false');
end if;

if (real1 between 0 and 100) then
    dbms_output.put_line ('real1 (5.25) between 0 and 100 resolves to true');
else
    dbms_output.put_line ('real1 (5.25) between 0 and 100 resolves to false');
end if;

if (real1 in (5, 5.25, 10)) then
    dbms_output.put_line ('real1 (5.25) in (5, 5.25, 10) resolves to true');
else
    dbms_output.put_line ('real1 (5.25) in (5, 5.25, 10) resolves to false');
end if;

if (real1 is null) then
    dbms_output.put_line ('real1 (5.25) is null resolves to true');
else
    dbms_output.put_line ('real1 (5.25) is null resolves to false');
end if;

-- 2 state logical operators
if ( 1 = 1 and 1 < 2) then
    dbms_output.put_line ('For an AND to be true both sides of the condition must resolve to true');
end if;

if (1 = 1 or 1 > 2) then
    dbms_output.put_line ('For an OR to be true either side, or both sides, of the condition must resolve to true');
end if;

if (not (1=1)) then
    dbms_output.put_line ('The NOT operator reverses the boolean result of a conditional');
end if;

end;

-- now dates
create or replace procedure date_formats as

    my_date1        date := to_date('01-01-1970','MM-DD-YYYY');
    my_date2        date := to_date('01-01-2070','MM-DD-YYYY');
    my_date3        date := to_date('01-Jan-1970','DD-MON-YYYY');
    my_date4        date := to_date('01-01-70','MM-DD-RR');
    my_date5        date := to_date('01-01-70','MM-DD-YY');
    
begin

    dbms_output.put_line('Today is ' || sysdate);   -- Oracle's default date format is pretty useless
    dbms_output.put_line('Today is ' || to_char(sysdate,'DD-MON-YYYY')); -- so always force a 4 digit year
    dbms_output.put_line ('Days between my_date1 (01-01-1970) and my_date3 (01-Jan-1970) ' || to_char(my_date1 - my_date3));
    dbms_output.put_line ('Days between my_date1 (01-01-1970) and my_date4 (01-01-70 via RR) ' || to_char(my_date1 - my_date4));
    dbms_output.put_line ('Days between my_date1 (01-01-1970) and my_date5 (01-01-70 via YY)' || to_char(my_date1 - my_date5));
    
    alter session set NLS_DATE_LANGUAGE = 'FRENCH';
    dbms_output.put_line('Today is ' || to_char(sysdate,'DD-MON-YYYY')); -- french month 

end;

-- to change the date language
alter session set nls_date_language = 'SPANISH';

-- string datatypes
create or replace procedure show_variable_length as

    my_char         char(50) := 'Hello';
    my_varchar      varchar(25) := 'World';
    my_varchar2     varchar2(25) := 'World';
    my_null         varchar2(25);
    my_null_test    varchar2(25);

begin

    dbms_output.put_line (my_char || ' ' || my_varchar);
    dbms_output.put_line (my_char || ' ' || my_varchar2);

    dbms_output.put_line ('Length of my_char = ' || length(my_char));
    dbms_output.put_line ('Length of my_varchar = ' || length(my_varchar));
    dbms_output.put_line ('Length of my_varchar2 = ' || length(my_varchar2));

    my_char := ' ';
    my_varchar := ' ';
    my_varchar2 := ' ';

    dbms_output.put_line ('Length of my_char = ' || length(my_char));
    dbms_output.put_line ('Length of my_varchar = ' || length(my_varchar));
    dbms_output.put_line ('Length of my_varchar2 = ' || length(my_varchar2));

    my_char := '';
    my_varchar := '';
    my_varchar2 := '';

    dbms_output.put_line ('Length of my_char = ' || length(my_char));
    dbms_output.put_line ('Length of my_varchar = ' || length(my_varchar));
    dbms_output.put_line ('Length of my_varchar2 = ' || length(my_varchar2));

	select nvl(my_null,'is Null') into my_null_test from dual;
	dbms_output.put_line ('my_null which was never assigned ' || my_null_test);

  	select nvl(my_varchar,'Is Null') into my_null_test from dual;
  	dbms_output.put_line ('Zero length string in varchar ' || my_null_test);

  	select nvl(my_varchar2,'Is Null') into my_null_test from dual;
  	dbms_output.put_line ('Zero length string in varchar2 ' || my_null_test);

  	my_char := null;
	my_varchar := null;
	my_varchar2 := null;

	dbms_output.put_line ('Length of my_char = ' || length(my_char));
	dbms_output.put_line ('Length of my_varchar = ' || length(my_varchar));
	dbms_output.put_line ('Length of my_varchar2 = ' || length(my_varchar2));   
end;

-- boolean datatype
create or replace NONEDITIONABLE procedure show_boolean_logic as

	my_boolean1	boolean;
	my_boolean2	boolean := true;
	my_boolean3	boolean := false;

begin

	case
		when my_boolean1 then
			dbms_output.put_line ('My_Boolean1 is true');
		when my_boolean2 then
			dbms_output.put_line ('My_Boolean2 is true');
		when my_boolean3 then
			dbms_output.put_line ('My_Boolean3 is true');
	end case;

    -- three state logical operators   
	if nvl(my_boolean1 and my_boolean2,True) then
		dbms_output.put_line ('my_boolean1 (null) and my_boolean2 (true) is null');
	end if;

	if my_boolean1 or my_boolean2 then
		dbms_output.put_line ('my_boolean1 (null) or my_boolean2 (true) is true');
	end if;

	if not(my_boolean1 and my_boolean3) then
		dbms_output.put_line ('my_boolean1 (null) and my_boolean3 (false) is false');
	end if;

	if nvl(my_boolean1 or my_boolean3,true) then
		dbms_output.put_line ('my_boolean1 (null) or my_boolean3 (false) is null');
	end if;

end;

-- nulls are hard
create or replace procedure null_is_not_dull as

    string1             varchar2(50);   -- initialize to null
    string2             varchar2(50) := 'World';
    real1               number(9,2);    -- initialize to null
    real2               number(9.2) := 5.25;
    bool1               boolean;        -- initialize to null
    bool2               boolean := true;
    bool3               boolean := false;
    
begin

    -- null string treated as zero length string
    dbms_output.put_line (string1 || ' ' || string2);

    -- null with arithmetic operators
    dbms_output.put_line ('real1 (null) + real2 (5.25) = ' || nvl(to_char(real1 + real2),'null'));
    dbms_output.put_line ('real1 (null) - real2 (5.25) = ' || nvl(to_char(real1 - real2),'null'));
    dbms_output.put_line ('real1 (null) * real2 (5.25) = ' || nvl(to_char(real1 * real2),'null'));
    dbms_output.put_line ('real1 (null) / real2 (5.25) = ' || nvl(to_char(real1 / real2),'null'));
    dbms_output.put_line ('real1 (null) ** real2 (5.25) = ' || nvl(to_char(real1 ** real2),'null'));

    -- relational and comparison operators 
    if (real1 is not null and real2 is not null) then
        dbms_output.put_line ('can only do relational and comparison operations on not null values');
        dbms_output.put_line ('the only one which works is null test');
        dbms_output.put_line ('the bad news is they compile');
    elsif ((real1 is null and real2 is not null) or
             (real2 is not null and real2 is null) or
             (real1 is null and real2 is null)) then
        dbms_output.put_line ('relational operator tests on null resolve to null');
        dbms_output.put_line ('the only one which works is null test');
        dbms_output.put_line ('the bad news is they compile');
    end if;
    
    -- logical operations 
    if (bool1 and bool2) then
        dbms_output.put_line ('bool1 (null) and bool2 (true) is true');
    elsif not(bool1 and bool2) then
        dbms_output.put_line ('bool1 (null) and bool2 (true) is false');
    else
        dbms_output.put_line ('bool1 (null) and bool2 (true) is null');
    end if;
    if (bool1 and bool3) then
        dbms_output.put_line ('bool1 (null) and bool3 (false) is true');
    elsif not(bool1 and bool3) then
        dbms_output.put_line ('bool1 (null) and bool3 (false) is false');
    else
        dbms_output.put_line ('bool1 (null) and bool3 (false) is null');
    end if;
    
    if (bool1 or bool2) then
        dbms_output.put_line ('bool1 (null) or bool2 (true) is true');
    elsif not(bool1 or bool2) then
        dbms_output.put_line ('bool1 (null) or bool2 (true) is false');
    else
        dbms_output.put_line ('bool1 (null) or bool2 (true) is null');
    end if;
    if (bool1 or bool3) then
        dbms_output.put_line ('bool1 (null) or bool3 (false) is true');
    elsif not(bool1 or bool3) then
        dbms_output.put_line ('bool1 (null) or bool3 (false) is false');
    else
        dbms_output.put_line ('bool1 (null) or bool3 (false) is null');
    end if;
       
end;
