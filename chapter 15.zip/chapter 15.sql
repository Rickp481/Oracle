/****************************************************************************************/
/*											*/
/*	Chapter 15 Procedures								*/
/*	Rick Phillips									*/
/*	02/22/2022									*/
/*											*/
/****************************************************************************************/

-- super easy procedure
create or replace procedure hello_world as	-- definition syntax
	
	-- declaration block is where we define our variables and types
	my_message	varchar(200) := 'Hello World';

begin	

	-- the body is where we write our executable code
	dbms_output.put_line (my_message);

	-- be certain to handle unexpected issues
	exception
		when others then 
            	raise_application_error (-20001,'An unexpected error has occurred in procedure hello_world. ' ||
					 	'Please contact the DBA immediately.');
end;

-- add input parameters
create or replace procedure hello_world_2 	-- definition syntax
	(my_message2   in      varchar,        -- basic input parameter
     	my_message3    in      varchar default 'Message3') as  -- input parm with default value
     
	-- declaration block is where we define our variables and types
	my_message	varchar(200) := 'Hello World';

begin	

	-- the body is where we write our executable code
	dbms_output.put_line (my_message);

    	my_message := hello_world_2.my_message2;    -- dot notation optional here because varnames are unique
	dbms_output.put_line (my_message);

    	my_message := hello_world_2.my_message3;
	dbms_output.put_line (my_message);

	-- be certain to handle unexpected issues
	exception
		when others then 
            raise_application_error (-20001,'An unexpected error has occurred in procedure hello_world_2. ' ||
					 'Please contact the DBA immediately.');
end;

-- write a calling routine for our test_hellow_world2 routine
-- note the two calling methods and defaults
create or replace NONEDITIONABLE procedure test_hello_world2 as
begin
    -- two ways to pass parms are by order or explicitly
    hello_world_2('This is my_message2','This is my_message3');
    hello_world_2(my_message2 => 'This is my_message2',my_message3 =>'This is my_message3');
    hello_world_2(my_message2 => 'This is my_message2');  -- use default for my_message3 parm
end;

-- add output parameters
create or replace procedure hello_world_3 	            -- definition syntax
	(my_message2   in      varchar,                     -- basic input parameter
    	my_message3    in      varchar default 'Message3',  -- input parm with default
    	my_message4    out      varchar) as                 -- output parm
     
	-- declaration block is where we define our variables and types
	my_message	varchar(200) := 'Hello World';

begin	

	-- the body is where we write our executable code
	dbms_output.put_line (my_message);

    	my_message := hello_world_3.my_message2;    -- dot notation optional here because varnames are unique
	dbms_output.put_line (my_message);

    	my_message := hello_world_3.my_message3;
	dbms_output.put_line (my_message);

    	my_message4 := my_message3;
    
	-- be certain to handle unexpected issues
	exception
		when others then 
            raise_application_error (-20001,'An unexpected error has occurred in procedure hello_world_3. ' ||
					 'Please contact the DBA immediately.');
end;

-- write a calling routine for our test_hellow_world_3 routine
create or replace procedure test_hello_world_3 as
    my_message_out      varchar(200);
begin
    hello_world_3(my_message2 => 'This is my_message2', my_message4 => my_message_out);  -- use default for my_message3 parm
    
    dbms_output.put_line ('my_message_out = ' || my_message_out);
end;

-- next we add an in/out parm
-- add output parameters
create or replace procedure hello_world_4 
	(my_message2   in out     varchar) as   -- output parm
     
	-- declaration block is where we define our variables and types
	my_message	varchar(200) := 'Hello World';

begin	

	-- the body is where we write our executable code
	dbms_output.put_line (my_message);

   	my_message := hello_world_4.my_message2;    
	dbms_output.put_line (my_message);

    my_message2 := 'updated message';
    
	-- be certain to handle unexpected issues
	exception
		when others then 
            raise_application_error (-20001,'An unexpected error has occurred in procedure hello_world_3. ' ||
					 'Please contact the DBA immediately.');
end;

create or replace procedure test_hello_world_4 as

    my_message  varchar(200)  := 'in calling routine';

begin

    dbms_output.put_line ('value of my_message is ' || my_message);
    
        hello_world_4 (my_message); -- can not use explicit with in/out parms
        
    dbms_output.put_line ('value of my_message is ' || my_message);
    
end;

-- user-defined passed parm
create or replace package record_structure_parm as

    type person is record
    (
        person_id       number(9,0),
        first_name      varchar(50),
        last_name       varchar(50),
        date_of_birth   date,
        gender          char(1)
    );
    
    this_person person;

    procedure   calling_routine;
    procedure   called_routine(this_person in out person);
    
end record_structure_parm;

create or replace package body record_structure_parm as

    procedure calling_routine is
    begin
        this_person.person_id := 1;
        this_person.first_name := 'Rick';
        this_person.last_name := 'Phillips';
        this_person.date_of_birth := to_date('16-Feb-1958','DD-Mon-YYYY');
        this_person.gender := 'M';
        
        if (this_person.gender = 'M' and sysdate - this_person.date_of_birth > 50) then
            dbms_output.put_line ('Person ID ' || this_person.person_id || ' is an old guy');
        elsif (this_person.gender = 'M' and sysdate - this_person.date_of_birth <= 50) then
            dbms_output.put_line ('Person ID ' || this_person.person_id || ' is a young guy');
        elsif (this_person.gender = 'F' and sysdate - this_person.date_of_birth <= 50) then
            dbms_output.put_line ('Person ID ' || this_person.person_id || ' is a young woman');
        else
            dbms_output.put_line ('I have nothing to say on this topic.');
        end if;
        
        called_routine (this_person);
        
        if (this_person.gender = 'M' and sysdate - this_person.date_of_birth > 50) then
            dbms_output.put_line ('Person ID ' || this_person.person_id || ' is an old guy');
        elsif (this_person.gender = 'M' and sysdate - this_person.date_of_birth <= 50) then
            dbms_output.put_line ('Person ID ' || this_person.person_id || ' is a young guy');
        elsif (this_person.gender = 'F' and sysdate - this_person.date_of_birth <= 50) then
            dbms_output.put_line ('Person ID ' || this_person.person_id || ' is a young woman');
        else
            dbms_output.put_line ('I have nothing to say on this topic.');
        end if;

        exception
            when others then
                raise_application_error (-20001,'An unexpected error has occurred in procedure calling routine.' ||
                    'Please report this issue to the DBA immediate.');
    end calling_routine;

    procedure called_routine 
        (this_person    in out  person) is
    begin
        if (this_person.gender = 'M') then
            this_person.gender := 'F';
        else
            this_person.gender := 'M';
        end if;
        
        exception
            when others then
                raise_application_error (-20001,'An unexpected error has occurred in procedure called routine.' ||
                    'Please report this issue to the DBA immediate.');
    end called_routine;

end record_structure_parm;

-- Rick's attempt at humor
create or replace package record_structure_parm2 as

    type person is record
    (
        person_id       number(9,0),
        first_name      varchar(50),
        last_name       varchar(50),
        date_of_birth   date,
        gender          char(1)
    );
    
    this_person person;

    procedure   calling_routine;
    procedure   called_routine(this_person in out person);
    
end record_structure_parm2;


create or replace procedure test_record_structure_parm2 as
begin
    record_structure_parm.calling_routine;
end;

-- hide that gender change logic cause it is too weird for public consumption
create or replace package body record_structure_parm2 as

    procedure calling_routine is
    begin
        this_person.person_id := 1;
        this_person.first_name := 'Rick';
        this_person.last_name := 'Phillips';
        this_person.date_of_birth := to_date('16-Feb-1958','DD-Mon-YYYY');
        this_person.gender := 'M';
        
        if (this_person.gender = 'M' and sysdate - this_person.date_of_birth > 50) then
            dbms_output.put_line ('Person ID ' || this_person.person_id || ' is an old guy');
        elsif (this_person.gender = 'M' and sysdate - this_person.date_of_birth <= 50) then
            dbms_output.put_line ('Person ID ' || this_person.person_id || ' is a young guy');
        elsif (this_person.gender = 'F' and sysdate - this_person.date_of_birth <= 50) then
            dbms_output.put_line ('Person ID ' || this_person.person_id || ' is a young woman');
        else
            dbms_output.put_line ('I have nothing to say on this topic.');
        end if;
        
        called_routine (this_person);
        
        if (this_person.gender = 'M' and sysdate - this_person.date_of_birth > 50) then
            dbms_output.put_line ('Person ID ' || this_person.person_id || ' is an old guy');
        elsif (this_person.gender = 'M' and sysdate - this_person.date_of_birth <= 50) then
            dbms_output.put_line ('Person ID ' || this_person.person_id || ' is a young guy');
        elsif (this_person.gender = 'F' and sysdate - this_person.date_of_birth <= 50) then
            dbms_output.put_line ('Person ID ' || this_person.person_id || ' is a young woman');
        else
            dbms_output.put_line ('I have nothing to say on this topic.');
        end if;

        exception
            when others then
                raise_application_error (-20001,'An unexpected error has occurred in procedure calling routine.' ||
                    'Please report this issue to the DBA immediate.');
    end calling_routine;

    procedure called_routine 
        (this_person    in out  person) is

        procedure gender_change 
            (this_person in out person) is
        begin
	        if (this_person.gender = 'M') then
        	    this_person.gender := 'F';
        	else
            		this_person.gender := 'M';
	        end if;
	        
            exception
        	    when others then
                	raise_application_error (-20001,'An unexpected error has occurred in procedure gender_change.' ||
	                    'Please report this issue to the DBA immediate.');
        end gender_change;

    begin

    	gender_change (this_person);        
    
        exception
            when others then
                raise_application_error (-20001,'An unexpected error has occurred in procedure called routine.' ||
                    'Please report this issue to the DBA immediate.');
    end called_routine;

end record_structure_parm2;

create or replace procedure test_record_structure_parm2 as
begin
    record_structure_parm2.calling_routine;
end;
