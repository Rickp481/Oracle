/****************************************************************************************/
/*											*/
/*	Rick Phillips									*/
/*	Chapter 7 Advanced Queries							*/
/*	3/21/2021									*/
/*											*/
/****************************************************************************************/

-- translate and replace functions
select translate('beer bucket','beer','milk') as translate_is_char_4_char,
       replace('beer bucket','beer','milk') as replace_is_string_4_string,
from   dual;

-- decode and random numbers
select  mod(to_number(to_char(sysdate,'SSSSS')),86400) as random_number,
        decode(mod(to_number(to_char(sysdate,'SSSSS')),2),0,'True','False') as true_false 
from dual;

-- random day of week
select mod(to_number(to_char(current_date,'SSSSS')),6) as random_day_of_week,
	case mod(to_number(to_char(current_date,'SSSSS')),6)
		when 0 then 'Sunday'
		when 1 then 'Monday'
		when 2 then 'Tuesday'
		when 3 then 'Wednesday'
		when 4 then 'Thursday'
		when 5 then 'Friday'
		when 6 then 'Saturday'
		else 'Something is very wrong'
	end
from dual;

-- self join
select a.first_name || ' ' || a.last_name as manager, b.first_name || ' ' || b.last_name as subordinate
from   persons a, persons b
where  a.person_id = b.manager_id;

-- connect by and start 
select 	person_id, manager_id, first_name, last_name
from   	persons
connect by prior person_id = manager_id
start with person_id = 1;

-- add the level pseudo column 
select level, person_id, manager_id, first_name, last_name
from   persons
connect by prior person_id = manager_id
start with person_id = 1
order by level;

-- use the level to indent subordinates 
select lpad(' ',5 * level-1) || first_name || ' ' || last_name as "Employee Name"
from   persons
connect by prior person_id = manager_id
start with person_id = 1;

-- lets add some numeric data to the textbooks table so we can run some stat functions
alter table textbooks add unit_price decimal(9,2) default 0.0;

update  textbooks 
set     unit_price = 10.25 * textbook_id;

insert into textbooks
    (textbook_id, title, publisher, publication_date, author_id, unit_price)
values
    (3, 'Another Textbook','Badger Mtn', sysdate, 2, 30.75);
    
insert into textbooks
    (textbook_id, title, publisher, publication_date, author_id, unit_price)
values
    (4, 'Another Textbook 2','Badger Mtn', sysdate, 2, 100);

insert into textbooks
    (textbook_id, title, publisher, publication_date, author_id, unit_price)
values
    (5, 'Another Textbook 3','Badger Mtn', sysdate, 2, -30.75);

insert into textbooks
    (textbook_id, title, publisher, publication_date, author_id, unit_price)
values
    (6, 'Another Textbook 4','Badger Mtn Pub', sysdate, 2, -30.75);
    
insert into textbooks
    (textbook_id, title, publisher, publication_date, author_id, unit_price)
values
    (7, 'Another Textbook 5','Badger Mtn Pub', sysdate, 2, -100);

select * from textbooks;

-- some standard stat functions
select      publisher, to_char(publication_date,'DD-MM-YYYY') as "Publication Date",
            to_char(sum(unit_price),'999,999.99') as "Sum of Unit Price",
            to_char(avg(unit_price),'$99,999.99') as "Average Unit Price",
            to_char(stddev(unit_price),'$99,999.99') as "Standard Deviation Unit Price"
from        textbooks
group by    publisher, publication_date
order by    avg(unit_price);

-- having clause
select      publisher, to_char(publication_date,'DD-MM-YYYY') as "Publication Date",
            to_char(sum(unit_price),'999,999.99') as "Sum of Unit Price",
            to_char(avg(unit_price),'$99,999.99') as "Average Unit Price",
            to_char(stddev(unit_price),'$99,999.99') as "Standard Deviation Unit Price"
from        textbooks
group by    publisher, publication_date having avg(unit_price) > 0
order by    avg(unit_price);

-- rank and dense rank
select title, unit_price,
       rank() over (order by unit_price) "Ascending Rank Order"
from   textbooks;
       
select title, unit_price,
       dense_rank() over (order by unit_price desc) "Descending Dense Rank Order"
from   textbooks;
       
-- rollup
select  publisher, to_char(sum(unit_price),'$99,999.99') as "Sum of Unit Price"
from    textbooks
group by rollup (publisher);

-- cume_dist and percent_rank
select  publisher, to_char(unit_price,'$99,999.99') as "Unit Price", 
        round(cume_dist() over (order by unit_price) * 100,2) "Cumulative Distribution",
        round(percent_rank() over (order by unit_price) * 100,2) "Percent Distribution"
from    textbooks;

