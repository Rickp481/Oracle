/****************************************************************************************/
/*											*/
/*	Chapter 19									*/
/*	Rick Phillips									*/
/*	4-26-2022									*/
/*											*/
/****************************************************************************************/

-- create a new connection to online_training_testing with thick client
-- to do this go to advanced tab and enable Use OCI option (Oracle Cloud Interface)

-- as system
grant create any directory to online_training_testing;
commit;

-- now using the online_training_testing thick client connection

-- create our OS disk file system directory object 
create or replace directory MY_XML_FILES as '/my_xml_files';

-- create a table into which we can place the results of our parsed external XML file
create table xml_documents
(document_name          varchar(100)        primary key,
 date_parsed            date                default sysdate,
 xml_document           xmltype)
 xmltype xml_document store as binary xml;

 -- our first XML read
insert into xml_documents
    (document_name, date_parsed, xml_document)
values
    ('chapter_18_XML_example.xml', null,
        xmltype(bfilename('MY_XML_FILES','chapter_18_XML_example.xml'),NLS_Charset_ID('AL32UTF8')));

select extract(xml_document,'/online_training/students/student/first_name') as first_name 
from xml_documents;

select xmltype.getclobval(extract(xml_document,'/online_training/students/student/first_name')) as first_name 
from xml_documents;

select xmltype.getclobval(column_value)
from   xml_documents a,
       table(xmlsequence(extract(a.xml_document,'/online_training/students/student/first_name'))) d;

select a.document_name, a.date_parsed, b.*
from   xml_documents a,
       xmltable('online_training/students/student'
                 passing a.xml_document
                 columns first_name varchar(100) path 'first_name',
                         last_name  varchar(100) path 'last_name') b
order by a.date_parsed, a.document_name;

select a.document_name, a.date_parsed, b.*
from   xml_documents a,
       xmltable('online_training/students/student'
                 passing a.xml_document
                 columns first_name varchar(100) path 'first_name',
                         last_name  varchar(100) path 'last_name',
                         person_id integer path '@person_id') b
order by a.date_parsed, a.document_name;

select a.document_name, a.date_parsed, b.*
from   xml_documents a,
       xmltable('online_training/students/student[@person_id=3]'
                 passing a.xml_document
                 columns first_name varchar(100) path 'first_name',
                         last_name  varchar(100) path 'last_name',
                         person_id integer path '@person_id') b
order by a.date_parsed, a.document_name;

