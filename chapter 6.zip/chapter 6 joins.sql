/****************************************************************************************/
/*											*/
/*	Rick Phillips									*/
/*	Chapter 6 script joins								*/
/*	3/17/2021									*/
/*											*/
/****************************************************************************************/

-- BASE TABLES
insert into page_types (page_type) values ('HTML');
insert into page_types (page_type) values ('PDF');
insert into page_types (page_type) values ('MPG');
insert into page_types (page_type) values ('AVI');
insert into page_types (page_type) values ('WMV');
insert into page_types (page_type) values ('MOV');
insert into page_types (page_type) values ('JPG');
insert into page_types (page_type) values ('MC QUESTION');
insert into page_types (page_type) values ('MATCH QUESTION');

COMMIT;

insert into roles (role) values ('Instructor');
insert into roles (role) values ('Student');
insert into roles (role) values ('Instruc Designer');
insert into roles (role) values ('Course Lead');

commit;

-- load tables from RI root to leaf nodes
insert into persons (person_id, first_name, last_name, manager_id)
values (1,'Mary','Phillips',null);
insert into persons (person_id, first_name, last_name, manager_id)
values (2,'Rick','Phillips',1);
insert into persons (person_id, first_name, last_name, manager_id)
values (3,'Daniel','Phillips',2);
insert into persons (person_id, first_name, last_name, manager_id)
values (4,'David','Phillips',2);

commit;

-- why does the textbook table have a course_id column, get rid of it
alter table textbooks drop column course_id;
commit;

insert into textbooks (textbook_id, title, publisher, publication_date, author_id)
values (1, 'C# From Beginner to Pro', 'Badger Mtn', to_date('01-15-2021','MM-DD-YYYY'),2);

insert into textbooks (textbook_id, title, publisher, publication_date, author_id)
values (2, 'PL/SQL From Beginner to Pro', 'Badger Mtn', null,2);

commit;

insert into instructors (instructor_id, person_id) values (1,2);
commit;

insert into students (student_id, customer_id, person_id) values (1, 1, 2);
insert into students (student_id, customer_id, person_id) values (2, 1, 3);
insert into students (student_id, customer_id, person_id) values (3, null, 1);
commit;

insert into courses (course_id, title, textbook_id) values (1, 'C# Programming', 1);
insert into courses (course_id, title, textbook_id) values (2, 'PL/SQL Programming', 2);
commit;

insert into person_course_roles (person_id, course_id, role) values (3, 1, 'STUDENT');
insert into person_course_roles (person_id, course_id, role) values (4, 1, 'STUDENT');
insert into person_course_roles (person_id, course_id, role) values (3, 2, 'STUDENT');
insert into person_course_roles (person_id, course_id, role) values (4, 2, 'STUDENT');
commit;

insert into sections (course_id, section_id, title) values (1, 1, 'Foundation');
insert into sections (course_id, section_id, title) values (1, 2, 'The Basics');
insert into sections (course_id, section_id, title) values (1, 3, 'Classes');
insert into sections (course_id, section_id, title) values (1, 4, 'Real-World Examples - Web Forms');
insert into sections (course_id, section_id, title) values (1, 5, 'Real-World Examples -Databases and XML');
insert into sections (course_id, section_id, title) values (1, 6, 'Summation');
commit;

insert into chapters (course_id, section_id, chapter_id, title) values (1,1,1,'Roadmap');
insert into chapters (course_id, section_id, chapter_id, title) values (1,1,2,'Sandbox');
insert into chapters (course_id, section_id, chapter_id, title) values (1,1,3,'Hello World');
insert into chapters (course_id, section_id, chapter_id, title) values (1,2,4,'Variables, Datatypes and Operators');
insert into chapters (course_id, section_id, chapter_id, title) values (1,2,5,'Flow Control');
insert into chapters (course_id, section_id, chapter_id, title) values (1,2,6,'Collections');
insert into chapters (course_id, section_id, chapter_id, title) values (1,3,7,'Classes');
insert into chapters (course_id, section_id, chapter_id, title) values (1,3,8,'Namespaces');
insert into chapters (course_id, section_id, chapter_id, title) values (1,3,9,'Input - Output');
insert into chapters (course_id, section_id, chapter_id, title) values (1,4,10,'Calculator');
insert into chapters (course_id, section_id, chapter_id, title) values (1,4,11,'Matching Game');
insert into chapters (course_id, section_id, chapter_id, title) values (1,4,12,'Multi-Select Wizard');
insert into chapters (course_id, section_id, chapter_id, title) values (1,4,13,'Movement');
insert into chapters (course_id, section_id, chapter_id, title) values (1,4,14,'Storefront');
insert into chapters (course_id, section_id, chapter_id, title) values (1,4,15,'Advanced File Types');
insert into chapters (course_id, section_id, chapter_id, title) values (1,5,16,'SQL');
insert into chapters (course_id, section_id, chapter_id, title) values (1,5,17,'DB Connection');
insert into chapters (course_id, section_id, chapter_id, title) values (1,5,18,'DB Parent-Child');
insert into chapters (course_id, section_id, chapter_id, title) values (1,5,19,'DB Stored Procs');
insert into chapters (course_id, section_id, chapter_id, title) values (1,5,20,'Simple XML');
insert into chapters (course_id, section_id, chapter_id, title) values (1,5,21,'DB and XML');
insert into chapters (course_id, section_id, chapter_id, title) values (1,6,22,'Summary');

commit;

insert into pages (course_id, section_id, chapter_id, page_id, external_file_reference, page_type)
values (1,1,1,1, 'd:\rickp\documents\c# from beginner to pro\roadmap.pdf', 'PDF');
insert into pages (course_id, section_id, chapter_id, page_id, external_file_reference, page_type)
values (1,1,1,2, 'd:\rickp\documents\c# from beginner to pro\roadmap p2.pdf', 'PDF');
insert into pages (course_id, section_id, chapter_id, page_id, external_file_reference, page_type)
values (1,1,1,3, 'd:\rickp\documents\c# from beginner to pro\roadmap p3.pdf', 'PDF');

commit;

-- our first join
select	first_name, last_name
from    persons, students
where   persons.person_id = students.person_id
order by last_name, first_name;

-- class roster
select persons.person_id, first_name, last_name, title
from   persons, person_course_roles, courses
where  persons.person_id = person_course_roles.person_id
and    person_course_roles.course_id = courses.course_id
and    person_course_roles.role = 'STUDENT'
order by title, last_name, first_name;

-- table aliases
select a.person_id, first_name, last_name, title
from   persons a, person_course_roles b, courses c
where  a.person_id = b.person_id
and    b.course_id = c.course_id
and    b.role = 'STUDENT'
order by title, last_name, first_name;

-- improperly joined tables
select a.person_id, first_name, last_name, title
from   persons a, person_course_roles b, courses c
where  a.person_id = b.person_id
--and    b.course_id = c.course_id
and    b.role = 'STUDENT'
order by title, last_name, first_name;

-- aggregate functions
select  a.title as course, b.title as section, count(*)
from    courses a, sections b, chapters c
where   a.course_id = b.course_id
and     b.section_id = c.section_id
group by a.title, b.title;

-- get next available primary key value
select nvl(max(customer_id)+1,1) as next_pk
from   customers;

-- insert + select
insert into customers
	(customer_id, name, short_name, contract_start, contract_end)
select	nvl(max(customer_id)+1,1), 'New Customer','NC',sysdate, sysdate+364
from	customers;

select * from customers;

-- uncorrelated subquery
select * from customers 
where  customer_id not in
    (select  customer_id
     from   students
     where  customer_id is not null)
order by name;

-- correlated subquery
select * from textbooks a
where  exists
    (select  1
     from   courses b
     where  a.textbook_id = b.textbook_id)
order by a.title;

-- the dual table
select cos(90) as "Cosign of 90", ln(2.5) as "Natural Log of 2.5", mod(11,4) as "Mod 11,4", sysdate as "Now" from dual;

-- rowid and rownum
select rowid, rownum, name from customers;
