/********************************************************************************/
/*										*/
/*	Chapter 9								*/
/*	Rick Phillips								*/
/*										*/
/********************************************************************************/

-- as SYSTEM
-- grant priv's needed to run debugger to online_training_testing;
grant DEBUG CONNECT SESSION to online_training_testing;
grant DEBUG ANY PROCEDURE to online_training_testing;
commit;

-- as ADMIN
reate or replace NONEDITIONABLE PROCEDURE ENABLE_DEBUGGING
IS 
   ip_address VARCHAR2(40);
BEGIN
  ip_address := SYS_CONTEXT( 'userenv', 'ip_address' );
  DBMS_NETWORK_ACL_ADMIN.APPEND_HOST_ACE
       (HOST=>ip_address,
        ace=> SYS.XS$ACE_TYPE(privilege_list=>sys.XS$NAME_LIST('JDWP') ,
                           principal_name=>USER,
                           principal_type=>sys.XS_ACL.PTYPE_DB) );
     DBMS_OUTPUT.PUT_LINE( 'Added Java debugging privilege for user: ' || USER );
     DBMS_OUTPUT.PUT_LINE( 'At IP address: ' || ip_address );
EXCEPTION
   WHEN OTHERS THEN
      DBMS_OUTPUT.PUT_LINE( 'ENABLE_DEBUGGING: An unknown exception has occurred.' );
      RAISE;
END;

-- as admin
grant execute on enable_debugging to public;
commit;

-- as online_training_testing;
execute admin.enable_debugging;
commit;
