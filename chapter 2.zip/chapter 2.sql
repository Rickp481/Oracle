/************************************************************************/
/*									*/
/*	Chapter 2.sql							*/
/*									*/
/*	Revision Log:							*/
/*		11/22/2021	Rick Phillips	Created			*/
/*									*/
/************************************************************************/

-- set up the privileges needed to drop a user
alter session set "_ORACLE_SCRIPT"=true;

-- clean out any previous users w/ same name as well as all their owned objects
drop user online_training_testing cascade;

-- create our online_training_testing schema
create user online_training_testing identified by my_db_pw;	

-- grant our new user/schema enough privileges to login and create objects
grant connect, resource to online_training_testing with admin option;

-- write these updates to the database
commit;
