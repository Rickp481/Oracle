/****************************************************************************************/
/*											*/
/*	Chapter 22									*/
/*	Rick Phillips									*/
/*	9/23/20022									*/
/*											*/
/****************************************************************************************/


-- as online_training_testing
create table needed_in_new_schema
    (table_name             varchar(100),
     column_name            varchar(100),
     data_type              varchar(100),
     data_length            integer);
commit;
     
-- as SYS (only SYS has full access to these views)
create or replace procedure get_needed_tables as
begin

    insert into online_training_testing.needed_in_new_schema
        (table_name, column_name, data_type, data_length)
    select  
        table_name, column_name, data_type, data_length
    from    
        all_tab_columns
    where   
        owner = 'MASTER_COMMON'
        and table_name not in
            (select     table_name
             from       all_synonyms
             where      owner = 'PUBLIC');

end;

grant execute on get_needed_tables to online_training_testing;

-- now create our new user/schema
alter session set "_ORACLE_SCRIPT"=true;
drop user new_schema_101 cascade;
create user new_schema_101 identified by my_db_pw;	
grant connect, resource to new_schema_101 with admin option;
grant unlimited tablespace to new_schema_101;
commit;

-- now we need to allow online_training_testing to manage objects in new_schema_101
grant create any table to online_training_testing;
grant drop any table to online_training_testing;
grant alter any table to online_training_testing;
commit;

-- now back as online_training_testing
create table new_schema_constraints
	(table_name		varchar(100),
 	 constraint_name	varchar(100),
	 constraint_type	char(1),	-- P = primary key, C = check, R = RI
	 column_name  		varchar(100),
     	 check_rule         	long);
commit;

-- okay, back as SYS we need to get the constraints 
create or replace procedure get_needed_constraints as
begin
	-- we need the distinct because constraint may exist in both schemas
	insert 	into online_training_testing.new_schema_constraints
		(table_name, constraint_name, constraint_type, column_name, check_rule)
	select  distinct a.table_name, a.constraint_name, a.constraint_type, b.column_name, null
	from   	all_constraints a, all_cons_columns b
	where  	a.table_name = b.table_name
	and    	a.constraint_name = b.constraint_name
	and    	b.owner in ('NEW_SCHEMA_101','MASTER_COMMON')
	order by a.table_name, b.column_name;
	
end;

grant execute on get_needed_constraints to online_training_testing;
commit;

-- now we need to make a table in online_training_testing schema to manually maintain check rules
create table check_constraint_rules
	(table_name		varchar(32),
	 column_name		varchar(32),
	 check_rule		varchar(2000));

-- populate that table
insert into check_constraint_rules (table_name, column_name, check_rule)
values ('PROGRAMS','TESTING_OR_TRAINING','CHECK (TESTING_OR_TRAINING IN (''Test'',''Train'',''Both'')');
COMMIT;

-- now again as SYS
-- this view is the full list of tables which we will join to new_schema_constraints
grant select on dba_tables to online_training_testing;
grant select on any table to online_training_testing;
grant insert any table to online_training_testing;

-- these allow online_training_testing to alter tables in new_schema
grant alter any table to online_training_testing;
grant create any index to online_training_testing;
commit;

-- we need these to get the RI external table pk and columns
GRANT SELECT ON DBA_CONSTRAINTS TO ONLINE_TRAINING_TESTING;
GRANT SELECT ON DBA_CONS_COLUMNS TO ONLINE_TRAINING_TESTING;
COMMIT;

-- our package created under the online_training_testing schema
create or replace NONEDITIONABLE package create_new_schema is

    type r_general_info is record (
        company                 varchar(50),
        company_street_add_1    varchar(50),
        company_street_add_2    varchar(50),
        company_city            varchar(50),
        company_state_prov      varchar(50),
        company_country         varchar(50),
        company_postal_code     varchar(25),
        program_name            varchar(100),
        contact_first_name      varchar(50),
        contact_last_name       varchar(50),
        contact_name_prefix     varchar(20),
        contact_name_suffix     varchar(20),
        contact_phone           varchar(20),
        contact_email           varchar(20),
        test_or_training        varchar(10));   -- [Test|Train|Both]
    
    type r_user_defined_val is record (
        user_defined_name       varchar(32),  -- column name max length in Oracle
        user_defined_type       varchar(20),
        user_defined_size       integer default null,
        user_defined_valid      varchar(100));
    type t_user_defined_vals is table of r_user_defined_val index by binary_integer;
    
    type r_user_profile is record (
        first_name              varchar(50),
        last_name               varchar(50),
        street_address_1        varchar(50),
        street_address_2        varchar(50),
        city                    varchar(50),
        state_province          varchar(50),
        postal_code             varchar(25),
        country                 varchar(50),
        security_code           varchar(20),
        password                varchar(20),
        user_defined_vals       t_user_defined_vals);
    
    type r_attachment is record (
        sequence                integer,    -- aka question identifier
        external_file_reference varchar(50),
        page_type               varchar(20));
    type t_attachments is table of r_attachment index by binary_integer;
    
    type r_attachments is record (
        company                 varchar(50),
        program_name            varchar(100),
        attachments             t_attachments);
    
    type t_tasks is table of varchar(1500) index by binary_integer;

    type r_domains is record (
        domain_desc             varchar(1500),
        tasks                   t_tasks);
    type t_domains is table of r_domains index by binary_integer;    
        
    type r_blueprint is record (
        company                 varchar(50),
        program_name            varchar(100),
        domains                 t_domains);
        
    type r_question is record (
        sequence                integer,    -- aka question identifier
        domain                  varchar(1500),
        task                    varchar(1500),
        question_type           varchar(20),
        stem                    varchar(1000),
        correct_response        varchar(1000),
        distractor_1            varchar(1000),
        distractor_2            varchar(1000),
        distractor_3            varchar(1000),
        distractor_4            varchar(1000),
        attachments             t_attachments);
    type t_questions is table of r_question index by binary_integer;
    
    type r_test is record (
        examination_name                varchar(100),
        practice_license_certification  varchar(20), -- [Prac|Lic|Cert]
        scored                          char(1) default 'Y', -- [Y|N]
        immediate_feedback              char(1) default 'Y', -- [Y|N]
        feedback_after_x                integer,
        domain_stats                    char(1) default 'Y', -- [Y|N]
        item_stats                      char(1) default 'Y', -- [Y|N]
        passing_score                   integer,
        duration_seconds                integer,
        z_below_weakness                numeric,
        z_above_strength                numeric,
        five_min_warning                char(1) default 'Y', -- [Y|N]
        lockdown                        char(1) default 'Y', -- [Y|N]
        proctor                         char(1) default 'Y', -- [Y|N]
        accommodations                  char(1) default 'Y', -- [Y|N]
        randomized_questions            char(1) default 'Y', -- [Y\N]
        randomized_distractors          char(1) default 'Y', -- [Y|N]
        questions                       t_questions);
    
    type r_page is record (
        page_title              varchar(100),
        page_sequence           integer,
        external_file_reference varchar(50),
        page_type               varchar(20));
    type t_pages is table of r_page index by binary_integer;
    
    type r_chapter is record (
        chapter_title           varchar(100),
        pages                   t_pages);
    type t_chapters is table of r_chapter index by binary_integer;
    
    type r_section is record (
        section_title           varchar(100),
        chapters                t_chapters);
    type t_sections is table of r_section index by binary_integer;

    type r_training is record (
        training_name           varchar(100),
        tracked                 char(1) default 'Y',
        sections                t_sections);
   
    type r_new_schema is record (
        general_info            r_general_info,
        user_profile            r_user_profile,
        test                    r_test,
        training                r_training);

    new_schema                  r_new_schema;
    attachments                 r_attachments;
    blueprint                   r_blueprint;
    
    procedure start_here; 
    procedure build_new_schema;
    procedure populate_tables;
    
end create_new_schema;

create or replace NONEDITIONABLE package body create_new_schema as
    
    user_defined_val_count  integer;
    attachment_count        integer;
    domain_count            integer;
    task_count              integer;
    question_count          integer;
    section_count           integer;
    chapter_count           integer;
    page_count              integer;
    
    new_schema_name         varchar(100) := 'NEW_SCHEMA_101';
    
    procedure start_here is

        procedure retrieve_external_xmlspecs is
        begin

            insert into xml_documents
                (document_name, date_parsed, xml_document)
            values
                ('new_schema_spec.xml', sysdate,
                xmltype(bfilename('MY_XML_FILES','new_schema_spec.xml'),NLS_Charset_ID('AL32UTFS')));

            insert into xml_documents
                (document_name, date_parsed, xml_document)
            values
                ('attachments.xml', sysdate,
                xmltype(bfilename('MY_XML_FILES','attachments.xml'),NLS_Charset_ID('AL32UTFS')));

            insert into xml_documents
                (document_name, date_parsed, xml_document)
            values
                ('blueprint.xml', sysdate,
                xmltype(bfilename('MY_XML_FILES','blueprint.xml'),NLS_Charset_ID('AL32UTFS')));

        end retrieve_external_xmlspecs;

        procedure parse_general_info is
        begin
            select  b.*
            into    new_schema.general_info.company,
                    new_schema.general_info.company_street_add_1,
                    new_schema.general_info.company_street_add_2,
                    new_schema.general_info.company_city,
                    new_schema.general_info.company_state_prov,
                    new_schema.general_info.company_postal_code,
                    new_schema.general_info.company_country,
                    new_schema.general_info.program_name,
                    new_schema.general_info.contact_first_name,
                    new_schema.general_info.contact_last_name,
                    new_schema.general_info.contact_name_prefix,
                    new_schema.general_info.contact_name_suffix,
                    new_schema.general_info.contact_phone,
                    new_schema.general_info.contact_email,
                    new_schema.general_info.test_or_training
            from    xml_documents a,
                    xmltable ('/new_schema/general'
                            passing a.xml_document
                            columns company_name varchar(100) path 'company',
                                    company_street_add1 varchar(100) path 'company_street_add1',
                                    company_street_add2 varchar(100) path 'company_street_add2',
                                    company_city varchar(100) path 'company_city',
                                    company_state_prov varchar(100) path 'company_state_prov',
                                    company_postal_code varchar(25) path 'company_postal_code',
                                    company_country varchar(50) path 'company_country',
                                    program_name varchar(100) path 'program_name',
                                    contact_first_name varchar(50) path 'contact_first_name',
                                    contact_last_name varchar(50) path 'contact_last_name',
                                    contact_name_prefix varchar(20) path 'contact_name_prefix',
                                    contact_name_suffix varchar(20) path 'contact_name_suffix',
                                    contact_phone varchar(20) path 'contact_phone',
                                    contact_email varchar(20) path 'contact_email',
                                    test_or_train varchar(10) path 'Test_or_Training') b
             where a.document_name = 'new_schema_spec.xml';

        end parse_general_info;
       
        procedure parse_user_profile is
        begin
            select  b.*
            into    new_schema.user_profile.first_name,
                    new_schema.user_profile.last_name,
                    new_schema.user_profile.street_address_1,
                    new_schema.user_profile.street_address_2,
                    new_schema.user_profile.city,
                    new_schema.user_profile.state_province,
                    new_schema.user_profile.postal_code,
                    new_schema.user_profile.country,
                    new_schema.user_profile.security_code,
                    new_schema.user_profile.password
            from    xml_documents a,
                    xmltable ('/new_schema/user_profile'
                        passing a.xml_document
                        columns first_name varchar(50) path 'first_name',
                                last_name varchar(50) path 'last_name',
                                street_address_1 varchar(100) path 'street_address_1',
                                street_address_2 varchar(100) path 'street_address_2',
                                city varchar(100) path 'city',
                                state_province varchar(100) path 'state_province',
                                postal_code varchar(25) path 'postal_code',
                                country varchar(50) path 'country',
                                security_code varchar(20) path 'security_code',
                                password varchar(20) path 'password') b
             where a.document_name = 'new_schema_spec.xml';
             
            user_defined_val_count := 0;
            for lcv in
                (select  b.*
                 from    xml_documents a,
                         xmltable ('/new_schema/user_profile/user_defined_vals/user_defined_val'
                         passing a.xml_document
                         columns user_defined_type varchar(20) path '@type',
                                 user_defined_size integer path '@size',
                                 user_defined_valid varchar(100) path '@valid',
                                 user_defined_name varchar(32) path '@name') b ) loop
                user_defined_val_count := user_defined_val_count + 1;
                new_schema.user_profile.user_defined_vals(user_defined_val_count).user_defined_type := lcv.user_defined_type;
                new_schema.user_profile.user_defined_vals(user_defined_val_count).user_defined_size := lcv.user_defined_size;
                new_schema.user_profile.user_defined_vals(user_defined_val_count).user_defined_valid := lcv.user_defined_valid;
                new_schema.user_profile.user_defined_vals(user_defined_val_count).user_defined_name := lcv.user_defined_name;
            end loop;

       end parse_user_profile;
       
       procedure parse_test is
       begin
            select  b.*
            into    new_schema.test.examination_name,
                    new_schema.test.practice_license_certification,
                    new_schema.test.scored,
                    new_schema.test.immediate_feedback,
                    new_schema.test.feedback_after_x,
                    new_schema.test.domain_stats,
                    new_schema.test.item_stats,
                    new_schema.test.passing_score,
                    new_schema.test.duration_seconds,
                    new_schema.test.z_below_weakness,
                    new_schema.test.z_above_strength,
                    new_schema.test.five_min_warning,
                    new_schema.test.lockdown,
                    new_schema.test.proctor,
                    new_schema.test.accommodations,
                    new_schema.test.randomized_questions,
                    new_schema.test.randomized_distractors
            from    xml_documents a,
                    xmltable ('/new_schema/test'
                            passing a.xml_document
                            columns examination_name varchar(100) path 'examination_name',
                                    practice_license_certification varchar(20) path 'practice_license_certification',
                                    scored char(1) path 'scored',
                                    immediate_feedback char(1) path 'immediate_feedback',
                                    feedback_after_x char(1) path 'feedback_after_x',
                                    domain_stats char(1) path 'domain_stats',
                                    item_stats char(1) path 'item_stats',
                                    passing_score integer path 'passing_score',
                                    duration_seconds integer path 'duration_seconds',
                                    z_below_weakness numeric path 'z_below_weakness',
                                    z_above_strength numeric path 'z_above_strength',
                                    five_min_warning char(1) path 'five_min_warning',
                                    lockdown char(1) path 'lockdown',
                                    proctor char(1) path 'proctor',
                                    accommodations char(1) path 'accommodations',
                                    randomized_questions char(1) path 'randomized_questions',
                                    randomized_distractors char(1) path 'randomized_distractors') b
                where a.document_name = 'new_schema_spec.xml';
       end parse_test;
       
       procedure parse_attachments is
       begin
            select  b.*
            into    attachments.company,
                    attachments.program_name
            from    xml_documents a,
                    xmltable ('/attachments'
                            passing a.xml_document
                            columns company_name varchar(100) path 'company',
                                    program_name varchar(100) path 'program_name') b
             where a.document_name = 'attachments.xml';

            attachment_count := 0;
            for lcv in
                (select  b.*
                 from    xml_documents a,
                         xmltable ('/attachments/attachment'
                         passing a.xml_document
                         columns sequence varchar(50) path 'sequence',
                                 external_file_reference varchar(50) path 'external_file_reference',
                                 page_type varchar(100) path 'page_type') b
                 where a.document_name = 'attachments.xml' ) loop
                
                attachment_count := attachment_count + 1;
                attachments.attachments(attachment_count).sequence := lcv.sequence;
                attachments.attachments(attachment_count).external_file_reference := lcv.external_file_reference;
                attachments.attachments(attachment_count).page_type := lcv.page_type;
            end loop;
       end parse_attachments;
       
       procedure parse_blueprint is
       
            my_file     utl_file.file_type;
            my_string   varchar(1000);
            
            procedure get_tasks 
                (domain_description     varchar) is
                temp        varchar(100);
            begin
                my_file := utl_file.fopen ('MY_XML_FILES','blueprint.xml','R');
                task_count := 0;
                loop
                    utl_file.get_line (my_file, my_string);
                    -- does the current line contain our domain description
                    if (instr(my_string, domain_description) > 1 ) then
                        loop
                            utl_file.get_line (my_file, my_string);
                            if (instr(my_string, '<task>') > 1) then  -- this is a task for this domain
                                task_count := task_count + 1;
                                temp := substr(my_string, instr(my_string, '<task>') + 6);
                                temp := substr(temp, 1, instr(temp, '</task>') - 1);
                                blueprint.domains(domain_count).tasks(task_count) := temp; 
                            elsif (instr(my_string, '</tasks>') > 1) then
                                exit;
                            end if;
                        end loop;
                    end if;
                end loop;
                exception
                    when NO_DATA_FOUND then
                        utl_file.fclose(my_file);
            end get_tasks;

       begin
            domain_count := 0;
            for lcv in
                (select  b.*
                 from    xml_documents a,
                         xmltable ('/blueprint/domains/domain'
                         passing a.xml_document
                         columns domain_desc varchar(50) path 'domain_desc') b
                 where a.document_name = 'blueprint.xml' ) loop
                
                domain_count := domain_count + 1;
                blueprint.domains(domain_count).domain_desc := lcv.domain_desc;
                get_tasks (blueprint.domains(domain_count).domain_desc);
            end loop;
       end parse_blueprint;
       
       procedure parse_questions is
       begin
            question_count := 0;
            for lcv in 
                (select  b.*
                 from    xml_documents a,
                         xmltable ('/new_schema/test/questions/question'
                         passing a.xml_document
                         columns sequence integer path 'sequence',
                                 domain varchar(100) path 'domain',
                                 task varchar(100) path 'task',
                                 question_type varchar(20) path 'question_type',
                                 stem varchar(1000) path 'stem',
                                 correct_response varchar(1000) path 'correct_response',
                                 distractor_1 varchar(1000) path 'distractor_1',
                                 distractor_2 varchar(1000) path 'distractor_2',
                                 distractor_3 varchar(1000) path 'distractor_3',
                                 distractor_4 varchar(1000) path 'distractor_4') b
                  where a.document_name = 'new_schema_spec.xml') loop
                  question_count := question_count + 1;
                  new_schema.test.questions(question_count).sequence := lcv.sequence;
                  new_schema.test.questions(question_count).domain := lcv.domain;
                  new_schema.test.questions(question_count).task := lcv.task;
                  new_schema.test.questions(question_count).question_type := lcv.question_type;
                  new_schema.test.questions(question_count).stem := lcv.stem;
                  new_schema.test.questions(question_count).correct_response := lcv.correct_response;
                  new_schema.test.questions(question_count).distractor_1 := lcv.distractor_1;
                  new_schema.test.questions(question_count).distractor_2 := lcv.distractor_2;
                  new_schema.test.questions(question_count).distractor_3 := lcv.distractor_3;
                  new_schema.test.questions(question_count).distractor_4 := lcv.distractor_4;
            end loop;
       end parse_questions;
       
       procedure parse_training is
       begin
            section_count := 0;

            select  b.*
            into    new_schema.training.training_name,
                    new_schema.training.tracked
            from    xml_documents a,
                    xmltable ('/new_schema/training'
                    passing a.xml_document
                    columns training_name varchar(100) path 'training_name',
                            tracked char(1) path 'tracked') b
            where  a.document_name = 'new_schema_spec.xml'; 

            for lcv1 in 
                (select  b.*
                 from    xml_documents a,
                         xmltable ('/new_schema/training/sections/section'
                         passing a.xml_document
                         columns section_title varchar(100) path 'section_title') b
                where  a.document_name = 'new_schema_spec.xml') loop
                section_count := section_count + 1;
                new_schema.training.sections(section_count).section_title := lcv1.section_title;
            
                chapter_count := 0;
                for lcv2 in
                    (select b.*
                     from   xml_documents a,
                            xmltable ('/new_schema/training/sections/section/chapters/chapter'
                            passing a.xml_document
                            columns chapter_title varchar(100) path 'chapter_title') b,
                            xmltable ('/new_schema/training/sections/section'
                            passing a.xml_document
                            columns section_title varchar(100) path 'section_title') c
                    where   a.document_name = 'new_schema_spec.xml'
                    and     c.section_title = new_schema.training.sections(section_count).section_title) loop
                    chapter_count := chapter_count + 1;
                    new_schema.training.sections(section_count).chapters(chapter_count).chapter_title := lcv2.chapter_title;
                    
                    page_count := 0;
                    for lcv3 in
                        (select     d.*
                         from       xml_documents a,
                                    xmltable ('/new_schema/training/sections/section/chapters/chapter'
                                    passing a.xml_document
                                    columns chapter_title varchar(100) path 'chapter_title') b,
                                    xmltable ('/new_schema/training/sections/section'
                                    passing a.xml_document
                                    columns section_title varchar(100) path 'section_title') c,
                                    xmltable ('/new_schema/training/sections/section/chapters/chapter/pages/page'
                                    passing a.xml_document
                                    columns   page_title varchar(100) path 'page_title',
                                              page_sequence integer path 'page_sequence',
                                              external_file_reference varchar(100) path 'external_file_reference',
                                              page_type varchar(20) path 'page_type') d
                        where       a.document_name = 'new_schema_spec.xml'
                        and         c.section_title = new_schema.training.sections(section_count).section_title
                        and         b.chapter_title = new_schema.training.sections(section_count).chapters(chapter_count).chapter_title) loop

                        page_count := page_count + 1;
                        new_schema.training.sections(section_count).chapters(chapter_count).pages(page_count).page_title := lcv3.page_title;
                        new_schema.training.sections(section_count).chapters(chapter_count).pages(page_count).page_sequence := lcv3.page_sequence;
                        new_schema.training.sections(section_count).chapters(chapter_count).pages(page_count).external_file_reference := lcv3.external_file_reference;
                        new_schema.training.sections(section_count).chapters(chapter_count).pages(page_count).page_type := lcv3.page_type;
                    end loop;
                end loop;
            end loop;

       end parse_training;
       
    begin
        delete from xml_documents;  -- this is inelegant but we don't want to spend time on smart names here
        retrieve_external_xmlspecs;
        parse_general_info;
        parse_user_profile;
        parse_test;
        parse_attachments;
        parse_blueprint;
        parse_questions;
        parse_training;
    end start_here;
    
    procedure build_new_schema is
        my_sql      varchar(1000);
        row_count   integer;
        
        procedure build_tables is
        begin
            for lcv in 
                (select distinct table_name from needed_in_new_schema) loop
            
                my_sql := 'create table ' || new_schema_name || '.' || lcv.table_name || '(';
                select count(*) into row_count from needed_in_new_schema where table_name = lcv.table_name;
                
                for lcv2 in
                    (select   column_name, data_type, data_length, rownum
                    from     needed_in_new_schema
                    where    table_name = lcv.table_name) loop
                 
                    -- sys specifies all column data types as char(x), varchar2(x) or number
                    if lcv2.data_type = 'NUMBER' and lcv2.rownum < row_count then
                        my_sql := my_sql || lcv2.column_name || ' numeric, ';
                    elsif lcv2.data_type = 'NUMBER' then
                        my_sql := my_sql || lcv2.column_name || ' numeric) ';
                    elsif lcv2.data_type = 'CHAR' and lcv2.rownum < row_count then
                        my_sql := my_sql || lcv2.column_name || ' char(' || lcv2.data_length || '), ';
                    elsif lcv2.data_type = 'CHAR' then
                        my_sql := my_sql || lcv2.column_name || ' varchar2(' || lcv2.data_length || ')) ';
                    elsif lcv2.data_type like 'VARCHAR2%' and lcv2.rownum < row_count then
                        my_sql := my_sql || lcv2.column_name || ' varchar2(' || lcv2.data_length || '), ';
                    else
                        my_sql := my_sql || lcv2.column_name || ' varchar2(' || lcv2.data_length || ')) ';
                    end if;                
                end loop;

                execute immediate my_sql;
            end loop;
        end build_tables;
        
        procedure build_pk_constraints is
            my_sql      varchar(1000);
        begin
            for lcv in 
                (select  distinct a.table_name, a.constraint_name
                 from    new_schema_constraints a, dba_tables b
                 where   a.table_name = b.table_name
                 and     a.constraint_type = 'P'
                 and     b.owner = new_schema_name
                 and     a.table_name not like 'BIN$%') loop  -- BIN$% tables are recycle bin stuff
                
                for lcv2 in
                    (select     distinct column_name, rownum
                     from       new_schema_constraints
                     where      table_name = lcv.table_name
                     and        constraint_name = lcv.constraint_name) loop
                    
                    if lcv2.rownum = 1 then
                        my_sql := 'alter table ' || new_schema_name || '.' || lcv.table_name || ' add constraint ' || lcv.constraint_name || 
                                    ' primary key (' || lcv2.column_name; 
                    else
                        my_sql := my_sql || ', ' || lcv2.column_name;
                    end if;
                end loop;
                my_sql := my_sql || ')';
                
                execute immediate my_sql;
            end loop;
        end build_pk_constraints;

        procedure build_fk_constraints is
            my_sql      varchar(1000);
        begin
            for lcv in
                (select  distinct a.table_name as child_table, a.constraint_name, c.r_constraint_name, d.table_name as parent_table
                 from    new_schema_constraints a, dba_tables b, dba_constraints c, dba_constraints d
                 where   a.table_name = b.table_name
                 and     a.table_name = c.table_name
                 and     a.constraint_name = c.constraint_name
                 and     c.r_constraint_name = d.constraint_name
                 and     a.constraint_type = 'R'
                 and     b.owner = new_schema_name
                 and     a.table_name not like 'BIN$%') loop

                my_sql := 'alter table ' || lcv.child_table || ' add constraint ' || lcv.constraint_name || ' foreign key ';
                
                for lcv2 in 
                    (select     distinct column_name, rownum
                     from       dba_cons_columns
                     where      table_name = lcv.child_table
                     and        constraint_name = lcv.constraint_name
                     order by   rownum) loop

                    if lcv2.rownum = 1 then
                        my_sql := my_sql || '(' || lcv2.column_name;
                    else
                        my_sql := my_sql || ',' || lcv2.column_name;
                    end if;
                end loop;
              
                my_sql := my_sql || ') references ' || lcv.parent_table;

                for lcv3 in
                    (select     distinct column_name, rownum
                     from       dba_cons_columns
                     where      table_name = lcv.parent_table
                     and        constraint_name = lcv.r_constraint_name
                     order by   rownum) loop

                    if lcv3.rownum = 1 then
                        my_sql := my_sql || '(' || lcv3.column_name;
                    else
                        my_sql := my_sql || ',' || lcv3.column_name;
                    end if;
                end loop;
                
                my_sql := my_sql || ')';

                execute immediate my_sql;

            end loop;

        end build_fk_constraints;
        
        procedure build_check_constraints is
            my_sql      varchar(1000);
        begin
            for lcv in 
                (select table_name, column_name, check_rule, rownum
                 from   check_constraint_rules) loop
                    my_sql := 'alter table ' || lcv.table_name || ' addd constraint check_constraint' || lcv.rownum || ' ' || lcv.check_rule;
                    execute immediate my_sql;
            end loop;
        end build_check_constraints;
        
    begin
        
        -- we begin by running the sys.get_needed_tables to populate the needed_in_new_schema table
        delete from needed_in_new_schema;
        sys.get_needed_tables;
        build_tables;
        
        -- now we run our get_needed_constraints routine
        delete from new_schema_constraints;
        sys.get_needed_constraints;
        build_pk_constraints;
        build_fk_constraints;
        build_check_constraints;
        
    end build_new_schema;
    
    procedure populate_tables is
        
        procedure populate_blueprint is
            my_sql              varchar(1000);
            my_blueprint_id     integer;
            my_domain_id        integer;
            my_task_id          integer;
        begin

            my_sql := 'select nvl(max(blueprint_id)+1,1) from ' || new_schema_name || '.blueprints';
            execute immediate my_sql into my_blueprint_id;
            dbms_output.put_line (my_sql);
            
            my_sql := 'insert into ' || new_schema_name || '.blueprints (blueprint_id, blueprint_description) ' ||
                        ' values (:bind_var1, :bind_var2)';
            execute immediate my_sql using my_blueprint_id, blueprint.program_name;
            dbms_output.put_line (my_sql);

            my_sql := 'select nvl(max(domain_id)+1,1) from ' || new_schema_name || '.domains';
            execute immediate my_sql into my_domain_id;
            dbms_output.put_line (my_sql);

            my_sql := 'select nvl(max(task_id)+1,1) from ' || new_schema_name || '.tasks';
            execute immediate my_sql into my_task_id;
            dbms_output.put_line (my_sql);

            for lcv1 in 1..blueprint.domains.count loop
                my_sql := 'insert into ' || new_schema_name || '.domains (domain_id, domain_description, domain_relative_weight) ' ||
                            'values (:bind_var1, :bind_var2, null)';
                execute immediate my_sql using my_domain_id, blueprint.domains(lcv1).domain_desc;
                dbms_output.put_line (my_sql);
                
                for lcv2 in 1..blueprint.domains(lcv1).tasks.count loop
                    my_sql := 'insert into ' || new_schema_name || '.tasks (task_id, task_description, task_relative_weight) ' ||
                                'values (:bind_var1, :bind_var2, null)';
                    execute immediate my_sql using my_task_id, blueprint.domains(lcv1).tasks(lcv2);
                    dbms_output.put_line (my_sql);
                    
                    my_sql := 'insert into ' || new_schema_name || '.blueprint_details (blueprint_id, domain_id, task_id) ' ||
                                ' values (:bind_var1, :bind_var2, :bind_var3)';
                    execute immediate my_sql using my_blueprint_id, my_domain_id, my_task_id;
                    dbms_output.put_line (my_sql);

                    my_task_id := my_task_id + 1;                    
                end loop;
                
                my_domain_id := my_domain_id + 1;
            end loop;

            execute immediate 'commit';
            
        end populate_blueprint;
        
        procedure populate_training is
            my_training_id      integer;
            my_section_id       integer;
            my_chapter_id       integer;
            my_page_id          integer;
            my_sql              varchar(1000);
        begin
            
            my_sql := 'select nvl(max(training_id)+1,1) from ' || new_schema_name || '.trainings';
            execute immediate my_sql into my_training_id;
            
            my_sql := 'select nvl(max(section_id)+1,1) from ' || new_schema_name || '.sections';
            execute immediate my_sql into my_section_id;
            
            my_sql := 'select nvl(max(chapter_id)+1,1) from ' || new_schema_name || '.chapters';
            execute immediate my_sql into my_chapter_id;
            
            my_sql := 'select nvl(max(page_id)+1,1) from ' || new_schema_name || '.pages';
            execute immediate my_sql into my_page_id;
            
            my_sql := 'insert into ' || new_schema_name || '.trainings (training_id, training_title) ' ||
                        'values (:bind_var1, :bind_var2)';
            execute immediate my_sql using my_training_id, new_schema.training.training_name;
            dbms_output.put_line (my_sql);
            
            for lcv1 in 1..new_schema.training.sections.count loop
                my_sql := 'insert into ' || new_schema_name || '.sections (section_id, section_title) ' ||
                            ' values (:bind_var1, :bind_var2)';
                execute immediate my_sql using my_section_id, new_schema.training.sections(lcv1).section_title;
                dbms_output.put_line (my_sql);
                
                for lcv2 in 1..new_schema.training.sections(lcv1).chapters.count loop
                    my_sql := 'insert into ' || new_schema_name || '.chapters (chapter_id, chapter_title) ' ||
                                ' values (:bind_var1, :bind_var2)';
                    execute immediate my_sql using my_chapter_id, new_schema.training.sections(lcv1).chapters(lcv2).chapter_title;
                    dbms_output.put_line (my_sql);
                    
                    for lcv3 in 1..new_schema.training.sections(lcv1).chapters(lcv2).pages.count loop
                        my_sql := 'insert into ' || new_schema_name || '.pages (page_id, page_title, external_file_reference, page_type) ' ||
                                    ' values (:bind_var1, :bind_var2, :bind_var3, :bind_var4)';
                        execute immediate my_sql using my_page_id, new_schema.training.sections(lcv1).chapters(lcv2).pages(lcv3).page_title,
                                    new_schema.training.sections(lcv1).chapters(lcv2).pages(lcv3).external_file_reference,
                                    new_schema.training.sections(lcv1).chapters(lcv2).pages(lcv3).page_type;
                        dbms_output.put_line (my_sql);
                        
                        -- now we do all those combination tables; i.e. modules
                        my_sql := 'insert into ' || new_schema_name || '.chapter_pages (chapter_id, page_id) ' ||
                                    'values (:bind_var1, :bind_var2)';
                         execute immediate my_sql using my_chapter_id, my_page_id;
                        dbms_output.put_line (my_sql);
                        
                        my_sql := 'insert into ' || new_schema_name || '.section_chapters (section_id, chapter_id, page_id) ' ||
                                    'values (:bind_var1, :bind_var2, :bind_var3)';
                        execute immediate my_sql using my_section_id, my_chapter_id, my_page_id;
                        dbms_output.put_line (my_sql);

                        my_sql := 'insert into ' || new_schema_name || '.training_sections (training_id, section_id, chapter_id, page_id, page_sequence) ' ||
                                    'values (:bind_var1, :bind_var2, :bind_var3, :bind_var4, :bind_var5)';
                        execute immediate my_sql using my_training_id, my_section_id, my_chapter_id, my_page_id, 
                                    new_schema.training.sections(lcv1).chapters(lcv2).pages(lcv3).page_sequence;
                        dbms_output.put_line (my_sql);

                        my_page_id := my_page_id + 1;                    
                    end loop;
                
                    my_chapter_id := my_chapter_id + 1;
                end loop;
                
                my_section_id := my_section_id + 1;
            end loop;
            commit;
        end populate_training;
        
        procedure populate_general is
            my_company_id           integer;
            my_mailing_address_id   integer;
            my_program_id           integer;
            my_blueprint_id         integer;
            my_sql                  varchar(1000);
            my_person_id            integer;
        begin
            -- company_info goes in master_common schema
            select nvl(max(company_id)+1,1) into my_company_id from master_common.companies;
            insert into master_common.companies (company_id, name)
            values (my_company_id, new_schema.general_info.company);
            
            select nvl(max(mailing_address_id)+1,1) into my_mailing_address_id from master_common.mailing_addresses;
            insert into master_common.mailing_addresses 
                (mailing_address_id, street_address_1, street_address_2, city, state_province, country, postal_code)
            values
                (my_mailing_address_id, new_schema.general_info.company_street_add_1, new_schema.general_info.company_street_add_2,
                 new_schema.general_info.company_city, new_schema.general_info.company_state_prov, new_schema.general_info.company_country,
                 new_schema.general_info.company_postal_code);
                 
            insert into company_addresses (company_id, mailing_address_id, mailing_address_type)
            values (my_company_id, my_mailing_address_id, 'HQ');
            
            -- program info goes in customer/program specific schema
            my_sql := 'select max(blueprint_id) from ' || new_schema_name || '.blueprints';
            execute immediate my_sql into my_blueprint_id;
            
            my_sql := 'select nvl(max(program_id)+1,1) from ' || new_schema_name || '.programs';
            execute immediate my_sql into my_program_id;

            my_sql := 'insert into ' || new_schema_name || '.programs ' ||
                        '(program_id, company_id, program_name, testing_or_training, blueprint_id) ' ||
                        'values (:program_id, :company_id, :program_name, :testing_or_training, :blueprint_id)';
            execute immediate my_sql using my_program_id, my_company_id, new_schema.general_info.program_name, 
                                            new_schema.general_info.test_or_training, my_blueprint_id;
                                        
            -- contact info goes in master_common
            select nvl(max(person_id)+1,1) into my_person_id from master_common.persons;
            insert into master_common.persons (person_id, first_name, last_name, name_prefix, name_suffix)
            values (my_person_id, new_schema.general_info.contact_first_name, new_schema.general_info.contact_last_name,
                    new_schema.general_info.contact_name_prefix, new_schema.general_info.contact_name_prefix);
                    
            insert into master_common.person_emails (person_id, email_address, email_address_type)
            values (my_person_id, new_schema.general_info.contact_email, 'Work');
            
            insert into master_common.company_persons (company_id, person_id, person_role)
            values (my_company_id, my_person_id, 'Point of Contact');
            
        end populate_general;
        
        procedure populate_testing is
            my_sql                  varchar(1000);
            my_test_id              integer;
            my_question_id          integer;
            my_blueprint_id         integer;
            my_domain_id            integer;
            my_task_id              integer;
        begin
            my_sql := 'select nvl(max(test_id)+1,1) from ' || new_schema_name || '.tests';
            execute immediate my_sql into my_test_id;
            
            my_sql := 'insert into ' || new_schema_name || '.tests (test_id, examination_name, practice_license_certification, ' ||
                            'randomized_distractors, scored, immediate_feedback, feedback_after_x, domain_stats, item_stats, ' ||
                            'passing_score,duration_seconds, z_below_weakness, z_above_strength, five_min_warning, lockdown, ' ||
                            'proctor, accommodations, randomized_questions) values (:test_id, :examination_name, :practice_license_certification, '||
                            ':randomized_distractors, :scored, :immediate_feedback, :feedback_after_x, :domain_stats, :item_stats, ' ||
                            ':passing_score,:duration_seconds, :z_below_weakness, :z_above_strength, :five_min_warning, :lockdown, '||
                            ':proctor, :accommodations, :randomized_questions)';
            execute immediate my_sql using my_test_id, new_schema.test.examination_name, new_schema.test.practice_license_certification,
                            new_schema.test.randomized_distractors, new_schema.test.scored, new_schema.test.immediate_feedback,
                            new_schema.test.feedback_after_x, new_schema.test.domain_stats, new_schema.test.item_stats,
                            new_schema.test.passing_score, new_schema.test.duration_seconds, new_schema.test.z_below_weakness,
                            new_schema.test.z_above_strength, new_schema.test.five_min_warning, new_schema.test.lockdown,
                            new_schema.test.proctor, new_schema.test.accommodations, new_schema.test.randomized_questions;

            my_sql := 'select nvl(max(question_id)+1,1) from ' || new_schema_name || '.questions';
            execute immediate my_sql into my_question_id;

            my_sql := 'select max(blueprint_id) from ' || new_schema_name || '.blueprints';
            execute immediate my_sql into my_blueprint_id;
            
            for lcv in 1..new_schema.test.questions.count loop
                my_sql := 'select domain_id from ' || new_schema_name || '.domains where domain_description = :bind_1 ';
                execute immediate my_sql into my_domain_id using new_schema.test.questions(lcv).domain;
                my_sql := 'select task_id from ' || new_schema_name || '.tasks where task_description = :bind_1 ';
                execute immediate my_sql into my_task_id using new_schema.test.questions(lcv).task;
                
                my_sql := 'insert into ' || new_schema_name || '.questions (question_id, question_type, blueprint_id, domain_id, ' ||
                                'task_id, stem, correct_response, distractor_1, distractor_2, distractor_3, distractor_4) ' ||
                          'values (:question_id, :question_type, :blueprint_id, :domain_id, :task_id, :stem, :distractor_1, ' ||
                          '         :distractor_2, :distractor_3, :distractor_4)';
                execute immediate my_sql using (lcv + my_question_id - 1), new_schema.test.questions(lcv).question_type, my_blueprint_id,
                            my_domain_id, my_task_id, new_schema.test.questions(lcv).stem, new_schema.test.questions(lcv).correct_response,
                            new_schema.test.questions(lcv).distractor_1, new_schema.test.questions(lcv).distractor_2,
                            new_schema.test.questions(lcv).distractor_3, new_schema.test.questions(lcv).distractor_4;
                            
                my_sql := 'insert into ' || new_schema_name || '.test_questions (test_id, question_id) values (:test_id, :question_id)';
                execute immediate my_sql using my_test_id, lcv + my_question_id - 1;
                            
           end loop;
            
        end populate_testing;
        
    begin
        populate_blueprint;
        populate_training;
        populate_general;
        populate_testing;
        
    end populate_tables;

end create_new_schema;
