/************************************************************************************************/
/*												*/
/*	Chapter 12.SQL										*/
/*	Rick Phillips										*/
/*	9/17/2021										*/
/*												*/
/************************************************************************************************/

-- explicit cursors 
create or replace procedure simple_explicit_cursor as

    cursor      c1 is
    select      a.title, b.title, c.title, d.title
    from        courses a, sections b, chapters c, textbooks d
    where       a.course_id = b.course_id
    and         b.course_id = c.course_id
    and         b.section_id = c.section_id
    and         a.textbook_id = d.textbook_id
    order by    a.course_id, b.section_id, c.chapter_id;

    course_title    courses.title%type;	-- self documenting column data type
    section_title   sections.title%type;
    chapter_title   chapters.title%type;
    textbook_title  textbooks.title%type;

begin

    open c1;    -- open our cursor
    loop
        -- grab some data from the db
        fetch c1 into course_title, section_title, chapter_title, textbook_title;
        exit when c1%notfound; -- jump out when no data found
        -- output the data to the screen
        dbms_output.put_line (course_title || ' ' || section_title || ' ' || chapter_title || ' ' || textbook_title);
    end loop;
    close c1;   -- release cursor

end;

-- try it again with a record structure receiving data
create or replace procedure simple_explicit_cursor_v2 as

    cursor      c1 is
    select      a.title, b.title, c.title, d.title
    from        courses a, sections b, chapters c, textbooks d
    where       a.course_id = b.course_id
    and         b.course_id = c.course_id
    and         b.section_id = c.section_id
    and         a.textbook_id = d.textbook_id
    order by    a.course_id, b.section_id, c.chapter_id;

    type t_titles is record
    (course_title   courses.title%type,
    section_title   sections.title%type,
    chapter_title   chapters.title%type,
    textbook_title  textbooks.title%type);

    titles          t_titles;   -- use this record type (class) to receive data from cursor

begin

    open c1;    -- open our cursor
    loop
        -- grab some data from the db
        fetch c1 into titles;
        exit when c1%notfound; -- jump out when no data found
        -- output the data to the screen
        dbms_output.put_line (titles.course_title || ' ' || titles.section_title || ' ' || titles.chapter_title || ' ' || titles.textbook_title);
    end loop;
    close c1;   -- release cursor

end;

-- now with the for loop
create or replace procedure simple_explicit_cursor_v3 as

    -- note that now we need column aliases to distinguish between the same name columns
    cursor      c1 is
    select      a.title as course_title, b.title as section_title, c.title as chapter_title, d.title as textbook_title
    from        courses a, sections b, chapters c, textbooks d
    where       a.course_id = b.course_id
    and         b.course_id = c.course_id
    and         b.section_id = c.section_id
    and         a.textbook_id = d.textbook_id
    order by    a.course_id, b.section_id, c.chapter_id;

begin

    for titles in c1 loop  -- for cursor loops are very cool
        -- output the data to the screen
        dbms_output.put_line (titles.course_title || ' ' || titles.section_title || ' ' || titles.chapter_title || ' ' || titles.textbook_title);
    end loop;

end;

-- implicit cursor
create or replace procedure simple_implicit_cursor as

begin

    for titles in -- Note the required paren's and column aliases
        (select      a.title as course_title, b.title as section_title, c.title as chapter_title, d.title as textbook_title
        from        courses a, sections b, chapters c, textbooks d
        where       a.course_id = b.course_id
        and         b.course_id = c.course_id
        and         b.section_id = c.section_id
        and         a.textbook_id = d.textbook_id
        order by    a.course_id, b.section_id, c.chapter_id)
    loop  -- implicit for cursor loops are even cooler
        -- output the data to the screen
        dbms_output.put_line (titles.course_title || ' ' || titles.section_title || ' ' || titles.chapter_title || ' ' || titles.textbook_title);
    end loop;

end; 

-- implicit cursor and user-defined data structure (we have reached the top of the stack)
create or replace procedure simple_implicit_cursor_v2 as

    type t_titles is record
    (course_title   varchar(100),
    section_title   varchar(100),
    chapter_title   varchar(100),
    textbook_title  varchar(100));
    
    type tab_titles is table of t_titles index by pls_integer;
    my_titles       tab_titles;
    title_index     integer := 0;

begin

    for titles in -- Note the required paren's
        (select      a.title as course_title, b.title as section_title, c.title as chapter_title, d.title as textbook_title
        from        courses a, sections b, chapters c, textbooks d
        where       a.course_id = b.course_id
        and         b.course_id = c.course_id
        and         b.section_id = c.section_id
        and         a.textbook_id = d.textbook_id
        order by    a.course_id, b.section_id, c.chapter_id)
    loop  -- implicit for cursor loops are even cooler
        -- store row to my_titles with index of title_index + 1;
        title_index := title_index + 1;
        my_titles(title_index).course_title := titles.course_title;
        my_titles(title_index).section_title := titles.section_title;
        my_titles(title_index).chapter_title := titles.chapter_title;
        my_titles(title_index).textbook_title := titles.textbook_title;
    end loop;

    for lcv in 1..title_index loop
        -- print this stuff out to prove we have it
        dbms_output.put_line (my_titles(lcv).course_title || ' ' || my_titles(lcv).section_title || ' ' || my_titles(lcv).chapter_title || ' ' || my_titles(lcv).textbook_title);
    end loop;

end; 

-- getting closer to the real-world
create or replace procedure big_time_cursors as
    
        cursor      c1      is
                    select  a.course_id, a.title as course_title, b.title as textbook_title
                    from    courses a, textbooks b
                    where   a.textbook_id = b.textbook_id
                    order by a.course_id;
         type       t_course_textbooks is record
                    (course_id      integer,
                     course_title   varchar(100),
                     textbook_title varchar(100));
        type        tab_course_textbooks is table of t_course_textbooks index by pls_integer;
        my_course_textbooks         tab_course_textbooks;
        my_course_index             integer := 0;

        cursor      c2      (course_id_in   number) is  -- note how cursor is accepting parmaeter
                    select  course_id, section_id, title
                    from    sections
                    where   course_id = course_id_in
                    order by course_id, section_id;
        type        t_section_stuff is record
                    (course_id      integer,
                    section_id       integer,
                    section_title   varchar(100));
        type        tab_sections is table of t_section_stuff index by pls_integer;
        my_sections                 tab_sections;
        my_section_index            integer := 0;

        cursor      c3      (course_id_in   number, section_id_in   number) is
                    select  course_id, section_id, chapter_id, title
                    from    chapters
                    where   course_id = course_id_in
                    and     section_id = section_id_in
                    order by course_id, section_id, chapter_id;
        type        t_chapter_stuff is record
                    (course_id      integer,
                    section_id      integer,
                    chapter_id      integer,
                    chapter_title   varchar(100));
        type        tab_chapters is table of t_chapter_stuff index by pls_integer;
        my_chapters                 tab_chapters;
        my_chapter_index            integer := 1;

        lcv1                        integer;
        lcv2                        integer;
        lcv3                        integer;

begin

    open c1;
    loop
        my_course_index := my_course_index + 1;
        fetch c1 into my_course_textbooks(my_course_index);
        exit when c1%notfound;

                open c2(my_course_textbooks(my_course_index).course_id);  -- note the parameter pass here from c1
                loop
                    my_section_index := my_section_index + 1;
                    fetch c2 into my_sections(my_section_index);
                    exit when c2%notfound;

                        open c3 (my_course_textbooks(my_course_index).course_id, my_sections(my_section_index).section_id);
                        loop
                            fetch c3 into my_chapters(my_chapter_index);
                            exit when c3%notfound;
                            my_chapter_index := my_chapter_index + 1;
                        end loop;
                     close c3;

                end loop;
                close c2;

    end loop;
    close c1;
    
    for lcv1 in my_course_textbooks.first .. my_course_textbooks.last loop
        
        dbms_output.put_line('Course ' || ' ' || my_course_textbooks(lcv1).course_id || ' ' || my_course_textbooks(lcv1).course_title || ' ' || my_course_textbooks(lcv1).textbook_title);
        
        for lcv2 in my_sections.first .. my_sections.last loop
        
            if (my_course_textbooks(lcv1).course_id = my_sections(lcv2).course_id) then

                dbms_output.put_line ('     Section ' || my_sections(lcv2).section_title);

                for lcv3 in my_chapters.first .. my_chapters.last loop
                
                    if (my_chapters(lcv3).section_id = my_sections(lcv2).section_id) then
                    
                        dbms_output.put_line ('          Chapter ' || my_chapters(lcv3).chapter_title);
                        
                    end if;
                    
                end loop;
                
            end if;

        end loop;

    end loop;

end;

-- the real-world is here!!!
create or replace procedure big_time_cursors_v2 as
    
begin

    for my_course_textbook in
        (select     a.course_id, a.title as course_title, b.title as textbook_title
        from        courses a, textbooks b
        where       a.textbook_id = b.textbook_id
        order by    a.course_id) loop

        dbms_output.put_line('Course ' || ' ' || my_course_textbook.course_id || ' ' || my_course_textbook.course_title || ' ' || my_course_textbook.textbook_title);
        
        for my_section in
            (select     course_id, section_id, title as section_title
            from        sections
            where       course_id = my_course_textbook.course_id
            order by    course_id, section_id) loop

            dbms_output.put_line ('     Section ' || my_section.section_title);


            for my_chapter in
                (select     course_id, section_id, chapter_id, title as chapter_title
                from        chapters
                where       course_id = my_section.course_id
                and         section_id = my_section.section_id
                order by    course_id, section_id, chapter_id) loop

                dbms_output.put_line ('          Chapter ' || my_chapter.chapter_title);

            end loop;
                
        end loop;

    end loop;

end;