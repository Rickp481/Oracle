/****************************************************************************************/
/*											*/
/*	Chapter 11.sql									*/
/*	Rick Phillips									*/
/*	9-11-2021									*/
/*											*/
/****************************************************************************************/

-- the basic if statement
create or replace procedure basic_if_statement as

	my_char		varchar2(20) := 'Hello World';

begin

	if my_char = 'Hello World' then
		dbms_output.put_line ('This will print if the conditional my_char = ''Hello World'' resolves to true');
	end if;

end;

-- the else keyword
create or replace procedure basic_if_statement as

	my_char		varchar2(20) := 'Hello World';

begin

	if my_char = 'Hell0 World' then
		dbms_output.put_line ('This will print if the conditional my_char = ''Hell0 World'' resolves to true');
    	else
		dbms_output.put_line ('This will print if the conditional my_char = ''Hell0 World'' resolves to false');  
	end if;

end;

-- the elsif keyword
create or replace procedure basic_if_statement as

	my_char		varchar2(20) := 'Hello World';

begin

	if my_char = 'Hell0 World' then
		dbms_output.put_line ('This will print if the conditional my_char = ''Hell0 World'' resolves to true');
    elsif my_char = '123456789' then
		dbms_output.put_line ('This will print if the conditional my_char = ''123456789'' resolves to true');  
    elsif my_char = 'Hello World' then
		dbms_output.put_line ('This will print if the conditional my_char = ''Hello World'' resolves to true');  
    else
		dbms_output.put_line ('This will print if none of the above conditionals was true');      
	end if;

end;

-- only the first true elsif
create or replace procedure basic_if_statement as

	my_char		varchar2(20) := 'Hello World';

begin

	if my_char = 'Hell0 World' then
		dbms_output.put_line ('This will print if the conditional my_char = ''Hell0 World'' resolves to true');
    elsif my_char = 'Hello World' then
		dbms_output.put_line ('This will print if the conditional my_char = ''Hello World'' resolves to true');  
    elsif my_char = 'Hello World' then
		dbms_output.put_line ('This will not print because we have already encountered a true conditional');  
    else
		dbms_output.put_line ('This will print if none of the above conditionals was true');      
	end if;

end;

-- nested if statements
create or replace procedure basic_if_statement as

	my_char		varchar2(20) := 'Hello World';

begin

     if my_char = 'Hell0 World' then
		dbms_output.put_line ('This will print if the conditional my_char = ''Hell0 World'' resolves to true');
    elsif my_char != 'Hello World' then
		dbms_output.put_line ('This will print if the conditional my_char = ''Hello World'' resolves to true');  
    elsif my_char != 'Hello World' then
		dbms_output.put_line ('This will not print because we have already encountered a true conditional');  
    else
		dbms_output.put_line ('This will print if none of the above conditionals was true');      
        if my_char like 'Hell%' then
            dbms_output.put_line ('This will print too.');
        end if;
    end if;

end;

-- CASE statement is not used by real programmers
create or replace  procedure nobody_uses_the_case_statement as

	my_char		varchar2(20) := 'Hello World';

begin

    case my_char  -- case statement with selector variable
        when 'First Option' then
            dbms_output.put_line('The variable my_char resolves to First Option');
        when 'Second Option' then
            dbms_output.put_line('The variable my_char resolves to Second Option');
        when 'Hello World' then
            dbms_output.put_line('The variable my_char resolves to Hello World');
        else
            dbms_output.put_line('None of the above is true');
    end case;
    
    case   -- case statement without selector variable
        when my_char = 'First Option' then
            dbms_output.put_line('The variable my_char is equal to First Option');
        when my_char = 'Second Option' then
            dbms_output.put_line('The variable my_char is equal to Second Option');
        when my_char = 'Hello World' then
            dbms_output.put_line('The variable my_char is equal to Hello World');
        else
            dbms_output.put_line('None of the above is true');
    end case;

end;

-- simiple loop keyword with associated exit and continue keywords
create or replace procedure simple_loop_w_exit_and_continue as

    test    integer := 0;
    
begin

    loop
            test := test + 1;
            if test = 1 then
                dbms_output.put_line ('test = ' || ' ' || test);
            elsif test = 2 then
                -- continue says jumpt back to the keyword loop
                continue;
                dbms_output.put_line ('This line will never execute.');
            else
                -- exit can exist with or without conditional
                exit when test = 3;
                exit; -- this will never execute
            end if;
    end loop;

end;

-- simple while
create or replace procedure simple_while as

    lcv     varchar(100) := 'a';

begin

    while length(lcv) < 5 loop
        dbms_output.put_line ('lcv = ' || lcv || ' and it has a length of ' || length(lcv));
        lcv := lcv || 'a';
    end loop;

end;

-- simple range for loop
create or replace procedure range_for_loop as

    lcv         integer;
    output_var  integer;
begin

    for lcv in 2..5 loop
        dbms_output.put_line ('default step size is 1, lcv = ' || lcv);
    end loop;

    for lcv in 2..5 loop
        output_var := lcv * 2;
        dbms_output.put_line ('simulate step size of 2, output_var = ' || output_var);
    end loop;
    
    for lcv in reverse 2..5 loop
        dbms_output.put_line ('reverse keyword with default step size of 1, lcv = ' || lcv);
    end loop;
    
end;

-- nested loops
create or replace NONEDITIONABLE procedure nested_loops as

    type t_players is table of varchar(100) index by pls_integer;
    type t_teams is record
    (   team_name       varchar(100),
        team_city       varchar(100),
        team_state      varchar(100),
        team_players    t_players);

    type t_teams_table is table of t_teams index by pls_integer;
    teams   t_teams_table;

    team_index          integer;
    player_index        integer;

begin
    -- load up some data
    teams(1).team_name := 'Ricks Rough Riders';
    teams(1).team_city := 'Ferguson';
    teams(1).team_state := 'North Carolina';
    teams(1).team_players(1) := 'Bob';
    teams(1).team_players(2) := 'Joe';
    teams(1).team_players(3) := 'Pete';

    teams(2).team_name := 'Got To Be Tough';
    teams(2).team_city := 'Columbia';
    teams(2).team_state := 'South Carolina';
    teams(2).team_players(1) := 'Sue';
    teams(2).team_players(2) := 'Sally';
    teams(2).team_players(3) := 'Joyce';

    -- now print this stuff out
    team_index := teams.first;
    loop
        exit when team_index is null;
        dbms_output.put_line ('Team Name: ' || teams(team_index).team_name);
        dbms_output.put_line ('Team City: ' || teams(team_index).team_city);
        dbms_output.put_line ('Team State: ' || teams(team_index).team_state);
        dbms_output.put_line ('     Players: ');
        player_index := teams(team_index).team_players.first;
        loop
            exit when player_index is null;
            dbms_output.put_line ('          ' || teams(team_index).team_players(player_index));
            player_index := teams(team_index).team_players.next(player_index);
        end loop;
        team_index := teams.next(team_index);
    end loop;
end;

