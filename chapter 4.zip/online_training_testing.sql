/************************************************************************/
/*									*/
/*	Online_Training_Testing Schema Script				*/
/*	Rick Phillips							*/
/*	V1.0 2/27/2021							*/
/*									*/
/************************************************************************/

-- sql is case insensitive and white space tolerant

/* we always start with the base tables */
create table roles (role varchar(20) 
	constraint roles_pk primary key);

create table page_types (page_type varchar(25)
	constraint page_type_pk primary key);

/* now the data tables - RI Root node to leaf nodes */
create table customers
(customer_id	integer,
name		varchar(50) not null,
short_name	varchar(6) not null,
contract_start	date default sysdate,	-- default = now
contract_end	date,
constraint customers_pk primary key (customer_id));

create table persons
(person_id	integer,
first_name	varchar(30) not null,
last_name	varchar(50) not null,
email		varchar(50),
telephone	varchar(20),
password	varchar(30),
password_update	date,
manager_id	integer,
constraint persons_pk primary key (person_id),
constraint persons_fk0 foreign key (manager_id) references persons(person_id));

create table students
(student_id	integer,
customer_id	integer,
person_id	integer not null,
constraint students_pk primary key (student_id),
constraint students_fk0 foreign key (customer_id) references customers(customer_id),
constraint students_fk1 foreign key (person_id) references persons(person_id));

create table instructors
(instructor_id	integer,
person_id	integer not null,
constraint instructors_pk primary key (instructor_id),
constraint instructors_fk0 foreign key (person_id) references persons(person_id));

create table courses
(course_id	integer,
title		varchar(200) not null,
constraint courses_pk primary key (course_id));

create table student_courses
(student_id	integer,
course_id	integer,
constraint student_courses_pk primary key (course_id, student_id)) -- arbitrary order
organization index;	-- index only table

-- textbook attributes are transitively dependent on course id via textbook ID
create table textbooks
(textbook_id	int,
title		varchar(200) not null,
publisher	varchar(200),
publication_date	date,
author_id	int,
course_id	int,
constraint textbooks_pk primary key (textbook_id),
constraint textbooks_fk0 foreign key (author_id) references persons(person_id),
constraint textbooks_fk1 foreign key (course_id) references courses(course_id));

-- we can now go back and get our courses textbook_id fk
alter table courses add textbook_id integer not null;
alter table courses add constraint courses_fk0 foreign key (textbook_id) references textbooks(textbook_id);

create table person_course_roles
(person_id	integer,
course_id	integer,
role		varchar(50),
constraint person_course_roles_pk primary key (course_id, person_id, role))
organization index;

create table sections
(course_id	integer,
section_id	integer,
title		varchar(200),
constraint sections_pk primary key (course_id, section_id));

create table chapters
(course_id	integer,
section_id	integer,
chapter_id	integer,
title		varchar(200),
constraint chapters_pk primary key (course_id, section_id, chapter_id));

create table pages
(course_id	integer,
section_id	integer,
chapter_id	integer,
page_id	integer,
external_file_reference	varchar(250),
page_type	varchar(25),
constraint pages_pk primary key (course_id, section_id, chapter_id, page_id),
constraint pages_fk0 foreign key (page_type) references page_types(page_type));

-- we don't need the instructor_courses table as that is covered via roles

-- now the audit tables
create table persons_audit
(person_id	integer,
update_datetime	date default sysdate,
first_name	varchar(30) not null,
last_name	varchar(50) not null,
email		varchar(50),
telephone	varchar(20),
password	varchar(30),
password_update	date,
manager_id	integer,
update_by_person_id	integer not null,
constraint persons_audit_pk primary key (person_id, update_datetime),
constraint persons_audit_fk0 foreign key (manager_id) references persons(person_id),
constraint persons_audit_fk1 foreign key (update_by_person_id) references 	persons(person_id));

create table customers_audit
(customer_id	integer,
update_datetime	date default sysdate,
name		varchar(50) not null,
short_name	varchar(6) not null,
contract_start	date default sysdate,	-- default = now
contract_end	date,
update_by_person_id	integer,
constraint customers_audit_pk primary key (customer_id, update_datetime),
constraint customers_audit_fk0 foreign key (update_by_person_id) 
	references persons(person_id));

create table students_audit
(student_id	integer,
update_datetime	date default sysdate,
customer_id	integer not null,
person_id	integer not null,
update_by_person_id	integer not null,
constraint students_audit_pk primary key (student_id, update_datetime),
constraint students_audit_fk0 foreign key (customer_id) references customers(customer_id),
constraint students_audit_fk1 foreign key (person_id) references persons(person_id),
constraint students_audit_fk2 foreign key (update_by_person_id) references 	persons(person_id));

create table instructors_audit
(instructor_id	integer,
update_datetime	date default sysdate,
person_id	integer not null,
update_by_person_id	integer not null,
constraint instructors_audit_pk primary key (instructor_id, update_datetime),
constraint instructors_audit_fk0 foreign key (person_id) references persons(person_id),
constraint instructors_audit_fk1 foreign key (update_by_person_id) references 	persons(person_id));

create table courses_audit
(course_id	integer,
update_datetime	date default sysdate,
title		varchar(200) not null,
update_by_person_id	integer not null,
constraint courses_audit_pk primary key (course_id, update_datetime),
constraint courses_audit_fk0 foreign key (update_by_person_id) references 	persons(person_id));

create table textbooks_audit
(textbook_id	int,
update_datetime	date default sysdate,
title		varchar(200) not null,
publisher	varchar(200),
publication_date	date,
author_id	int,
course_id	int,
update_by_person_id	int,
constraint textbooks_audit_pk primary key (textbook_id, update_datetime),
constraint textbooks_audit_fk0 foreign key (author_id) references persons(person_id),
constraint textbooks_audit_fk1 foreign key (course_id) references courses(course_id),
constraint textbooks_audit_fk2 foreign key (update_by_person_id) references 	persons(person_id));

create table student_courses_audit
(student_id	integer,
course_id	integer,
update_datetime	date default sysdate,
update_by_person_id 	integer,
constraint student_courses_audit_pk primary key (course_id, student_id, update_datetime),
constraint student_courses_audit_fk0 foreign key (update_by_person_id) references 	persons(person_id));

 create table person_course_roles_audit
(person_id	integer,
course_id	integer,
role		varchar(50),
update_datetime	date default sysdate,
update_by_person_id	int,
constraint person_course_roles_audit_pk primary key (course_id, person_id, role),
constraint person_course_roles_audit_fk0 foreign key (update_by_person_id) references 	persons(person_id));

create table sections_audit
(course_id	integer,
section_id	integer,
update_datetime	date default sysdate,
title		varchar(200),
update_by_person_id	integer,
constraint sections_audit_pk primary key (course_id, section_id, update_datetime),
constraint sections_audit_fk0 foreign key (update_by_person_id) references 	persons(person_id));

create table chapters_audit
(course_id	integer,
section_id	integer,
chapter_id	integer,
update_datetime	date default sysdate,
title		varchar(200),
update_by_person_id	integer,
constraint chapters_audit_pk primary key (course_id, section_id, chapter_id, 	update_datetime),
constraint chapters_audit_fk0 foreign key (update_by_person_id) references 	persons(person_id));

create table pages_audit
(course_id	integer,
section_id	integer,
chapter_id	integer,
page_id	integer,
update_datetime	date default sysdate,
external_file_reference	varchar(250),
page_type	varchar(25),
update_by_person_id	integer,
constraint pages_audit_pk primary key (course_id, section_id, chapter_id, page_id, 	update_datetime),
constraint pages_audit_fk0 foreign key (page_type) references page_types(page_type),
constraint pages_audit_fk1 foreign key (update_by_person_id) references 	persons(person_id));

-- now drop a table 
drop table student_courses; -- we will take care of this via roles
drop table student_courses_audit;

