/****************************************************************************************************************/
/*														*/
/*	chapter 18 XML												*/
/*	Rick Phillips												*/
/*	3/28/2022												*/
/*														*/
/****************************************************************************************************************/

-- the xmlelement function return an xmltype oracle data primitive
select      xmlelement("Customer Name",name) 
from        customers 
order by    customer_id;

-- now we will see what the xmltype.getclobval function does
select      xmltype.getclobval(xmlelement("Customer Name",name)) 
from        customers 
order by    customer_id;

-- the XMLAttributes function
select      xmltype.getclobval(xmlelement("Customer Name",
                                XMLAttributes(customer_id as "ID"),
                                name)) 
from        customers 
order by    customer_id;

-- the xmlforest function
select      xmltype.getclobval(xmlforest(customer_id as "ID", name as "Name") )
from        customers 
order by    customer_id;

-- let's combine xmlelement and xmlforest funcitons with the xmltype.getclobval function
select      xmltype.getclobval(xmlelement("Customer",xmlforest(customer_id as "ID", name as "Name")))
from        customers
order by    customer_id;

-- an xml comment is self defining, xml processing instructions tell the receiving application
-- how to process subsequent information; e.g. cascading style sheet for browser display
select  xmltype.getclobval(xmlpi(name "PI Target", 'this is a processing instruction')),
        xmltype.getclobval(xmlcomment('This is an XML comment'))
from dual;

-- let's alter our database to add a table to store student online learning activity as
-- associated with our example XML file
create table person_pages
(person_id      integer,
 course_id      integer,
 section_id     integer,
 chapter_id     integer,
 page_id        integer,
 start_datetime date,
 end_datetime   date,
 constraint person_pages_pk primary key (course_id, section_id, chapter_id, page_id, person_id),
 constraint person_pages_fk0 foreign key (course_id, section_id, chapter_id, page_id) references
    pages(course_id, section_id, chapter_id, page_id),
 constraint person_pages_fk1 foreign key (person_id) references persons(person_id));

-- populate that table
insert into person_pages
    (person_id, course_id, section_id, chapter_id, page_id, start_datetime, end_datetime)
values
    (3, 1, 1, 1, 1, to_date('28-03-2022 09:56:07','DD-MM-YYYY HH24:MI:SS'),to_date('28-03-2022 09:58:37','DD-MM-YYYY HH24:MI:SS'));
insert into person_pages
    (person_id, course_id, section_id, chapter_id, page_id, start_datetime, end_datetime)
values
    (3, 1, 1, 1, 2, to_date('28-03-2022 09:58:38','DD-MM-YYYY HH24:MI:SS'),to_date('28-03-2022 10:00:21','DD-MM-YYYY HH24:MI:SS'));
 insert into person_pages
    (person_id, course_id, section_id, chapter_id, page_id, start_datetime)
values
    (3, 1, 1, 1, 3, to_date('28-03-2022 10:00:24','DD-MM-YYYY HH24:MI:SS'));
insert into person_pages
    (person_id, course_id, section_id, chapter_id, page_id, start_datetime)
values
    (4, 1, 1, 1, 1, to_date('28-03-2022 09:56:07','DD-MM-YYYY HH24:MI:SS'));
commit;

-- in addition we need a table to store our xml fragments 
create table my_clob_table (my_xml_clob clob, counter integer);

-- now we start to play with the xmlgen package
-- which very quickly runs out of gas on nested 1:M relationships
declare

    QueryContext        dbms_xmlgen.ctxhandle;
    my_clob             clob;
    
begin

    -- assign a select statement to our context handle
    QueryContext := dbms_xmlgen.newcontext ('select * from customers');
    
    -- retrieve the xml to a local clob   
    my_clob := dbms_xmlgen.getxml(QueryContext);

    -- insert that clob to our new table
    insert into my_clob_table (my_xml_clob, counter)
    values (my_clob, 1);
    
    -- release the context handle
    dbms_xmlgen.closecontext (QueryContext);

end;

-- clean up that row and rowset tag issue
declare

    QueryContext        dbms_xmlgen.ctxhandle;
    my_clob             clob;
    
begin

    -- assign a select statement to our context handle
    QueryContext := dbms_xmlgen.newcontext ('select * from customers');
    
    -- change those row and rowset tags
    dbms_xmlgen.setrowsettag (QueryContext, 'Customers');
    dbms_xmlgen.setrowtag (QueryContext, 'Customer');

    -- retrieve the xml to a local clob   
    my_clob := dbms_xmlgen.getxml(QueryContext);

    -- insert that clob to our new table
    insert into my_clob_table (my_xml_clob, counter)
    values (my_clob, 1);
    
    -- release the context handle
    dbms_xmlgen.closecontext (QueryContext);

end;

select my_xml_clob from my_clob_table;

-- this is the base SQL statement we will use to generate our
-- example XML file
select	a.person_id, c.course_id, c.title as course_title, d.section_id as section_title,
	e.title as chapter_title, f.page_id, b.start_datetime, b.end_datetime, f.external_file_reference
from	persons a, person_pages b, courses c, sections d, chapters e, pages f
where	a.person_id = b.person_id
and	b.course_id = c.course_id
and	b.course_id = d.course_id and b.section_id = d.section_id
and	b.course_id = e.course_id and b.section_id = e.section_id and b.chapter_id = e.chapter_id
and	b.course_id = f.course_id and b.section_id = f.section_id and b.chapter_id = f.chapter_id and b.page_id = f.page_id
and 	a.status = 'Active'
order by
	b.person_id, b.course_id, b.section_id, b.chapter_id, b.page_id;

-- before we change to simple select approach let's get that clob
-- out of the picture
drop table my_clob_table;
create table my_xml_fragments 
(counter	integer,
 xml_fragment	varchar(1000),
 constraint my_xml_framents_pk primary key (counter));

-- iteration one of nested cursor approach
-- very straight forward and easy to maintain
create or replace NONEDITIONABLE procedure create_todays_student_pages  as

    my_string       varchar(1000);
    my_counter      integer := 1;
    my_person_id    integer;
    my_course_id    integer;
    my_section_id   integer;
    
    -- we only want  single copy of all students who opened a page today
    cursor c1 is
    select  distinct '<student person_id=' || chr(34) || a.person_id || chr(34) || '><first_name>' || a.first_name || 
                        '</first_name><last_name>' || a.last_name  || '</last_name>' as fragment, a.person_id
    from    persons a, person_pages b, courses c, sections d, chapters e, pages f
    where   a.person_id = b.person_id 
    and     b.course_id = c.course_id
    and     b.course_id = d.course_id and b.section_id = d.section_id
    and     b.course_id = e.course_id and b.section_id = e.section_id and b.chapter_id = e.chapter_id
    and     b.course_id = f.course_id and b.section_id = f.section_id and b.chapter_id = f.chapter_id and b.page_id = f.page_id
    and     a.status = 'Active'
    and     to_char(start_datetime,'MM-DD-YYYY') = to_char(sysdate,'MM-DD-YYYY') -- just stuff posted under today's date
    order by a.person_id;

begin

    -- put out the root tag stuff
    my_string :=    '<?xml version=' || chr(34) || '1.0' || chr(34) || '?>' ||
                    '<!-- online_training todays_date=' || chr(34) ||  to_char(sysdate,'MM-DD-YYYY') || chr(34) || ' --> ' ||
                    '<!-- chapter page count is total number of pages in a chapter --> ' ||
                    '<students>';
    insert into my_xml_fragments
        (counter, xml_fragment)
    values
        (my_counter, my_string);
    my_counter := my_counter + 1;

    open c1;
    loop
        fetch c1 into my_string, my_person_id;
        exit when c1%notfound;
        insert into my_xml_fragments
            (counter, xml_fragment)
        values
            (my_counter, my_string);
        my_counter := my_counter + 1;

        insert into my_xml_fragments
            (counter, xml_fragment)
        values
            (my_counter, '</student>');
        my_counter := my_counter + 1;

    end loop;

    -- close up those root tags
        insert into my_xml_fragments
        (counter, xml_fragment)
    values
        (my_counter, '</students>');
    my_counter := my_counter + 1;

    commit;
end;

-- iteration two is the course level tags
create or replace NONEDITIONABLE procedure create_todays_student_pages  as

    my_string       varchar(1000);
    my_counter      integer := 1;
    my_person_id    integer;
    my_course_id    integer;

    -- we only want  single copy of all students who opened a page today
    cursor c1 is
    select  distinct '<student person_id=' || chr(34) || a.person_id || chr(34) || '><first_name>' || a.first_name || 
                        '</first_name><last_name>' || a.last_name  || '</last_name>' as fragment, a.person_id
    from    persons a, person_pages b, courses c, sections d, chapters e, pages f
    where   a.person_id = b.person_id 
    and     b.course_id = c.course_id
    and     b.course_id = d.course_id and b.section_id = d.section_id
    and     b.course_id = e.course_id and b.section_id = e.section_id and b.chapter_id = e.chapter_id
    and     b.course_id = f.course_id and b.section_id = f.section_id and b.chapter_id = f.chapter_id and b.page_id = f.page_id
    and     a.status = 'Active'
    and     to_char(start_datetime,'MM-DD-YYYY') = to_char(sysdate,'MM-DD-YYYY') -- just stuff posted under today's date
    order by a.person_id;

    cursor c2 (person_id_in number) is
    select  distinct '<course course_id=' || chr(34) || c.course_id || chr(34) || '><course_name>' || c.title || '</course_name>' as fragment, 
                a.person_id, c.course_id
    from    persons a, person_pages b, courses c, sections d, chapters e, pages f
    where   a.person_id = b.person_id 
    and     b.course_id = c.course_id
    and     b.course_id = d.course_id and b.section_id = d.section_id
    and     b.course_id = e.course_id and b.section_id = e.section_id and b.chapter_id = e.chapter_id
    and     b.course_id = f.course_id and b.section_id = f.section_id and b.chapter_id = f.chapter_id and b.page_id = f.page_id
    and     a.status = 'Active'
    and     a.person_id = person_id_in
    and     to_char(start_datetime,'MM-DD-YYYY') = to_char(sysdate,'MM-DD-YYYY') -- just stuff posted under today's date
    order by a.person_id, c.course_id;

begin

    -- put out the root tag stuff
    my_string :=    '<?xml version=' || chr(34) || '1.0' || chr(34) || '?>' ||
                    '<!-- online_training todays_date=' || chr(34) ||  to_char(sysdate,'MM-DD-YYYY') || chr(34) || ' --> ' ||
                    '<!-- chapter page count is total number of pages in a chapter --> ' ||
                    '<students>';
    insert into my_xml_fragments
        (counter, xml_fragment)
    values
        (my_counter, my_string);
    my_counter := my_counter + 1;

    open c1;
    loop
        fetch c1 into my_string, my_person_id;
        exit when c1%notfound;
        insert into my_xml_fragments
            (counter, xml_fragment)
        values
            (my_counter, my_string || '<courses>');
        my_counter := my_counter + 1;

        open c2 (my_person_id);
        loop
            fetch c2 into my_string, my_person_id, my_course_id;
            exit when c2%notfound;
            
            insert into my_xml_fragments
                (counter, xml_fragment)
            values
                (my_counter, my_string || '</course>');
            my_counter := my_counter + 1;

        end loop;
        close c2;

        insert into my_xml_fragments
            (counter, xml_fragment)
        values
            (my_counter, '</courses></student>');
        my_counter := my_counter + 1;
    end loop;

    -- close up those root tags
        insert into my_xml_fragments
        (counter, xml_fragment)
    values
        (my_counter, '</students>');
    my_counter := my_counter + 1;

    commit;
end;

-- iteration three adds section tags
create or replace NONEDITIONABLE procedure create_todays_student_pages  as

    my_string       varchar(1000);
    my_counter      integer := 1;
    my_person_id    integer;
    my_course_id    integer;
    my_section_id   integer;
    
    -- we only want single copy of all students who opened a page today
    cursor c1 is
    select  distinct '<student person_id=' || chr(34) || a.person_id || chr(34) || '><first_name>' || a.first_name || 
                        '</first_name><last_name>' || a.last_name  || '</last_name>' as fragment, a.person_id
    from    persons a, person_pages b, courses c, sections d, chapters e, pages f
    where   a.person_id = b.person_id 
    and     b.course_id = c.course_id
    and     b.course_id = d.course_id and b.section_id = d.section_id
    and     b.course_id = e.course_id and b.section_id = e.section_id and b.chapter_id = e.chapter_id
    and     b.course_id = f.course_id and b.section_id = f.section_id and b.chapter_id = f.chapter_id and b.page_id = f.page_id
    and     a.status = 'Active'
    and     to_char(start_datetime,'MM-DD-YYYY') = to_char(sysdate,'MM-DD-YYYY') -- just stuff posted under today's date
    order by a.person_id;

    cursor c2 (person_id_in number) is
    select  distinct '<course course_id=' || chr(34) || c.course_id || chr(34) || '><course_name>' || c.title || 
                        '</course_name>' as fragment, a.person_id, c.course_id
    from    persons a, person_pages b, courses c, sections d, chapters e, pages f
    where   a.person_id = b.person_id 
    and     b.course_id = c.course_id
    and     b.course_id = d.course_id and b.section_id = d.section_id
    and     b.course_id = e.course_id and b.section_id = e.section_id and b.chapter_id = e.chapter_id
    and     b.course_id = f.course_id and b.section_id = f.section_id and b.chapter_id = f.chapter_id and b.page_id = f.page_id
    and     a.status = 'Active'
    and     a.person_id = person_id_in
    and     to_char(start_datetime,'MM-DD-YYYY') = to_char(sysdate,'MM-DD-YYYY') -- just stuff posted under today's date
    order by a.person_id, c.course_id;

    cursor c3 (person_id_in number, course_id_in number) is
    select  distinct '<section section_id=' || chr(34) || d.section_id || chr(34) || '><section_name>' || c.title || 
                        '</section_name></section>' as fragment, a.person_id, c.course_id, d.section_id
    from    persons a, person_pages b, courses c, sections d, chapters e, pages f
    where   a.person_id = b.person_id 
    and     b.course_id = c.course_id
    and     b.course_id = d.course_id and b.section_id = d.section_id
    and     b.course_id = e.course_id and b.section_id = e.section_id and b.chapter_id = e.chapter_id
    and     b.course_id = f.course_id and b.section_id = f.section_id and b.chapter_id = f.chapter_id and b.page_id = f.page_id
    and     a.status = 'Active'
    and     a.person_id = person_id_in
    and     c.course_id = course_id_in
    and     to_char(start_datetime,'MM-DD-YYYY') = to_char(sysdate,'MM-DD-YYYY') -- just stuff posted under today's date
    order by a.person_id, c.course_id, d.section_id;

begin

    -- put out the root tag stuff
    my_string :=    '<?xml version=' || chr(34) || '1.0' || chr(34) || '?>' ||
                    '<!-- online_training todays_date=' || chr(34) ||  to_char(sysdate,'MM-DD-YYYY') || chr(34) || ' --> ' ||
                    '<!-- chapter page count is total number of pages in a chapter --> ' ||
                    '<students>';
    insert into my_xml_fragments
        (counter, xml_fragment)
    values
        (my_counter, my_string);
    my_counter := my_counter + 1;

    open c1;
    loop
        fetch c1 into my_string, my_person_id;
        exit when c1%notfound;
        insert into my_xml_fragments
            (counter, xml_fragment)
        values
            (my_counter, my_string || '<courses>');
        my_counter := my_counter + 1;

        open c2 (my_person_id);
        loop
            fetch c2 into my_string, my_person_id, my_course_id;
            exit when c2%notfound;
            insert into my_xml_fragments
                (counter, xml_fragment)
            values
                (my_counter, my_string || '<sections>');
            my_counter := my_counter + 1;

            open c3 (my_person_id, my_course_id);
            loop
                fetch c3 into my_string, my_person_id, my_course_id, my_section_id;
                exit when c3%notfound;
                insert into my_xml_fragments
                    (counter, xml_fragment)
                values
                    (my_counter, my_string);
                my_counter := my_counter + 1;
            end loop;
            close c3;
            
            insert into my_xml_fragments
                (counter, xml_fragment)
            values
                (my_counter, '</sections></course>');
            my_counter := my_counter + 1;
        end loop;
        close c2;
        
        insert into my_xml_fragments
            (counter, xml_fragment)
        values
            (my_counter, '</courses></student>');
        my_counter := my_counter + 1;
    end loop;
    close c1;

    -- close up those root tags
    insert into my_xml_fragments
        (counter, xml_fragment)
    values
        (my_counter, '</students>');
    my_counter := my_counter + 1;

    commit;
end;

-- iteration 4 is the chapter tags
create or replace NONEDITIONABLE procedure create_todays_student_pages  as

    my_string       varchar(1000);
    my_counter      integer := 1;
    my_person_id    integer;
    my_course_id    integer;
    my_section_id   integer;
    my_chapter_id   integer;
    my_page_count   integer;
    
    -- we only want single copy of all students who opened a page today
    cursor c1 is
    select  distinct '<student person_id=' || chr(34) || a.person_id || chr(34) || '><first_name>' || a.first_name || 
                        '</first_name><last_name>' || a.last_name  || '</last_name>' as fragment, a.person_id
    from    persons a, person_pages b, courses c, sections d, chapters e, pages f
    where   a.person_id = b.person_id 
    and     b.course_id = c.course_id
    and     b.course_id = d.course_id and b.section_id = d.section_id
    and     b.course_id = e.course_id and b.section_id = e.section_id and b.chapter_id = e.chapter_id
    and     b.course_id = f.course_id and b.section_id = f.section_id and b.chapter_id = f.chapter_id and b.page_id = f.page_id
    and     a.status = 'Active'
    and     to_char(start_datetime,'MM-DD-YYYY') = to_char(sysdate,'MM-DD-YYYY') -- just stuff posted under today's date
    order by a.person_id;

    cursor c2 (person_id_in number) is
    select  distinct '<course course_id=' || chr(34) || c.course_id || chr(34) || '><course_name>' || c.title || 
                        '</course_name>' as fragment, a.person_id, c.course_id
    from    persons a, person_pages b, courses c, sections d, chapters e, pages f
    where   a.person_id = b.person_id 
    and     b.course_id = c.course_id
    and     b.course_id = d.course_id and b.section_id = d.section_id
    and     b.course_id = e.course_id and b.section_id = e.section_id and b.chapter_id = e.chapter_id
    and     b.course_id = f.course_id and b.section_id = f.section_id and b.chapter_id = f.chapter_id and b.page_id = f.page_id
    and     a.status = 'Active'
    and     a.person_id = person_id_in
    and     to_char(start_datetime,'MM-DD-YYYY') = to_char(sysdate,'MM-DD-YYYY') -- just stuff posted under today's date
    order by a.person_id, c.course_id;

    cursor c3 (person_id_in number, course_id_in number) is
    select  distinct '<section section_id=' || chr(34) || d.section_id || chr(34) || '><section_name>' || d.title || 
                        '</section_name>' as fragment, a.person_id, c.course_id, d.section_id
    from    persons a, person_pages b, courses c, sections d, chapters e, pages f
    where   a.person_id = b.person_id 
    and     b.course_id = c.course_id
    and     b.course_id = d.course_id and b.section_id = d.section_id
    and     b.course_id = e.course_id and b.section_id = e.section_id and b.chapter_id = e.chapter_id
    and     b.course_id = f.course_id and b.section_id = f.section_id and b.chapter_id = f.chapter_id and b.page_id = f.page_id
    and     a.status = 'Active'
    and     a.person_id = person_id_in
    and     c.course_id = course_id_in
    and     to_char(start_datetime,'MM-DD-YYYY') = to_char(sysdate,'MM-DD-YYYY') -- just stuff posted under today's date
    order by a.person_id, c.course_id, d.section_id;

    cursor c4 (person_id_in number, course_id_in number, section_id_in number) is
    select  distinct '<chapter chapter_id=' || chr(34) || e.chapter_id || chr(34) || '><chapter_name>' || e.title || 
                        '</chapter_name>' as fragment, a.person_id, c.course_id, d.section_id, e.chapter_id
    from    persons a, person_pages b, courses c, sections d, chapters e, pages f
    where   a.person_id = b.person_id 
    and     b.course_id = c.course_id
    and     b.course_id = d.course_id and b.section_id = d.section_id
    and     b.course_id = e.course_id and b.section_id = e.section_id and b.chapter_id = e.chapter_id
    and     b.course_id = f.course_id and b.section_id = f.section_id and b.chapter_id = f.chapter_id and b.page_id = f.page_id
    and     a.status = 'Active'
    and     a.person_id = person_id_in
    and     c.course_id = course_id_in
    and     d.section_id = section_id_in
    and     to_char(start_datetime,'MM-DD-YYYY') = to_char(sysdate,'MM-DD-YYYY') -- just stuff posted under today's date
    order by a.person_id, c.course_id, d.section_id, e.chapter_id;

begin

    -- put out the root tag stuff
    my_string :=    '<?xml version=' || chr(34) || '1.0' || chr(34) || '?>' ||
                    '<!-- online_training todays_date=' || chr(34) ||  to_char(sysdate,'MM-DD-YYYY') || chr(34) || ' --> ' ||
                    '<!-- chapter page count is total number of pages in a chapter --> ' ||
                    '<students>';
    insert into my_xml_fragments
        (counter, xml_fragment)
    values
        (my_counter, my_string);
    my_counter := my_counter + 1;

    open c1;
    loop
        fetch c1 into my_string, my_person_id;
        exit when c1%notfound;
        insert into my_xml_fragments
            (counter, xml_fragment)
        values
            (my_counter, my_string || '<courses>');
        my_counter := my_counter + 1;

        open c2 (my_person_id);
        loop
            fetch c2 into my_string, my_person_id, my_course_id;
            exit when c2%notfound;
            insert into my_xml_fragments
                (counter, xml_fragment)
            values
                (my_counter, my_string || '<sections>');
            my_counter := my_counter + 1;

            open c3 (my_person_id, my_course_id);
            loop
                fetch c3 into my_string, my_person_id, my_course_id, my_section_id;
                exit when c3%notfound;
                insert into my_xml_fragments
                    (counter, xml_fragment)
                values
                    (my_counter, my_string || '<chapters>');
                my_counter := my_counter + 1;

                open c4 (my_person_id, my_course_id, my_section_id);
                loop
                    fetch c4 into my_string, my_person_id, my_course_id, my_section_id, my_chapter_id;
                    exit when c4%notfound;
                    insert into my_xml_fragments
                        (counter, xml_fragment)
                    values
                        (my_counter, my_string);
                    my_counter := my_counter + 1;
                    
                    select  count(*) into my_page_count
                    from    pages
                    where   course_id = my_course_id
                    and     section_id = my_section_id
                    and     chapter_id = my_chapter_id;
                    
                    my_string := '<chapter_page_count>' || my_page_count || '</chapter_page_count></chapter>';
                    insert into my_xml_fragments
                        (counter, xml_fragment)
                    values
                        (my_counter, my_string);
                    my_counter := my_counter + 1;
                end loop;
                close c4;
                
                insert into my_xml_fragments
                    (counter, xml_fragment)
                values
                    (my_counter, '</chapters></section>');
                my_counter := my_counter + 1;
            end loop;
            close c3;
            
            insert into my_xml_fragments
                (counter, xml_fragment)
            values
                (my_counter, '</sections></course>');
            my_counter := my_counter + 1;
        end loop;
        close c2;
        
        insert into my_xml_fragments
            (counter, xml_fragment)
        values
            (my_counter, '</courses></student>');
        my_counter := my_counter + 1;
    end loop;
    close c1;

    -- close up those root tags
    insert into my_xml_fragments
        (counter, xml_fragment)
    values
        (my_counter, '</students>');
    my_counter := my_counter + 1;

    commit;
end;

-- iteration 5, the final cut
create or replace NONEDITIONABLE procedure create_todays_student_pages  as

    my_string       varchar(1000);
    my_counter      integer := 1;
    my_person_id    integer;
    my_course_id    integer;
    my_section_id   integer;
    my_chapter_id   integer;
    my_page_id      integer;
    my_page_count   integer;
    
    -- we only want single copy of all students who opened a page today
    cursor c1 is
    select  distinct '<student person_id=' || chr(34) || a.person_id || chr(34) || '><first_name>' || a.first_name || 
                        '</first_name><last_name>' || a.last_name  || '</last_name>' as fragment, a.person_id
    from    persons a, person_pages b, courses c, sections d, chapters e, pages f
    where   a.person_id = b.person_id 
    and     b.course_id = c.course_id
    and     b.course_id = d.course_id and b.section_id = d.section_id
    and     b.course_id = e.course_id and b.section_id = e.section_id and b.chapter_id = e.chapter_id
    and     b.course_id = f.course_id and b.section_id = f.section_id and b.chapter_id = f.chapter_id and b.page_id = f.page_id
    and     a.status = 'Active'
    and     to_char(start_datetime,'MM-DD-YYYY') = to_char(sysdate,'MM-DD-YYYY') -- just stuff posted under today's date
    order by a.person_id;

    cursor c2 (person_id_in number) is
    select  distinct '<course course_id=' || chr(34) || c.course_id || chr(34) || '><course_name>' || c.title || 
                        '</course_name>' as fragment, a.person_id, c.course_id
    from    persons a, person_pages b, courses c, sections d, chapters e, pages f
    where   a.person_id = b.person_id 
    and     b.course_id = c.course_id
    and     b.course_id = d.course_id and b.section_id = d.section_id
    and     b.course_id = e.course_id and b.section_id = e.section_id and b.chapter_id = e.chapter_id
    and     b.course_id = f.course_id and b.section_id = f.section_id and b.chapter_id = f.chapter_id and b.page_id = f.page_id
    and     a.status = 'Active'
    and     a.person_id = person_id_in
    and     to_char(start_datetime,'MM-DD-YYYY') = to_char(sysdate,'MM-DD-YYYY') -- just stuff posted under today's date
    order by a.person_id, c.course_id;

    cursor c3 (person_id_in number, course_id_in number) is
    select  distinct '<section section_id=' || chr(34) || d.section_id || chr(34) || '><section_name>' || d.title || 
                        '</section_name>' as fragment, a.person_id, c.course_id, d.section_id
    from    persons a, person_pages b, courses c, sections d, chapters e, pages f
    where   a.person_id = b.person_id 
    and     b.course_id = c.course_id
    and     b.course_id = d.course_id and b.section_id = d.section_id
    and     b.course_id = e.course_id and b.section_id = e.section_id and b.chapter_id = e.chapter_id
    and     b.course_id = f.course_id and b.section_id = f.section_id and b.chapter_id = f.chapter_id and b.page_id = f.page_id
    and     a.status = 'Active'
    and     a.person_id = person_id_in
    and     c.course_id = course_id_in
    and     to_char(start_datetime,'MM-DD-YYYY') = to_char(sysdate,'MM-DD-YYYY') -- just stuff posted under today's date
    order by a.person_id, c.course_id, d.section_id;

    cursor c4 (person_id_in number, course_id_in number, section_id_in number) is
    select  distinct '<chapter chapter_id=' || chr(34) || e.chapter_id || chr(34) || '><chapter_name>' || e.title || 
                        '</chapter_name>' as fragment, a.person_id, c.course_id, d.section_id, e.chapter_id
    from    persons a, person_pages b, courses c, sections d, chapters e, pages f
    where   a.person_id = b.person_id 
    and     b.course_id = c.course_id
    and     b.course_id = d.course_id and b.section_id = d.section_id
    and     b.course_id = e.course_id and b.section_id = e.section_id and b.chapter_id = e.chapter_id
    and     b.course_id = f.course_id and b.section_id = f.section_id and b.chapter_id = f.chapter_id and b.page_id = f.page_id
    and     a.status = 'Active'
    and     a.person_id = person_id_in
    and     c.course_id = course_id_in
    and     d.section_id = section_id_in
    and     to_char(start_datetime,'MM-DD-YYYY') = to_char(sysdate,'MM-DD-YYYY') -- just stuff posted under today's date
    order by a.person_id, c.course_id, d.section_id, e.chapter_id;

    -- the non-fragment columns are only need for order by clause
    cursor c5 (person_id_in number, course_id_in number, section_id_in number, chapter_id_in number) is
    select  '<page page_id=' || chr(34) || f.page_id || chr(34) || '><start_datetime>' || to_char(b.start_datetime,'DD-MM-YYYY HH24:MI:SS') || 
                        '</start_datetime><end_datetime>' || to_char(b.end_datetime,'DD-MM-YYYY HH24:MI:SS') || '</end_datetime></page>' as fragment, 
                        a.person_id, c.course_id, d.section_id, e.chapter_id, f.page_id
    from    persons a, person_pages b, courses c, sections d, chapters e, pages f
    where   a.person_id = b.person_id 
    and     b.course_id = c.course_id
    and     b.course_id = d.course_id and b.section_id = d.section_id
    and     b.course_id = e.course_id and b.section_id = e.section_id and b.chapter_id = e.chapter_id
    and     b.course_id = f.course_id and b.section_id = f.section_id and b.chapter_id = f.chapter_id and b.page_id = f.page_id
    and     a.status = 'Active'
    and     a.person_id = person_id_in
    and     c.course_id = course_id_in
    and     d.section_id = section_id_in
    and     e.chapter_id = chapter_id_in
    and     to_char(start_datetime,'MM-DD-YYYY') = to_char(sysdate,'MM-DD-YYYY') -- just stuff posted under today's date
    order by a.person_id, c.course_id, d.section_id, e.chapter_id, f.page_id;

begin

    -- put out the root tag stuff
    my_string :=    '<?xml version=' || chr(34) || '1.0' || chr(34) || '?>' ||
                    '<!-- online_training todays_date=' || chr(34) ||  to_char(sysdate,'MM-DD-YYYY') || chr(34) || ' --> ' ||
                    '<!-- chapter page count is total number of pages in a chapter --> ' ||
                    '<students>';
    insert into my_xml_fragments
        (counter, xml_fragment)
    values
        (my_counter, my_string);
    my_counter := my_counter + 1;

    open c1;
    loop
        fetch c1 into my_string, my_person_id;
        exit when c1%notfound;
        insert into my_xml_fragments
            (counter, xml_fragment)
        values
            (my_counter, my_string || '<courses>');
        my_counter := my_counter + 1;

        open c2 (my_person_id);
        loop
            fetch c2 into my_string, my_person_id, my_course_id;
            exit when c2%notfound;
            insert into my_xml_fragments
                (counter, xml_fragment)
            values
                (my_counter, my_string || '<sections>');
            my_counter := my_counter + 1;

            open c3 (my_person_id, my_course_id);
            loop
                fetch c3 into my_string, my_person_id, my_course_id, my_section_id;
                exit when c3%notfound;
                insert into my_xml_fragments
                    (counter, xml_fragment)
                values
                    (my_counter, my_string || '<chapters>');
                my_counter := my_counter + 1;

                open c4 (my_person_id, my_course_id, my_section_id);
                loop
                    fetch c4 into my_string, my_person_id, my_course_id, my_section_id, my_chapter_id;
                    exit when c4%notfound;
                    insert into my_xml_fragments
                        (counter, xml_fragment)
                    values
                        (my_counter, my_string);
                    my_counter := my_counter + 1;
                    
                    select  count(*) into my_page_count
                    from    pages
                    where   course_id = my_course_id
                    and     section_id = my_section_id
                    and     chapter_id = my_chapter_id;
                    
                    my_string := '<chapter_page_count>' || my_page_count || '</chapter_page_count><pages>';
                    insert into my_xml_fragments
                        (counter, xml_fragment)
                    values
                        (my_counter, my_string);
                    my_counter := my_counter + 1;
                    
                    open c5 (my_person_id, my_course_id, my_section_id, my_chapter_id);
                    loop
                        fetch c5 into my_string, my_person_id, my_course_id, my_section_id, my_chapter_id, my_page_id;
                        exit when c5%notfound;
                        insert into my_xml_fragments
                            (counter, xml_fragment)
                        values
                            (my_counter, my_string);
                        my_counter := my_counter + 1;
                    end loop;
                    close c5;
                    
                    insert into my_xml_fragments
                        (counter, xml_fragment)
                    values
                        (my_counter, '</pages></chapter>');
                    my_counter := my_counter + 1;

                end loop;
                close c4;
                
                insert into my_xml_fragments
                    (counter, xml_fragment)
                values
                    (my_counter, '</chapters></section>');
                my_counter := my_counter + 1;
            end loop;
            close c3;
            
            insert into my_xml_fragments
                (counter, xml_fragment)
            values
                (my_counter, '</sections></course>');
            my_counter := my_counter + 1;
        end loop;
        close c2;
        
        insert into my_xml_fragments
            (counter, xml_fragment)
        values
            (my_counter, '</courses></student>');
        my_counter := my_counter + 1;
    end loop;
    close c1;

    -- close up those root tags
    insert into my_xml_fragments
        (counter, xml_fragment)
    values
        (my_counter, '</students>');
    my_counter := my_counter + 1;

    commit;
end;