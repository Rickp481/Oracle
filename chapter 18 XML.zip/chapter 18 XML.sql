/****************************************************************************************************************/
/*														*/
/*	chapter 18 XML												*/
/*	Rick Phillips												*/
/*	3/28/2022												*/
/*														*/
/****************************************************************************************************************/

-- the xmlelement function
select      xmlelement("Customer Name",name) 
from        customers 
order by    customer_id;

-- now we will see what the xmltype.getclobval function does
select      xmltype.getclobval(xmlelement("Customer Name",name)) 
from        customers 
order by    customer_id;

-- how about the always interesting XMLAttributes function
select      xmltype.getclobval(xmlelement("Customer Name",
                                XMLAttributes(customer_id as "ID"),
                                name)) 
from        customers 
order by    customer_id;

-- oh, the always lovable xmlforest function
select      xmltype.getclobval(xmlforest(customer_id as "ID", name as "Name") )
from        customers 
order by    customer_id;

-- let's combine xmlelement and xmlforest funcitons with the xmltype.getclobval function
select      xmltype.getclobval(xmlelement("Customer",xmlforest(customer_id as "ID", name as "Name")))
from        customers
order by    customer_id;

-- an xml comment is self defining, xml processing instructions tell the receiving application
-- how to process subsequent information; e.g. cascading style sheet for browser display
select  xmltype.getclobval(xmlpi(name "PI Target", 'this is a processing instruction')),
        xmltype.getclobval(xmlcomment('This is an XML comment'))
from dual;

-- let's alter our database to add a table to store student online learning activity as
-- associated with our example XML file
create table person_pages
(person_id      integer,
 course_id      integer,
 section_id     integer,
 chapter_id     integer,
 page_id        integer,
 start_datetime date,
 end_datetime   date,
 constraint person_pages_pk primary key (course_id, section_id, chapter_id, page_id, person_id),
 constraint person_pages_fk0 foreign key (course_id, section_id, chapter_id, page_id) references
    pages(course_id, section_id, chapter_id, page_id),
 constraint person_pages_fk1 foreign key (person_id) references persons(person_id));

-- populate that table
insert into person_pages
    (person_id, course_id, section_id, chapter_id, page_id, start_datetime, end_datetime)
values
    (3, 1, 1, 1, 1, to_date('28-03-2022 09:56:07','DD-MM-YYYY HH24:MI:SS'),to_date('28-03-2022 09:58:37','DD-MM-YYYY HH24:MI:SS'));
insert into person_pages
    (person_id, course_id, section_id, chapter_id, page_id, start_datetime, end_datetime)
values
    (3, 1, 1, 1, 2, to_date('28-03-2022 09:58:38','DD-MM-YYYY HH24:MI:SS'),to_date('28-03-2022 10:00:21','DD-MM-YYYY HH24:MI:SS'));
 insert into person_pages
    (person_id, course_id, section_id, chapter_id, page_id, start_datetime)
values
    (3, 1, 1, 1, 3, to_date('28-03-2022 10:00:24','DD-MM-YYYY HH24:MI:SS'));
insert into person_pages
    (person_id, course_id, section_id, chapter_id, page_id, start_datetime)
values
    (4, 1, 1, 1, 1, to_date('28-03-2022 09:56:07','DD-MM-YYYY HH24:MI:SS'));
commit;

-- now back as online_training_testing
create table my_clob_table (my_xml_clob clob, counter integer);

-- now we start to play with the xmlgen package
-- which very quickly runs out of gas on nested 1:M relationships
declare

    QueryContext        dbms_xmlgen.ctxhandle;
    my_clob             clob;
    
begin

    -- assign a select statement to our context handle
    QueryContext := dbms_xmlgen.newcontext ('select * from customers');
    
    -- retrieve the xml to a local clob   
    my_clob := dbms_xmlgen.getxml(QueryContext);

    -- insert that clob to our new table
    insert into my_clob_table (my_xml_clob, counter)
    values (my_clob, 1);
    
    -- release the context handle
    dbms_xmlgen.closecontext (QueryContext);

end;

select my_xml_clob from my_clob_table;

-- before we change to simple select approach let's get that clob
-- out of the picture
drop table my_clob_table;
create table my_xml_fragments 
(counter	integer,
 xml_frament	varchar(1000),
 constraint my_xml_framents_pk primary key (counter));

-- iteration one of nested cursor approach
-- very straight forward and easy to maintain
create or replace procedure create_todays_student_pages  as

    my_fragment     clob;
    my_counter      integer := 1;
    my_person_id    integer;
    my_string      varchar2(200);

    -- we only want those students
    cursor c1 is
    select  distinct '<student person_id=' || chr(34) || a.person_id || chr(34) || '><first_name>' || a.first_name || 
                        '</first_name><last_name>' || a.last_name  || '</last_name>' as fragment, a.person_id
    from    persons a, person_pages b, courses c, sections d, chapters e, pages f
    where   a.person_id = b.person_id 
    and     b.course_id = c.course_id
    and     b.course_id = d.course_id and b.section_id = d.section_id
    and     b.course_id = e.course_id and b.section_id = e.section_id and b.chapter_id = e.chapter_id
    and     b.course_id = f.course_id and b.section_id = f.section_id and b.chapter_id = f.chapter_id and b.page_id = f.page_id
    and     a.status = 'Active'
    and     to_char(start_datetime,'MM-DD-YYYY') = to_char(sysdate,'MM-DD-YYYY') -- just stuff posted under today's date
    order by a.person_id;

    type c1_table_type is table of c1%rowtype index by binary_integer;
    c1_table        c1_table_type;
    
begin

    my_string :=  '<?xml version=' || chr(34) || '1.0' || chr(34) || '?><online_training todays_date=' 
                    || chr(34) ||  to_char(sysdate,'MM-DD-YYYY') || chr(34) || '><students>';
    -- put out the root tag stuff
    insert into my_clob_table
        (my_xml_clob, counter)
    values
        (to_clob(my_string), my_counter);
    my_counter := my_counter + 1;
        
    open c1;
    fetch c1 bulk collect into c1_table;  -- do not switch between pl/sql and sql engines
    for lcv in 1..c1_table.count 
    loop
        insert into my_clob_table (my_xml_clob, counter)
        values (to_clob(c1_table(lcv).fragment), my_counter);
        my_counter := my_counter + 1;

        -- this is where we will next c2 stuff
        
        insert into my_clob_table (my_xml_clob, counter)
        values (to_clob('</student>'), my_counter);
        my_counter := my_counter + 1;
    end loop;
    close c1;

    -- put out the closing root tags
    insert into my_clob_table
        (my_xml_clob, counter)
    values
        ('</students></online_training>', my_counter);
        my_counter := my_counter + 1;

    commit;
end;

-- iteration two is course level tags
create or replace NONEDITIONABLE procedure create_todays_student_pages as

    my_fragment     varchar(1000);
    my_counter      integer := 1;
    my_person_id    integer;
    my_course_id    integer;
    my_string      varchar2(200);

    -- we only want those students with pages on specified date so we need the distinct at this point
    cursor c1 is
    select  distinct '<student person_id=' || chr(34) || a.person_id || chr(34) || '><first_name>' || a.first_name || 
                        '</first_name><last_name>' || a.last_name  || '</last_name>' as fragment, a.person_id
    from    persons a, person_pages b, courses c, sections d, chapters e, pages f
    where   a.person_id = b.person_id 
    and     b.course_id = c.course_id
    and     b.course_id = d.course_id and b.section_id = d.section_id
    and     b.course_id = e.course_id and b.section_id = e.section_id and b.chapter_id = e.chapter_id
    and     b.course_id = f.course_id and b.section_id = f.section_id and b.chapter_id = f.chapter_id and b.page_id = f.page_id
    and     a.status = 'Active'
    and     to_char(start_datetime,'MM-DD-YYYY') = to_char(sysdate,'MM-DD-YYYY') -- just stuff posted on input date
    order by a.person_id;

    cursor c2 (person_id_in  number) is
    select  distinct '<course course_id=' || chr(34) || c.course_id || chr(34) || '><course_name>' || c.title || '</course_name>' 
                as fragment, a.person_id, c.course_id
    from    persons a, person_pages b, courses c, sections d, chapters e, pages f
    where   a.person_id = b.person_id 
    and     b.course_id = c.course_id
    and     b.course_id = d.course_id and b.section_id = d.section_id
    and     b.course_id = e.course_id and b.section_id = e.section_id and b.chapter_id = e.chapter_id
    and     b.course_id = f.course_id and b.section_id = f.section_id and b.chapter_id = f.chapter_id and b.page_id = f.page_id
    and     a.status = 'Active'
    and     a.person_id = person_id_in
    and     to_char(start_datetime,'MM-DD-YYYY') = to_char(sysdate,'MM-DD-YYYY') -- just stuff posted on input date
    order by a.person_id, c.course_id;

begin

    my_string :=  '<?xml version=' || chr(34) || '1.0' || chr(34) || '?><!-- online_training todays_date=' 
                    || chr(34) ||  to_char(sysdate,'MM-DD-YYYY') || chr(34) || ' --><students>';
    -- put out the root tag stuff
    insert into my_xml_fragments
        (counter, xml_fragment)
    values
        (my_counter, my_string);
    my_counter := my_counter + 1;

    open c1;
    loop
        fetch c1 into my_fragment, my_person_id;
        exit when c1%notfound;

        insert into my_xml_fragments
            (counter, xml_fragment)
        values
            (my_counter, my_fragment || '<courses>');
        my_counter := my_counter + 1;

        -- this is where we will nest c2 loop
        open c2 (my_person_id);
        loop
            fetch c2 into my_fragment, my_person_id, my_course_id;
            exit when c2%notfound;
            
            insert into my_xml_fragments
                (counter, xml_fragment)
            values
                (my_counter, my_fragment);
            my_counter := my_counter + 1;

            insert into my_xml_fragments
                (counter, xml_fragment)
            values 
                (my_counter, '</course>');
            my_counter := my_counter + 1;
        end loop;
        close c2;
        
        insert into my_xml_fragments
            (counter, xml_fragment)
        values 
            (my_counter, '</courses></student>');
        my_counter := my_counter + 1;
    end loop;
    close c1;

    -- put out the closing root tag stuff
    insert into my_xml_fragments
        (counter, xml_fragment)
    values
        (my_counter,'</students>');
        my_counter := my_counter + 1;

    commit;
end;

create or replace NONEDITIONABLE procedure create_todays_student_pages as

    my_fragment     varchar(1000);
    my_counter      integer := 1;
    my_person_id    integer;
    my_course_id    integer;
    my_section_id   integer;
    my_string      varchar2(200);

    -- we only want those students with pages on specified date so we need the distinct at this point
    cursor c1 is
    select  distinct '<student person_id=' || chr(34) || a.person_id || chr(34) || '><first_name>' || a.first_name || 
                        '</first_name><last_name>' || a.last_name  || '</last_name>' as fragment, a.person_id
    from    persons a, person_pages b, courses c, sections d, chapters e, pages f
    where   a.person_id = b.person_id 
    and     b.course_id = c.course_id
    and     b.course_id = d.course_id and b.section_id = d.section_id
    and     b.course_id = e.course_id and b.section_id = e.section_id and b.chapter_id = e.chapter_id
    and     b.course_id = f.course_id and b.section_id = f.section_id and b.chapter_id = f.chapter_id and b.page_id = f.page_id
    and     a.status = 'Active'
    and     to_char(start_datetime,'MM-DD-YYYY') = to_char(sysdate,'MM-DD-YYYY') -- just stuff posted on input date
    order by a.person_id;

    cursor c2 (person_id_in  number) is
    select  distinct '<course course_id=' || chr(34) || c.course_id || chr(34) || '><course_name>' || c.title || '</course_name>' 
                as fragment, a.person_id, c.course_id
    from    persons a, person_pages b, courses c, sections d, chapters e, pages f
    where   a.person_id = b.person_id 
    and     b.course_id = c.course_id
    and     b.course_id = d.course_id and b.section_id = d.section_id
    and     b.course_id = e.course_id and b.section_id = e.section_id and b.chapter_id = e.chapter_id
    and     b.course_id = f.course_id and b.section_id = f.section_id and b.chapter_id = f.chapter_id and b.page_id = f.page_id
    and     a.status = 'Active'
    and     a.person_id = person_id_in
    and     to_char(start_datetime,'MM-DD-YYYY') = to_char(sysdate,'MM-DD-YYYY') -- just stuff posted on input date
    order by a.person_id, c.course_id;

    cursor c3 (person_id_in  number, course_id_in number) is
    select  distinct '<section section_id=' || chr(34) || d.section_id || chr(34) || '><section_name>' || d.title || '</section_name>' 
                as fragment, a.person_id, c.course_id, d.section_id
    from    persons a, person_pages b, courses c, sections d, chapters e, pages f
    where   a.person_id = b.person_id 
    and     b.course_id = c.course_id
    and     b.course_id = d.course_id and b.section_id = d.section_id
    and     b.course_id = e.course_id and b.section_id = e.section_id and b.chapter_id = e.chapter_id
    and     b.course_id = f.course_id and b.section_id = f.section_id and b.chapter_id = f.chapter_id and b.page_id = f.page_id
    and     a.status = 'Active'
    and     a.person_id = person_id_in
    and     c.course_id = course_id_in
    and     to_char(start_datetime,'MM-DD-YYYY') = to_char(sysdate,'MM-DD-YYYY') -- just stuff posted on input date
    order by a.person_id, c.course_id, d.section_id;

begin

    my_string :=  '<?xml version=' || chr(34) || '1.0' || chr(34) || '?><!-- online_training todays_date=' 
                    || chr(34) ||  to_char(sysdate,'MM-DD-YYYY') || chr(34) || ' --><students>';
    -- put out the root tag stuff
    insert into my_xml_fragments
        (counter, xml_fragment)
    values
        (my_counter, my_string);
    my_counter := my_counter + 1;

    open c1;
    loop
        fetch c1 into my_fragment, my_person_id;
        exit when c1%notfound;

        insert into my_xml_fragments
            (counter, xml_fragment)
        values
            (my_counter, my_fragment || '<courses>');
        my_counter := my_counter + 1;

        -- this is where we will nest c2 loop
        open c2 (my_person_id);
        loop
            fetch c2 into my_fragment, my_person_id, my_course_id;
            exit when c2%notfound;
            
            insert into my_xml_fragments
                (counter, xml_fragment)
            values
                (my_counter, my_fragment);
            my_counter := my_counter + 1;
            
            insert into my_xml_fragments
                (counter, xml_fragment)
            values
                (my_counter, '<sections>');
            my_counter := my_counter + 1;

            -- this is where we insert iteration the section info tags
            open c3 (my_person_id, my_course_id);
            loop
                fetch c3 into my_fragment, my_person_id, my_course_id, my_section_id;
                exit when c3%notfound;
            
                insert into my_xml_fragments
                    (counter, xml_fragment)
                values
                    (my_counter, my_fragment);
                my_counter := my_counter + 1;
            
                insert into my_xml_fragments
                    (counter, xml_fragment)
                values 
                    (my_counter, '</section>');
                my_counter := my_counter + 1;
            end loop;
            close c3;

            insert into my_xml_fragments
                (counter, xml_fragment)
            values 
                (my_counter, '</sections></course>');
            my_counter := my_counter + 1;
        end loop;
        close c2;
        
        insert into my_xml_fragments
            (counter, xml_fragment)
        values 
            (my_counter, '</courses></student>');
        my_counter := my_counter + 1;
    end loop;
    close c1;

    -- put out the closing root tag stuff
    insert into my_xml_fragments
        (counter, xml_fragment)
    values
        (my_counter,'</students>');
        my_counter := my_counter + 1;

    commit;
end;

-- iteration 4
create or replace NONEDITIONABLE procedure create_todays_student_pages as

    my_fragment     varchar(1000);
    my_counter      integer := 1;
    my_person_id    integer;
    my_course_id    integer;
    my_section_id   integer;
    my_chapter_id   integer;
    my_string      varchar2(200);

    -- we only want those students with pages on specified date so we need the distinct at this point
    cursor c1 is
    select  distinct '<student person_id=' || chr(34) || a.person_id || chr(34) || '><first_name>' || a.first_name || 
                        '</first_name><last_name>' || a.last_name  || '</last_name>' as fragment, a.person_id
    from    persons a, person_pages b, courses c, sections d, chapters e, pages f
    where   a.person_id = b.person_id 
    and     b.course_id = c.course_id
    and     b.course_id = d.course_id and b.section_id = d.section_id
    and     b.course_id = e.course_id and b.section_id = e.section_id and b.chapter_id = e.chapter_id
    and     b.course_id = f.course_id and b.section_id = f.section_id and b.chapter_id = f.chapter_id and b.page_id = f.page_id
    and     a.status = 'Active'
    and     to_char(start_datetime,'MM-DD-YYYY') = to_char(sysdate,'MM-DD-YYYY') -- just stuff posted on input date
    order by a.person_id;

    cursor c2 (person_id_in  number) is
    select  distinct '<course course_id=' || chr(34) || c.course_id || chr(34) || '><course_name>' || c.title || '</course_name>' 
                as fragment, a.person_id, c.course_id
    from    persons a, person_pages b, courses c, sections d, chapters e, pages f
    where   a.person_id = b.person_id 
    and     b.course_id = c.course_id
    and     b.course_id = d.course_id and b.section_id = d.section_id
    and     b.course_id = e.course_id and b.section_id = e.section_id and b.chapter_id = e.chapter_id
    and     b.course_id = f.course_id and b.section_id = f.section_id and b.chapter_id = f.chapter_id and b.page_id = f.page_id
    and     a.status = 'Active'
    and     a.person_id = person_id_in
    and     to_char(start_datetime,'MM-DD-YYYY') = to_char(sysdate,'MM-DD-YYYY') -- just stuff posted on input date
    order by a.person_id, c.course_id;

    cursor c3 (person_id_in  number, course_id_in number) is
    select  distinct '<section section_id=' || chr(34) || d.section_id || chr(34) || '><section_name>' || d.title || '</section_name>' 
                as fragment, a.person_id, c.course_id, d.section_id
    from    persons a, person_pages b, courses c, sections d, chapters e, pages f
    where   a.person_id = b.person_id 
    and     b.course_id = c.course_id
    and     b.course_id = d.course_id and b.section_id = d.section_id
    and     b.course_id = e.course_id and b.section_id = e.section_id and b.chapter_id = e.chapter_id
    and     b.course_id = f.course_id and b.section_id = f.section_id and b.chapter_id = f.chapter_id and b.page_id = f.page_id
    and     a.status = 'Active'
    and     a.person_id = person_id_in
    and     c.course_id = course_id_in
    and     to_char(start_datetime,'MM-DD-YYYY') = to_char(sysdate,'MM-DD-YYYY') -- just stuff posted on input date
    order by a.person_id, c.course_id, d.section_id;

    cursor c4 (person_id_in  number, course_id_in number, section_id_in number) is
    select  distinct '<chapter chapter_id=' || chr(34) || e.chapter_id || chr(34) || '><chapter_name>' || e.title || '</chapter_name>' 
                as fragment, a.person_id, c.course_id, d.section_id, e.chapter_id
    from    persons a, person_pages b, courses c, sections d, chapters e, pages f
    where   a.person_id = b.person_id 
    and     b.course_id = c.course_id
    and     b.course_id = d.course_id and b.section_id = d.section_id
    and     b.course_id = e.course_id and b.section_id = e.section_id and b.chapter_id = e.chapter_id
    and     b.course_id = f.course_id and b.section_id = f.section_id and b.chapter_id = f.chapter_id and b.page_id = f.page_id
    and     a.status = 'Active'
    and     a.person_id = person_id_in
    and     c.course_id = course_id_in
    and     d.section_id = section_id_in
    and     to_char(start_datetime,'MM-DD-YYYY') = to_char(sysdate,'MM-DD-YYYY') -- just stuff posted on input date
    order by a.person_id, c.course_id, d.section_id, e.chapter_id;

begin

    my_string :=  '<?xml version=' || chr(34) || '1.0' || chr(34) || '?><!-- online_training todays_date=' 
                    || chr(34) ||  to_char(sysdate,'MM-DD-YYYY') || chr(34) || ' --><students>';
    -- put out the root tag stuff
    insert into my_xml_fragments
        (counter, xml_fragment)
    values
        (my_counter, my_string);
    my_counter := my_counter + 1;

    open c1;
    loop
        fetch c1 into my_fragment, my_person_id;
        exit when c1%notfound;

        insert into my_xml_fragments
            (counter, xml_fragment)
        values
            (my_counter, my_fragment || '<courses>');
        my_counter := my_counter + 1;

        -- this is where we will nest c2 loop
        open c2 (my_person_id);
        loop
            fetch c2 into my_fragment, my_person_id, my_course_id;
            exit when c2%notfound;
            
            insert into my_xml_fragments
                (counter, xml_fragment)
            values
                (my_counter, my_fragment);
            my_counter := my_counter + 1;
            
            insert into my_xml_fragments
                (counter, xml_fragment)
            values
                (my_counter, '<sections>');
            my_counter := my_counter + 1;

            -- this is where we insert iteration 3 the section info tags
            open c3 (my_person_id, my_course_id);
            loop
                fetch c3 into my_fragment, my_person_id, my_course_id, my_section_id;
                exit when c3%notfound;
            
                insert into my_xml_fragments
                    (counter, xml_fragment)
                values
                    (my_counter, my_fragment);
                my_counter := my_counter + 1;
            
                insert into my_xml_fragments
                    (counter, xml_fragment)
                values 
                    (my_counter, '<chapters>');
                my_counter := my_counter + 1;

                open c4 (my_person_id, my_course_id, my_section_id);
                loop
                    fetch c4 into my_fragment, my_person_id, my_course_id, my_section_id, my_chapter_id;
                    exit when c4%notfound;
            
                    insert into my_xml_fragments
                        (counter, xml_fragment)
                    values
                        (my_counter, my_fragment);
                    my_counter := my_counter + 1;
            
                    insert into my_xml_fragments
                        (counter, xml_fragment)
                    values 
                        (my_counter, '</chapter>');
                    my_counter := my_counter + 1;
                end loop;
                close c4;
                
                insert into my_xml_fragments
                    (counter, xml_fragment)
                values 
                    (my_counter, '</chapters></section>');
                my_counter := my_counter + 1;

            end loop;
            close c3;

            insert into my_xml_fragments
                (counter, xml_fragment)
            values 
                (my_counter, '</sections></course>');
            my_counter := my_counter + 1;
        end loop;
        close c2;
        
        insert into my_xml_fragments
            (counter, xml_fragment)
        values 
            (my_counter, '</courses></student>');
        my_counter := my_counter + 1;
    end loop;
    close c1;

    -- put out the closing root tag stuff
    insert into my_xml_fragments
        (counter, xml_fragment)
    values
        (my_counter,'</students>');
        my_counter := my_counter + 1;

    commit;
end;

-- fifth and final iteration
create or replace NONEDITIONABLE procedure create_todays_student_pages as

    my_fragment     varchar(1000);
    my_counter      integer := 1;
    my_person_id    integer;
    my_course_id    integer;
    my_section_id   integer;
    my_chapter_id   integer;
    my_page_id      integer;
    my_string       varchar2(200);

    -- we only want those students with pages on specified date so we need the distinct at this point
    cursor c1 is
    select  distinct '<student person_id=' || chr(34) || a.person_id || chr(34) || '><first_name>' || a.first_name || 
                        '</first_name><last_name>' || a.last_name  || '</last_name>' as fragment, a.person_id
    from    persons a, person_pages b, courses c, sections d, chapters e, pages f
    where   a.person_id = b.person_id 
    and     b.course_id = c.course_id
    and     b.course_id = d.course_id and b.section_id = d.section_id
    and     b.course_id = e.course_id and b.section_id = e.section_id and b.chapter_id = e.chapter_id
    and     b.course_id = f.course_id and b.section_id = f.section_id and b.chapter_id = f.chapter_id and b.page_id = f.page_id
    and     a.status = 'Active'
    and     to_char(start_datetime,'MM-DD-YYYY') = to_char(sysdate,'MM-DD-YYYY') -- just stuff posted on input date
    order by a.person_id;

    cursor c2 (person_id_in  number) is
    select  distinct '<course course_id=' || chr(34) || c.course_id || chr(34) || '><course_name>' || c.title || '</course_name>' 
                as fragment, a.person_id, c.course_id
    from    persons a, person_pages b, courses c, sections d, chapters e, pages f
    where   a.person_id = b.person_id 
    and     b.course_id = c.course_id
    and     b.course_id = d.course_id and b.section_id = d.section_id
    and     b.course_id = e.course_id and b.section_id = e.section_id and b.chapter_id = e.chapter_id
    and     b.course_id = f.course_id and b.section_id = f.section_id and b.chapter_id = f.chapter_id and b.page_id = f.page_id
    and     a.status = 'Active'
    and     a.person_id = person_id_in
    and     to_char(start_datetime,'MM-DD-YYYY') = to_char(sysdate,'MM-DD-YYYY') -- just stuff posted on input date
    order by a.person_id, c.course_id;

    cursor c3 (person_id_in  number, course_id_in number) is
    select  distinct '<section section_id=' || chr(34) || d.section_id || chr(34) || '><section_name>' || d.title || '</section_name>' 
                as fragment, a.person_id, c.course_id, d.section_id
    from    persons a, person_pages b, courses c, sections d, chapters e, pages f
    where   a.person_id = b.person_id 
    and     b.course_id = c.course_id
    and     b.course_id = d.course_id and b.section_id = d.section_id
    and     b.course_id = e.course_id and b.section_id = e.section_id and b.chapter_id = e.chapter_id
    and     b.course_id = f.course_id and b.section_id = f.section_id and b.chapter_id = f.chapter_id and b.page_id = f.page_id
    and     a.status = 'Active'
    and     a.person_id = person_id_in
    and     c.course_id = course_id_in
    and     to_char(start_datetime,'MM-DD-YYYY') = to_char(sysdate,'MM-DD-YYYY') -- just stuff posted on input date
    order by a.person_id, c.course_id, d.section_id;

    cursor c4 (person_id_in  number, course_id_in number, section_id_in number) is
    select  distinct '<chapter chapter_id=' || chr(34) || e.chapter_id || chr(34) || '><chapter_name>' || e.title || '</chapter_name>' 
                as fragment, a.person_id, c.course_id, d.section_id, e.chapter_id
    from    persons a, person_pages b, courses c, sections d, chapters e, pages f
    where   a.person_id = b.person_id 
    and     b.course_id = c.course_id
    and     b.course_id = d.course_id and b.section_id = d.section_id
    and     b.course_id = e.course_id and b.section_id = e.section_id and b.chapter_id = e.chapter_id
    and     b.course_id = f.course_id and b.section_id = f.section_id and b.chapter_id = f.chapter_id and b.page_id = f.page_id
    and     a.status = 'Active'
    and     a.person_id = person_id_in
    and     c.course_id = course_id_in
    and     d.section_id = section_id_in
    and     to_char(start_datetime,'MM-DD-YYYY') = to_char(sysdate,'MM-DD-YYYY') -- just stuff posted on input date
    order by a.person_id, c.course_id, d.section_id, e.chapter_id;

    cursor c5 (person_id_in  number, course_id_in number, section_id_in number, chapter_id_in number) is
    select  '<page page_id=' || chr(34) || f.page_id || chr(34) || '><start_datetime>' || to_char(b.start_datetime,'DD-MM-YYYY HH24-MI-SS') || '</start_datetime>' ||
                '<end_datetime>'|| to_char(b.end_datetime,'DD-MM-YYYY HH24-MI-SS') || '</end_datetime>' 
                as fragment, a.person_id, c.course_id, d.section_id, e.chapter_id, f.page_id -- we need to include these for the order by clause
    from    persons a, person_pages b, courses c, sections d, chapters e, pages f
    where   a.person_id = b.person_id 
    and     b.course_id = c.course_id
    and     b.course_id = d.course_id and b.section_id = d.section_id
    and     b.course_id = e.course_id and b.section_id = e.section_id and b.chapter_id = e.chapter_id
    and     b.course_id = f.course_id and b.section_id = f.section_id and b.chapter_id = f.chapter_id and b.page_id = f.page_id
    and     a.status = 'Active'
    and     a.person_id = person_id_in
    and     c.course_id = course_id_in
    and     d.section_id = section_id_in
    and     e.chapter_id = chapter_id_in
    and     to_char(start_datetime,'MM-DD-YYYY') = to_char(sysdate,'MM-DD-YYYY') -- just stuff posted on input date
    order by a.person_id, c.course_id, d.section_id, e.chapter_id, f.page_id;

begin

    my_string :=  '<?xml version=' || chr(34) || '1.0' || chr(34) || '?><!-- online_training todays_date=' 
                    || chr(34) ||  to_char(sysdate,'MM-DD-YYYY') || chr(34) || ' --><students>';
    -- put out the root tag stuff
    insert into my_xml_fragments
        (counter, xml_fragment)
    values
        (my_counter, my_string);
    my_counter := my_counter + 1;

    open c1;
    loop
        fetch c1 into my_fragment, my_person_id;
        exit when c1%notfound;

        insert into my_xml_fragments
            (counter, xml_fragment)
        values
            (my_counter, my_fragment || '<courses>');
        my_counter := my_counter + 1;

        -- this is where we will nest c2 loop
        open c2 (my_person_id);
        loop
            fetch c2 into my_fragment, my_person_id, my_course_id;
            exit when c2%notfound;
            
            insert into my_xml_fragments
                (counter, xml_fragment)
            values
                (my_counter, my_fragment);
            my_counter := my_counter + 1;
            
            insert into my_xml_fragments
                (counter, xml_fragment)
            values
                (my_counter, '<sections>');
            my_counter := my_counter + 1;

            -- this is where we insert iteration 3 the section info tags
            open c3 (my_person_id, my_course_id);
            loop
                fetch c3 into my_fragment, my_person_id, my_course_id, my_section_id;
                exit when c3%notfound;
            
                insert into my_xml_fragments
                    (counter, xml_fragment)
                values
                    (my_counter, my_fragment);
                my_counter := my_counter + 1;
            
                insert into my_xml_fragments
                    (counter, xml_fragment)
                values 
                    (my_counter, '<chapters>');
                my_counter := my_counter + 1;

                open c4 (my_person_id, my_course_id, my_section_id);
                loop
                    fetch c4 into my_fragment, my_person_id, my_course_id, my_section_id, my_chapter_id;
                    exit when c4%notfound;
            
                    insert into my_xml_fragments
                        (counter, xml_fragment)
                    values
                        (my_counter, my_fragment || '<pages>');
                    my_counter := my_counter + 1;
            
                    open c5 (my_person_id, my_course_id, my_section_id, my_chapter_id);
                    loop
                        fetch c5 into my_fragment, my_person_id, my_course_id, my_section_id, my_chapter_id, my_page_id;
                        exit when c5%notfound;
            
                        insert into my_xml_fragments
                            (counter, xml_fragment)
                        values
                            (my_counter, my_fragment || '</page>');
                        my_counter := my_counter + 1;
            
                    end loop;
                    close c5;
                    
                    insert into my_xml_fragments
                        (counter, xml_fragment)
                    values 
                        (my_counter, '</pages></chapter>');
                    my_counter := my_counter + 1;
                end loop;
                close c4;
                
                insert into my_xml_fragments
                    (counter, xml_fragment)
                values 
                    (my_counter, '</chapters></section>');
                my_counter := my_counter + 1;

            end loop;
            close c3;

            insert into my_xml_fragments
                (counter, xml_fragment)
            values 
                (my_counter, '</sections></course>');
            my_counter := my_counter + 1;
        end loop;
        close c2;
        
        insert into my_xml_fragments
            (counter, xml_fragment)
        values 
            (my_counter, '</courses></student>');
        my_counter := my_counter + 1;
    end loop;
    close c1;

    -- put out the closing root tag stuff
    insert into my_xml_fragments
        (counter, xml_fragment)
    values
        (my_counter,'</students>');
        my_counter := my_counter + 1;

    commit;
end;
