/********************************************************************************/
/*										*/
/*	Rick Phillips								*/
/*	Chapter 17 Packages							*/
/*	2/28/2022								*/
/*										*/
/********************************************************************************/
		
-- start with our function from chapter 16
create or replace package new_student as

    function calc_password_strength(user_password varchar default 'nogood') return integer;
    
end new_student;

-- and its associated package body
create or replace package body new_student as

    -- this is our function from chapter 16
    function calc_password_strength
        (user_password  in      varchar default 'nogood')
        return          integer     -- 0 through 100 inclusive wwith 100 max strength
        as
    
        type my_array is table of char(1) index by binary_integer;
        my_symbols      my_array;
        my_uletters     my_array;
        my_lletters     my_array;
        my_digits       my_array;

        my_symbol_count     integer := 0;
        my_uletter_count    integer := 0;
        my_lletter_count    integer := 0;
        my_digits_count     integer := 0;

        -- in our overloaded version of this function we will return this structure as an out parm
        type my_issues_table is table of varchar(200) index by binary_integer;
        my_issues           my_issues_table;
        my_issue_count      integer := 0;

        password_score      integer := 0;

        function test_for_gt_or_lt
            (user_password in   varchar)
            return boolean
            is
            found_one   boolean := false;
        begin
            for lcv in 1.. length(user_password) loop
                if substr(user_password, lcv, 1) = chr(60) or  -- ASCII <
                   substr(user_password, lcv, 1) = chr(62) then  -- ASCII >
                    found_one := true;
                end if;
            end loop;
            return found_one;
        end test_for_gt_or_lt;

        function test_for_symbol
            (user_password in   varchar)
            return boolean
            is
            symbol_found    boolean := false;
        begin
            for lcv1 in 1 .. my_symbol_count loop
                for lcv2 in 1 .. length(user_password) loop
                    if substr(user_password, lcv2, 1) = my_symbols(lcv1) then
                        symbol_found := true;
                    end if;
                end loop;
            end loop;
            return symbol_found;
        end test_for_symbol;

        function test_for_char_and_digit
            (user_password in   varchar)
            return boolean
            is
            char_found      boolean := false;
            digit_found     boolean := false;
        begin
            for lcv1 in 1 .. my_uletter_count loop
                for lcv2 in 1 .. length(user_password) loop
                    if (substr(user_password, lcv2, 1) = my_uletters(lcv1)) or
                        (substr(user_password, lcv2, 1) = my_lletters(lcv1)) then
                        char_found := true;
                    end if;
                end loop;
            end loop;

            for lcv1 in 1 .. my_digits_count loop
                for lcv2 in 1 .. length(user_password) loop
                    if substr(user_password, lcv2, 1) = my_digits(lcv1) then
                        digit_found := true;
                    end if;
                end loop;
            end loop;

            if digit_found and char_found then
                return true;
            else
                return false;
            end if;
        end test_for_char_and_digit;

        function test_for_upper_and_lower
            (user_password  in  varchar)
            return boolean
            is
            upper_found     boolean := false;
            lower_found     boolean := false;
        begin
            for lcv1 in 1 .. my_uletter_count loop  -- for each upper case letter
                for lcv2 in 1 .. length(user_password) loop -- for each letter in the password
                    if (substr(user_password, lcv2, 1) = my_uletters(lcv1)) then
                        -- if this upper case letter matches this character in the password
                        upper_found := true;    -- flag the ccondition as having been met
                    end if;
                end loop;
            end loop;

            for lcv1 in 1 .. my_lletter_count loop  -- for each lower case letter
                for lcv2 in 1 .. length(user_password) loop -- for each letter in the password
                    if (substr(user_password, lcv2, 1) = my_lletters(lcv1)) then
                        -- if this lower case letter matches this character in the password
                        lower_found := true;    -- flag the ccondition as having been met
                    end if;
                end loop;
            end loop;

            if upper_found and lower_found then
                return true;
            else
                return false;
            end if;
        end test_for_upper_and_lower;

       procedure check_length 
            (user_password  in  varchar)
        is
            -- this routine checks whether passsword length is accceptable; i.e. GE 8
            -- if not score zero and post an issue to the my_issues table
            -- if acceptable then score 15 plus one for each additional character length
            password_length integer;
        begin
            -- determine the length of the potential password
            select length(user_password) into password_length from dual;
            -- score that length
            if password_length < 8 then
                -- password is too short
                my_issue_count := my_issue_count + 1;
                my_issues(my_issue_count) := 'Password is too short.';
            else
                password_score := password_score + 15 + length(user_password) - 8;
            end if;
        end;

        procedure populate_arrays is
        begin
            -- keyboard symbols are ASCII 33 through 47 and 91 through 95 and 123 through 126
            for lcv in 33 .. 47 loop
                my_symbol_count := my_symbol_count + 1;
                my_symbols(my_symbol_count) := chr(lcv); 
            end loop;
            for lcv in 91 .. 95 loop
                my_symbol_count := my_symbol_count + 1;
                my_symbols(my_symbol_count) := chr(lcv); 
            end loop;
            for lcv in 123 .. 126 loop
                my_symbol_count := my_symbol_count + 1;
                my_symbols(my_symbol_count) := chr(lcv); 
            end loop;
            -- upper case letters are ASCII 65 through 90
            for lcv in 65 .. 90 loop
                my_uletter_count := lcv - 64;
                my_uletters(my_uletter_count) := chr(lcv);
            end loop;
            -- lower case letters are ASCII 97 through 122
            for lcv in 97 .. 122 loop
                my_lletter_count := my_lletter_count + 1;
                my_lletters(my_lletter_count) := chr(lcv);
            end loop;
            -- digits are ASCII values 48 through 57
            for lcv in 48 .. 57 loop
                my_digits_count := my_digits_count + 1;
                my_digits(my_digits_count) := chr(lcv);
            end loop;
        end populate_arrays;

    begin
        populate_arrays;

        -- length check is worth 15 + 1 for each char beyond 8
        check_length(user_password);

        -- if both upper and lower case characters exist add 25 to the running total
        if test_for_upper_and_lower(user_password) then
            password_score := password_score + 25;  -- fix the bug here
        else
            my_issue_count := my_issue_count + 1;
            my_issues(my_issue_count) := 'Missing both lower and upper case chars';
        end if;

        -- if both characters and digits exist add 25 to running total
        if test_for_char_and_digit(user_password) then
            password_score := password_score + 25;
        else
            my_issue_count := my_issue_count + 1;
            my_issues(my_issue_count) := 'Missing both char and digit combination.';
        end if;   

        -- if we have at least one embedded symbol add 25
        if test_for_symbol(user_password) then
            password_score := password_score + 25;
        else
            my_issue_count := my_issue_count + 1;
            my_issues(my_issue_count) := 'Missing at least one symbol.';
        end if;   

        -- if we have included either < or > set issue 
        if test_for_gt_or_lt(user_password) then
            password_score := 0;
            my_issue_count := my_issue_count + 1;
            my_issues(my_issue_count) := 'Illegal use of < or > symbol.';
        end if;

        if password_score < 0 then -- don't think can happen but we will play it safe
            password_score := 0;
        elsif password_score > 100 then
            password_score := 100;  -- this can definitely happend
        end if;

        -- if the user needs access to the issues they can call the overloaded version
        return password_score;
        
    end calc_password_strength;

end new_student;

-- note how our type declaration is now in the package definition
create or replace package new_student as

    type my_issues_table is table of varchar(200) index by binary_integer;

    function calc_password_strength(user_password varchar default 'nogood') return integer;

    function calc_password_strength
        (user_password      in      varchar     default 'nogood',
        my_issues_out       out     my_issues_table,
        my_issue_count_out  out     integer)    return integer;

end new_student;

create or replace package body new_student as

    -- pull these out as globals to the package body
    type my_array is table of char(1) index by binary_integer;
    my_symbols      my_array;
    my_uletters     my_array;
    my_lletters     my_array;
    my_digits       my_array;

    my_symbol_count     integer := 0;
    my_uletter_count    integer := 0;
    my_lletter_count    integer := 0;
    my_digits_count     integer := 0;

    my_issues           my_issues_table;
    my_issue_count      integer := 0;

    password_score      integer := 0;

    -- pull common routines out of calc_password_strength functions
    function test_for_gt_or_lt
       (user_password in   varchar)
       return boolean
       is
       found_one   boolean := false;
    begin
       for lcv in 1.. length(user_password) loop
           if substr(user_password, lcv, 1) = chr(60) or  -- ASCII <
              substr(user_password, lcv, 1) = chr(62) then  -- ASCII >
              found_one := true;
            end if;
        end loop;
        return found_one;
    end test_for_gt_or_lt;

    function test_for_symbol
        (user_password in   varchar)
        return boolean
        is
        symbol_found    boolean := false;
     begin
        for lcv1 in 1 .. my_symbol_count loop
            for lcv2 in 1 .. length(user_password) loop
                if substr(user_password, lcv2, 1) = my_symbols(lcv1) then
                    symbol_found := true;
                end if;
             end loop;
         end loop;
         return symbol_found;
     end test_for_symbol;

     function test_for_char_and_digit
         (user_password in   varchar)
         return boolean
         is
         char_found      boolean := false;
         digit_found     boolean := false;
     begin
         for lcv1 in 1 .. my_uletter_count loop
             for lcv2 in 1 .. length(user_password) loop
                 if (substr(user_password, lcv2, 1) = my_uletters(lcv1)) or
                    (substr(user_password, lcv2, 1) = my_lletters(lcv1)) then
                     char_found := true;
                 end if;
             end loop;
         end loop;

         for lcv1 in 1 .. my_digits_count loop
             for lcv2 in 1 .. length(user_password) loop
                 if substr(user_password, lcv2, 1) = my_digits(lcv1) then
                     digit_found := true;
                 end if;
             end loop;
         end loop;

         if digit_found and char_found then
             return true;
         else
             return false;
         end if;
    end test_for_char_and_digit;
    
    function test_for_upper_and_lower
        (user_password  in  varchar)
        return boolean
        is
        upper_found     boolean := false;
        lower_found     boolean := false;
    begin
        for lcv1 in 1 .. my_uletter_count loop  -- for each upper case letter
            for lcv2 in 1 .. length(user_password) loop -- for each letter in the password
                if (substr(user_password, lcv2, 1) = my_uletters(lcv1)) then
                    -- if this upper case letter matches this character in the password
                    upper_found := true;    -- flag the ccondition as having been met
                end if;
            end loop;
        end loop;

        for lcv1 in 1 .. my_lletter_count loop  -- for each lower case letter
            for lcv2 in 1 .. length(user_password) loop -- for each letter in the password
                if (substr(user_password, lcv2, 1) = my_lletters(lcv1)) then
                    -- if this lower case letter matches this character in the password
                    lower_found := true;    -- flag the ccondition as having been met
                end if;
            end loop;
        end loop;

        if upper_found and lower_found then
            return true;
        else
            return false;
        end if;
   end test_for_upper_and_lower;

   procedure check_length 
        (user_password  in  varchar)
        is
        -- this routine checks whether passsword length is accceptable; i.e. GE 8
        -- if not score zero and post an issue to the my_issues table
        -- if acceptable then score 15 plus one for each additional character length
        password_length integer;
    begin
        -- determine the length of the potential password
        select length(user_password) into password_length from dual;
        -- score that length
        if password_length < 8 then
            -- password is too short
            my_issue_count := my_issue_count + 1;
            my_issues(my_issue_count) := 'Password is too short.';
        else
            password_score := password_score + 15 + length(user_password) - 8;
        end if;
    end check_length;

    procedure populate_arrays is
    begin
        -- keyboard symbols are ASCII 33 through 47 and 91 through 95 and 123 through 126
        for lcv in 33 .. 47 loop
            my_symbol_count := my_symbol_count + 1;
            my_symbols(my_symbol_count) := chr(lcv); 
        end loop;
        for lcv in 91 .. 95 loop
            my_symbol_count := my_symbol_count + 1;
            my_symbols(my_symbol_count) := chr(lcv); 
        end loop;
        for lcv in 123 .. 126 loop
            my_symbol_count := my_symbol_count + 1;
            my_symbols(my_symbol_count) := chr(lcv); 
        end loop;
        -- upper case letters are ASCII 65 through 90
        for lcv in 65 .. 90 loop
            my_uletter_count := lcv - 64;
            my_uletters(my_uletter_count) := chr(lcv);
        end loop;
        -- lower case letters are ASCII 97 through 122
        for lcv in 97 .. 122 loop
            my_lletter_count := my_lletter_count + 1;
            my_lletters(my_lletter_count) := chr(lcv);
        end loop;
        -- digits are ASCII values 48 through 57
        for lcv in 48 .. 57 loop
            my_digits_count := my_digits_count + 1;
            my_digits(my_digits_count) := chr(lcv);
        end loop;
    end populate_arrays;

    -- this is our function from chapter 16
    function calc_password_strength
        (user_password  in      varchar default 'nogood')
        return          integer     -- 0 through 100 inclusive wwith 100 max strength
        as
    begin
    
        populate_arrays;

        -- length check is worth 15 + 1 for each char beyond 8
        check_length(user_password);

        -- if both upper and lower case characters exist add 25 to the running total
        if test_for_upper_and_lower(user_password) then
            password_score := password_score + 25;  -- fix the bug here
        else
            my_issue_count := my_issue_count + 1;
            my_issues(my_issue_count) := 'Missing both lower and upper case chars';
        end if;

        -- if both characters and digits exist add 25 to running total
        if test_for_char_and_digit(user_password) then
            password_score := password_score + 25;
        else
            my_issue_count := my_issue_count + 1;
            my_issues(my_issue_count) := 'Missing both char and digit combination.';
        end if;   

        -- if we have at least one embedded symbol add 25
        if test_for_symbol(user_password) then
            password_score := password_score + 25;
        else
            my_issue_count := my_issue_count + 1;
            my_issues(my_issue_count) := 'Missing at least one symbol.';
        end if;   

        -- if we have included either < or > set issue 
        if test_for_gt_or_lt(user_password) then
            password_score := 0;
            my_issue_count := my_issue_count + 1;
            my_issues(my_issue_count) := 'Illegal use of < or > symbol.';
        end if;

        if password_score < 0 then -- don't think can happen but we will play it safe
            password_score := 0;
        elsif password_score > 100 then
            password_score := 100;  -- this can definitely happend
        end if;

        -- if the user needs access to the issues they can call the overloaded version
        return password_score;

    end calc_password_strength;

    -- now the overloaded version
    function calc_password_strength
        (user_password          in      varchar default 'nogood',
         my_issues_out          out     my_issues_table,
         my_issue_count_out    out     integer)
        return          integer     -- 0 through 100 inclusive wwith 100 max strength
        as
    begin
        populate_arrays;

        -- length check is worth 25 + 1 for each char beyond 8
        check_length(user_password);

        -- if both upper and lower case characters exist add 15 to the running total
        if test_for_upper_and_lower(user_password) then
            password_score := password_score + 25;  -- fix the bug here
        else
            my_issue_count := my_issue_count + 1;
            my_issues(my_issue_count) := 'Missing both lower and upper case chars';
        end if;

        -- if both characters and digits exist add 25 to running total
        if test_for_char_and_digit(user_password) then
            password_score := password_score + 25;
        else
            my_issue_count := my_issue_count + 1;
            my_issues(my_issue_count) := 'Missing both char and digit combination.';
        end if;   

        -- if we have at least one embedded symbol add 25
        if test_for_symbol(user_password) then
            password_score := password_score + 25;
        else
            my_issue_count := my_issue_count + 1;
            my_issues(my_issue_count) := 'Missing at least one symbol.';
        end if;   

        -- if we have included either < or > set issue 
        if test_for_gt_or_lt(user_password) then
            password_score := 0;
            my_issue_count := my_issue_count + 1;
            my_issues(my_issue_count) := 'Illegal use of < or > symbol.';
        end if;

        if password_score < 0 then -- don't think can happen but we will play it safe
            password_score := 0;
        elsif password_score > 100 then
            password_score := 100;  -- this can definitely happend
        end if;


        my_issues_out := my_issues;
        my_issue_count_out := my_issue_count;

        -- if the user needs access to the issues they can call the overloaded version
        return password_score;

    end calc_password_strength;

end new_student;

-- add in the create_new_student procedure
create or replace package new_student as

    type my_issues_table is table of varchar(200) index by binary_integer;

    function calc_password_strength(user_password varchar default 'nogood') return integer;
    
    function calc_password_strength
        (user_password      in      varchar     default 'nogood',
        my_issues_out       out     my_issues_table,
        my_issue_count_out  out     integer)    return integer;

    procedure create_new_student
        (first_name         in      varchar,
         last_name          in      varchar,
         email              in      varchar,
         telephone          in      varchar,
         user_password      in      varchar,
         manager_id         in      integer,
         customer_id        in      integer,
         person_id          out     integer,
         student_id         out     integer,
         my_issues_out      out     my_issues_table,
         my_issue_out_count out     integer);
            
end new_student;

create or replace package body new_student as

    -- pull these out as globals to the package body
    type my_array is table of char(1) index by binary_integer;
    my_symbols      my_array;
    my_uletters     my_array;
    my_lletters     my_array;
    my_digits       my_array;

    my_symbol_count     integer := 0;
    my_uletter_count    integer := 0;
    my_lletter_count    integer := 0;
    my_digits_count     integer := 0;

    my_issues           my_issues_table;
    my_issue_count      integer := 0;

    password_score      integer := 0;

    -- pull common routines out of calc_password_strength functions
    function test_for_gt_or_lt
       (user_password in   varchar)
       return boolean
       is
       found_one   boolean := false;
    begin
       for lcv in 1.. length(user_password) loop
           if substr(user_password, lcv, 1) = chr(60) or  -- ASCII <
              substr(user_password, lcv, 1) = chr(62) then  -- ASCII >
              found_one := true;
            end if;
        end loop;
        return found_one;
    end test_for_gt_or_lt;

    function test_for_symbol
        (user_password in   varchar)
        return boolean
        is
        symbol_found    boolean := false;
     begin
        for lcv1 in 1 .. my_symbol_count loop
            for lcv2 in 1 .. length(user_password) loop
                if substr(user_password, lcv2, 1) = my_symbols(lcv1) then
                    symbol_found := true;
                end if;
             end loop;
         end loop;
         return symbol_found;
     end test_for_symbol;

     function test_for_char_and_digit
         (user_password in   varchar)
         return boolean
         is
         char_found      boolean := false;
         digit_found     boolean := false;
     begin
         for lcv1 in 1 .. my_uletter_count loop
             for lcv2 in 1 .. length(user_password) loop
                 if (substr(user_password, lcv2, 1) = my_uletters(lcv1)) or
                    (substr(user_password, lcv2, 1) = my_lletters(lcv1)) then
                     char_found := true;
                 end if;
             end loop;
         end loop;

         for lcv1 in 1 .. my_digits_count loop
             for lcv2 in 1 .. length(user_password) loop
                 if substr(user_password, lcv2, 1) = my_digits(lcv1) then
                     digit_found := true;
                 end if;
             end loop;
         end loop;

         if digit_found and char_found then
             return true;
         else
             return false;
         end if;
    end test_for_char_and_digit;
    
    function test_for_upper_and_lower
        (user_password  in  varchar)
        return boolean
        is
        upper_found     boolean := false;
        lower_found     boolean := false;
    begin
        for lcv1 in 1 .. my_uletter_count loop  -- for each upper case letter
            for lcv2 in 1 .. length(user_password) loop -- for each letter in the password
                if (substr(user_password, lcv2, 1) = my_uletters(lcv1)) then
                    -- if this upper case letter matches this character in the password
                    upper_found := true;    -- flag the ccondition as having been met
                end if;
            end loop;
        end loop;

        for lcv1 in 1 .. my_lletter_count loop  -- for each lower case letter
            for lcv2 in 1 .. length(user_password) loop -- for each letter in the password
                if (substr(user_password, lcv2, 1) = my_lletters(lcv1)) then
                    -- if this lower case letter matches this character in the password
                    lower_found := true;    -- flag the ccondition as having been met
                end if;
            end loop;
        end loop;

        if upper_found and lower_found then
            return true;
        else
            return false;
        end if;
   end test_for_upper_and_lower;

   procedure check_length 
        (user_password  in  varchar)
        is
        -- this routine checks whether passsword length is accceptable; i.e. GE 8
        -- if not score zero and post an issue to the my_issues table
        -- if acceptable then score 15 plus one for each additional character length
        password_length integer;
    begin
        -- determine the length of the potential password
        select length(user_password) into password_length from dual;
        -- score that length
        if password_length < 8 then
            -- password is too short
            my_issue_count := my_issue_count + 1;
            my_issues(my_issue_count) := 'Password is too short.';
        else
            password_score := password_score + 15 + length(user_password) - 8;
        end if;
    end check_length;

    procedure populate_arrays is
    begin
        -- keyboard symbols are ASCII 33 through 47 and 91 through 95 and 123 through 126
        for lcv in 33 .. 47 loop
            my_symbol_count := my_symbol_count + 1;
            my_symbols(my_symbol_count) := chr(lcv); 
        end loop;
        for lcv in 91 .. 95 loop
            my_symbol_count := my_symbol_count + 1;
            my_symbols(my_symbol_count) := chr(lcv); 
        end loop;
        for lcv in 123 .. 126 loop
            my_symbol_count := my_symbol_count + 1;
            my_symbols(my_symbol_count) := chr(lcv); 
        end loop;
        -- upper case letters are ASCII 65 through 90
        for lcv in 65 .. 90 loop
            my_uletter_count := lcv - 64;
            my_uletters(my_uletter_count) := chr(lcv);
        end loop;
        -- lower case letters are ASCII 97 through 122
        for lcv in 97 .. 122 loop
            my_lletter_count := my_lletter_count + 1;
            my_lletters(my_lletter_count) := chr(lcv);
        end loop;
        -- digits are ASCII values 48 through 57
        for lcv in 48 .. 57 loop
            my_digits_count := my_digits_count + 1;
            my_digits(my_digits_count) := chr(lcv);
        end loop;
    end populate_arrays;

    -- this is our function from chapter 16
    function calc_password_strength
        (user_password  in      varchar default 'nogood')
        return          integer     -- 0 through 100 inclusive wwith 100 max strength
        as
    begin
    
        populate_arrays;

        -- length check is worth 15 + 1 for each char beyond 8
        check_length(user_password);

        -- if both upper and lower case characters exist add 25 to the running total
        if test_for_upper_and_lower(user_password) then
            password_score := password_score + 25;  -- fix the bug here
        else
            my_issue_count := my_issue_count + 1;
            my_issues(my_issue_count) := 'Missing both lower and upper case chars';
        end if;

        -- if both characters and digits exist add 25 to running total
        if test_for_char_and_digit(user_password) then
            password_score := password_score + 25;
        else
            my_issue_count := my_issue_count + 1;
            my_issues(my_issue_count) := 'Missing both char and digit combination.';
        end if;   

        -- if we have at least one embedded symbol add 25
        if test_for_symbol(user_password) then
            password_score := password_score + 25;
        else
            my_issue_count := my_issue_count + 1;
            my_issues(my_issue_count) := 'Missing at least one symbol.';
        end if;   

        -- if we have included either < or > set issue 
        if test_for_gt_or_lt(user_password) then
            password_score := 0;
            my_issue_count := my_issue_count + 1;
            my_issues(my_issue_count) := 'Illegal use of < or > symbol.';
        end if;

        if password_score < 0 then -- don't think can happen but we will play it safe
            password_score := 0;
        elsif password_score > 100 then
            password_score := 100;  -- this can definitely happend
        end if;

        -- if the user needs access to the issues they can call the overloaded version
        return password_score;

    end calc_password_strength;

    -- now the overloaded version
    function calc_password_strength
        (user_password          in      varchar default 'nogood',
         my_issues_out          out     my_issues_table,
         my_issue_count_out    out     integer)
        return          integer     -- 0 through 100 inclusive wwith 100 max strength
        as
    begin
        populate_arrays;

        -- length check is worth 25 + 1 for each char beyond 8
        check_length(user_password);

        -- if both upper and lower case characters exist add 15 to the running total
        if test_for_upper_and_lower(user_password) then
            password_score := password_score + 25;  -- fix the bug here
        else
            my_issue_count := my_issue_count + 1;
            my_issues(my_issue_count) := 'Missing both lower and upper case chars';
        end if;

        -- if both characters and digits exist add 25 to running total
        if test_for_char_and_digit(user_password) then
            password_score := password_score + 25;
        else
            my_issue_count := my_issue_count + 1;
            my_issues(my_issue_count) := 'Missing both char and digit combination.';
        end if;   

        -- if we have at least one embedded symbol add 25
        if test_for_symbol(user_password) then
            password_score := password_score + 25;
        else
            my_issue_count := my_issue_count + 1;
            my_issues(my_issue_count) := 'Missing at least one symbol.';
        end if;   

        -- if we have included either < or > set issue 
        if test_for_gt_or_lt(user_password) then
            password_score := 0;
            my_issue_count := my_issue_count + 1;
            my_issues(my_issue_count) := 'Illegal use of < or > symbol.';
        end if;

        if password_score < 0 then -- don't think can happen but we will play it safe
            password_score := 0;
        elsif password_score > 100 then
            password_score := 100;  -- this can definitely happend
        end if;


        my_issues_out := my_issues;
        my_issue_count_out := my_issue_count;

        -- if the user needs access to the issues they can call the overloaded version
        return password_score;

    end calc_password_strength;

    procedure create_new_student
        (first_name         in      varchar,
         last_name          in      varchar,
         email              in      varchar,
         telephone          in      varchar,
         user_password      in      varchar,
         manager_id         in      integer,
         customer_id        in      integer,
         person_id          out     integer,
         student_id         out     integer,
         my_issues_out      out     my_issues_table,
         my_issue_out_count out     integer) is
     
         my_issues                  my_issues_table;
         my_issue_count             integer := 0;
         my_row_count               integer;
         my_password_strength       integer;
     
         begin
     
            -- first and last names are required fields
            if length(create_new_student.first_name) = 0 then
                my_issue_count := my_issue_count + 1;
                my_issues(my_issue_count) := 'First name is null';
            end if;
            if length(create_new_student.last_name) = 0 then
                my_issue_count := my_issue_count + 1;
                my_issues(my_issue_count) := 'Last name is null';
            end if;
            
            -- if present, then manager_id and customer_id must be valid
            if create_new_student.manager_id is not null then
                select  count(*) into my_row_count
                from    persons
                where   person_id = create_new_student.manager_id;
            
                if my_row_count = 0 then
                    my_issue_count := my_issue_count + 1;
                    my_issues(my_issue_count) := 'Manager_ID is invalid.';
                end if;
            end if;                
            
            if create_new_student.customer_id is not null then
                select  count(*) into my_row_count
                from    customers
                where   customer_id = create_new_student.customer_id;
            
                if my_row_count = 0 then
                    my_issue_count := my_issue_count + 1;
                    my_issues(my_issue_count) := 'Customer_ID is invalid.';
                end if;
            end if;      

            -- how strong is this password
            select calc_password_strength(create_new_student.user_password) into my_password_strength from dual;
            
            -- if all minimum criterion are met calc_password_strength should return a value of 90
            if my_password_strength < 90 then
                select  calc_password_strength (create_new_student.user_password,my_issues,my_issue_count)
                into    my_password_strength
                from    dual;
            end if;

            -- if my_issue_count is zero then we can insert else return issues
            if my_issue_count = 0 then
            
                insert into persons
                    (person_id, first_name, last_name, email, telephone, 
                     password, password_update, manager_id, customer_id)
                select
                    nvl(max(person_id)+1,1), create_new_student.first_name, create_new_student.last_name,
                    create_new_student.email, create_new_student.telephone, create_new_student.user_password, sysdate,
                    create_new_student.manager_id, create_new_student.customer_id
                from
                    persons;
            
                select max(person_id) into create_new_student.person_id from persons;
               
                insert into students
                    (person_id, student_id, customer_id)
                select
                    create_new_student.person_id, nvl(max(student_id)+1,1), create_new_student.customer_id
                from
                    students;
                    
                select max(student_id) into create_new_student.student_id from students;    
            else
            
                create_new_student.my_issues_out := my_issues;
                create_new_student.my_issue_out_count := my_issue_count;
                
            end if;
            
        end create_new_student;

end new_student;

-- let's update the person_course_roles table to add a couple of columns
alter table person_course_roles add action_type varchar(50);
alter table person_course_roles add action_type_date date default sysdate;
alter table person_course_roles_audit add action_type varchar(50);
alter table person_course_roles_audit add action_type_date date;

-- let's move the customer_id ref to the persons table then we can drop the students tables
alter table persons add customer_id integer;
alter table persons add constraint persons_fk1 foreign key (customer_id)  references customers(customer_id);
drop table students_audit;
drop table students;

-- update the create_new_student routine to conform to schema changes
create or replace package new_student as

    type my_issues_table is table of varchar(200) index by binary_integer;

    function calc_password_strength(user_password varchar default 'nogood') return integer;
    
    function calc_password_strength
        (user_password      in      varchar     default 'nogood',
        my_issues_out       out     my_issues_table,
        my_issue_count_out  out     integer)    return integer;

    -- note the removal of the student_id column
    procedure create_new_student
        (first_name         in      varchar,
         last_name          in      varchar,
         email              in      varchar,
         telephone          in      varchar,
         user_password      in      varchar,
         manager_id         in      integer,
         customer_id        in      integer,
         person_id          out     integer,
         my_issues_out      out     my_issues_table,
         my_issue_out_count out     integer);
            
end new_student;

create or replace package body new_student as

    -- this is our function from chapter 16
    function calc_password_strength
        (user_password  in      varchar default 'nogood')
        return          integer     -- 0 through 100 inclusive wwith 100 max strength
        as
    
        type my_array is table of char(1) index by binary_integer;
        my_symbols      my_array;
        my_uletters     my_array;
        my_lletters     my_array;
        my_digits       my_array;

        my_symbol_count     integer := 0;
        my_uletter_count    integer := 0;
        my_lletter_count    integer := 0;
        my_digits_count     integer := 0;

        -- in our overloaded version of this function we will return this structure as an out parm
        -- type my_issues_table is table of varchar(200) index by binary_integer;
        my_issues           my_issues_table;
        my_issue_count      integer := 0;

        password_score      integer := 0;

        function test_for_gt_or_lt
            (user_password in   varchar)
            return boolean
            is
            found_one   boolean := false;
        begin
            for lcv in 1.. length(user_password) loop
                if substr(user_password, lcv, 1) = chr(60) or  -- ASCII <
                   substr(user_password, lcv, 1) = chr(62) then  -- ASCII >
                    found_one := true;
                end if;
            end loop;
            return found_one;
        end test_for_gt_or_lt;

        function test_for_symbol
            (user_password in   varchar)
            return boolean
            is
            symbol_found    boolean := false;
        begin
            for lcv1 in 1 .. my_symbol_count loop
                for lcv2 in 1 .. length(user_password) loop
                    if substr(user_password, lcv2, 1) = my_symbols(lcv1) then
                        symbol_found := true;
                    end if;
                end loop;
            end loop;
            return symbol_found;
        end test_for_symbol;

        function test_for_char_and_digit
            (user_password in   varchar)
            return boolean
            is
            char_found      boolean := false;
            digit_found     boolean := false;
        begin
            for lcv1 in 1 .. my_uletter_count loop
                for lcv2 in 1 .. length(user_password) loop
                    if (substr(user_password, lcv2, 1) = my_uletters(lcv1)) or
                        (substr(user_password, lcv2, 1) = my_lletters(lcv1)) then
                        char_found := true;
                    end if;
                end loop;
            end loop;

            for lcv1 in 1 .. my_digits_count loop
                for lcv2 in 1 .. length(user_password) loop
                    if substr(user_password, lcv2, 1) = my_digits(lcv1) then
                        digit_found := true;
                    end if;
                end loop;
            end loop;

            if digit_found and char_found then
                return true;
            else
                return false;
            end if;
        end test_for_char_and_digit;

        function test_for_upper_and_lower
            (user_password  in  varchar)
            return boolean
            is
            upper_found     boolean := false;
            lower_found     boolean := false;
        begin
            for lcv1 in 1 .. my_uletter_count loop  -- for each upper case letter
                for lcv2 in 1 .. length(user_password) loop -- for each letter in the password
                    if (substr(user_password, lcv2, 1) = my_uletters(lcv1)) then
                        -- if this upper case letter matches this character in the password
                        upper_found := true;    -- flag the ccondition as having been met
                    end if;
                end loop;
            end loop;

            for lcv1 in 1 .. my_lletter_count loop  -- for each lower case letter
                for lcv2 in 1 .. length(user_password) loop -- for each letter in the password
                    if (substr(user_password, lcv2, 1) = my_lletters(lcv1)) then
                        -- if this lower case letter matches this character in the password
                        lower_found := true;    -- flag the ccondition as having been met
                    end if;
                end loop;
            end loop;

            if upper_found and lower_found then
                return true;
            else
                return false;
            end if;
        end test_for_upper_and_lower;

       procedure check_length 
            (user_password  in  varchar)
        is
            -- this routine checks whether passsword length is accceptable; i.e. GE 8
            -- if not score zero and post an issue to the my_issues table
            -- if acceptable then score 15 plus one for each additional character length
            password_length integer;
        begin
            -- determine the length of the potential password
            select length(user_password) into password_length from dual;
            -- score that length
            if password_length < 8 then
                -- password is too short
                my_issue_count := my_issue_count + 1;
                my_issues(my_issue_count) := 'Password is too short.';
            else
                password_score := password_score + 15 + length(user_password) - 8;
            end if;
        end;

        procedure populate_arrays is
        begin
            -- keyboard symbols are ASCII 33 through 47 and 91 through 95 and 123 through 126
            for lcv in 33 .. 47 loop
                my_symbol_count := my_symbol_count + 1;
                my_symbols(my_symbol_count) := chr(lcv); 
            end loop;
            for lcv in 91 .. 95 loop
                my_symbol_count := my_symbol_count + 1;
                my_symbols(my_symbol_count) := chr(lcv); 
            end loop;
            for lcv in 123 .. 126 loop
                my_symbol_count := my_symbol_count + 1;
                my_symbols(my_symbol_count) := chr(lcv); 
            end loop;
            -- upper case letters are ASCII 65 through 90
            for lcv in 65 .. 90 loop
                my_uletter_count := lcv - 64;
                my_uletters(my_uletter_count) := chr(lcv);
            end loop;
            -- lower case letters are ASCII 97 through 122
            for lcv in 97 .. 122 loop
                my_lletter_count := my_lletter_count + 1;
                my_lletters(my_lletter_count) := chr(lcv);
            end loop;
            -- digits are ASCII values 48 through 57
            for lcv in 48 .. 57 loop
                my_digits_count := my_digits_count + 1;
                my_digits(my_digits_count) := chr(lcv);
            end loop;
        end populate_arrays;

    begin
        populate_arrays;

        -- length check is worth 25 + 1 for each char beyond 8
        check_length(user_password);

        -- if both upper and lower case characters exist add 25 to the running total
        if test_for_upper_and_lower(user_password) then
            password_score := password_score + 25;  -- fix the bug here
        else
            my_issue_count := my_issue_count + 1;
            my_issues(my_issue_count) := 'Missing both lower and upper case chars';
        end if;

        -- if both characters and digits exist add 25 to running total
        if test_for_char_and_digit(user_password) then
            password_score := password_score + 25;
        else
            my_issue_count := my_issue_count + 1;
            my_issues(my_issue_count) := 'Missing both char and digit combination.';
        end if;   

        -- if we have at least one embedded symbol add 25
        if test_for_symbol(user_password) then
            password_score := password_score + 25;
        else
            my_issue_count := my_issue_count + 1;
            my_issues(my_issue_count) := 'Missing at least one symbol.';
        end if;   

        -- if we have included either < or > set issue 
        if test_for_gt_or_lt(user_password) then
            password_score := 0;
            my_issue_count := my_issue_count + 1;
            my_issues(my_issue_count) := 'Illegal use of < or > symbol.';
        end if;

        if password_score < 0 then -- don't think can happen but we will play it safe
            password_score := 0;
        elsif password_score > 100 then
            password_score := 100;  -- this can definitely happend
        end if;

        -- if the user needs access to the issues they can call the overloaded version
        return password_score;

    end calc_password_strength;

    -- now the overloaded version
    function calc_password_strength
        (user_password          in      varchar default 'nogood',
         my_issues_out          out     my_issues_table,
         my_issue_count_out     out     integer)
        return          integer     -- 0 through 100 inclusive wwith 100 max strength
        as

        type my_array is table of char(1) index by binary_integer;
        my_symbols      my_array;
        my_uletters     my_array;
        my_lletters     my_array;
        my_digits       my_array;

        my_symbol_count     integer := 0;
        my_uletter_count    integer := 0;
        my_lletter_count    integer := 0;
        my_digits_count     integer := 0;

        -- in our overloaded version of this function we will return this structure as an out parm
        -- type my_issues_table is table of varchar(200) index by binary_integer; no longer needed
        my_issues           my_issues_table;
        my_issue_count      integer := 0;

        password_score      integer := 0;

        function test_for_gt_or_lt
            (user_password in   varchar)
            return boolean
            is
            found_one   boolean := false;
        begin
            for lcv in 1.. length(user_password) loop
                if substr(user_password, lcv, 1) = chr(60) or  -- ASCII <
                   substr(user_password, lcv, 1) = chr(62) then  -- ASCII >
                    found_one := true;
                end if;
            end loop;
            return found_one;
        end test_for_gt_or_lt;

        function test_for_symbol
            (user_password in   varchar)
            return boolean
            is
            symbol_found    boolean := false;
        begin
            for lcv1 in 1 .. my_symbol_count loop
                for lcv2 in 1 .. length(user_password) loop
                    if substr(user_password, lcv2, 1) = my_symbols(lcv1) then
                        symbol_found := true;
                    end if;
                end loop;
            end loop;
            return symbol_found;
        end test_for_symbol;

        function test_for_char_and_digit
            (user_password in   varchar)
            return boolean
            is
            char_found      boolean := false;
            digit_found     boolean := false;
        begin
            for lcv1 in 1 .. my_uletter_count loop
                for lcv2 in 1 .. length(user_password) loop
                    if (substr(user_password, lcv2, 1) = my_uletters(lcv1)) or
                        (substr(user_password, lcv2, 1) = my_lletters(lcv1)) then
                        char_found := true;
                    end if;
                end loop;
            end loop;

            for lcv1 in 1 .. my_digits_count loop
                for lcv2 in 1 .. length(user_password) loop
                    if substr(user_password, lcv2, 1) = my_digits(lcv1) then
                        digit_found := true;
                    end if;
                end loop;
            end loop;

            if digit_found and char_found then
                return true;
            else
                return false;
            end if;
        end test_for_char_and_digit;

        function test_for_upper_and_lower
            (user_password  in  varchar)
            return boolean
            is
            upper_found     boolean := false;
            lower_found     boolean := false;
        begin
            for lcv1 in 1 .. my_uletter_count loop  -- for each upper case letter
                for lcv2 in 1 .. length(user_password) loop -- for each letter in the password
                    if (substr(user_password, lcv2, 1) = my_uletters(lcv1)) then
                        -- if this upper case letter matches this character in the password
                        upper_found := true;    -- flag the ccondition as having been met
                    end if;
                end loop;
            end loop;

            for lcv1 in 1 .. my_lletter_count loop  -- for each lower case letter
                for lcv2 in 1 .. length(user_password) loop -- for each letter in the password
                    if (substr(user_password, lcv2, 1) = my_lletters(lcv1)) then
                        -- if this lower case letter matches this character in the password
                        lower_found := true;    -- flag the ccondition as having been met
                    end if;
                end loop;
            end loop;

            if upper_found and lower_found then
                return true;
            else
                return false;
            end if;
        end test_for_upper_and_lower;

       procedure check_length 
            (user_password  in  varchar)
        is
            -- this routine checks whether passsword length is accceptable; i.e. GE 8
            -- if not score zero and post an issue to the my_issues table
            -- if acceptable then score 15 plus one for each additional character length
            password_length integer;
        begin
            -- determine the length of the potential password
            select length(user_password) into password_length from dual;
            -- score that length
            if password_length < 8 then
                -- password is too short
                my_issue_count := my_issue_count + 1;
                my_issues(my_issue_count) := 'Password is too short.';
            else
                password_score := password_score + 15 + length(user_password) - 8;
            end if;
        end;

        procedure populate_arrays is
        begin
            -- keyboard symbols are ASCII 33 through 47 and 91 through 95 and 123 through 126
            for lcv in 33 .. 47 loop
                my_symbol_count := my_symbol_count + 1;
                my_symbols(my_symbol_count) := chr(lcv); 
            end loop;
            for lcv in 91 .. 95 loop
                my_symbol_count := my_symbol_count + 1;
                my_symbols(my_symbol_count) := chr(lcv); 
            end loop;
            for lcv in 123 .. 126 loop
                my_symbol_count := my_symbol_count + 1;
                my_symbols(my_symbol_count) := chr(lcv); 
            end loop;
            -- upper case letters are ASCII 65 through 90
            for lcv in 65 .. 90 loop
                my_uletter_count := lcv - 64;
                my_uletters(my_uletter_count) := chr(lcv);
            end loop;
            -- lower case letters are ASCII 97 through 122
            for lcv in 97 .. 122 loop
                my_lletter_count := my_lletter_count + 1;
                my_lletters(my_lletter_count) := chr(lcv);
            end loop;
            -- digits are ASCII values 48 through 57
            for lcv in 48 .. 57 loop
                my_digits_count := my_digits_count + 1;
                my_digits(my_digits_count) := chr(lcv);
            end loop;
        end populate_arrays;

    begin
        populate_arrays;

        -- length check is worth 25 + 1 for each char beyond 8
        check_length(user_password);

        -- if both upper and lower case characters exist add 25 to the running total
        if test_for_upper_and_lower(user_password) then
            password_score := password_score + 25;  -- fix the bug here
        else
            my_issue_count := my_issue_count + 1;
            my_issues(my_issue_count) := 'Missing both lower and upper case chars';
        end if;

        -- if both characters and digits exist add 25 to running total
        if test_for_char_and_digit(user_password) then
            password_score := password_score + 25;
        else
            my_issue_count := my_issue_count + 1;
            my_issues(my_issue_count) := 'Missing both char and digit combination.';
        end if;   

        -- if we have at least one embedded symbol add 25
        if test_for_symbol(user_password) then
            password_score := password_score + 25;
        else
            my_issue_count := my_issue_count + 1;
            my_issues(my_issue_count) := 'Missing at least one symbol.';
        end if;   

        -- if we have included either < or > set issue 
        if test_for_gt_or_lt(user_password) then
            password_score := 0;
            my_issue_count := my_issue_count + 1;
            my_issues(my_issue_count) := 'Illegal use of < or > symbol.';
        end if;

        if password_score < 0 then -- don't think can happen but we will play it safe
            password_score := 0;
        elsif password_score > 100 then
            password_score := 100;  -- this can definitely happend
        end if;


        my_issues_out := my_issues;
        my_issue_count_out := my_issue_count;

        -- if the user needs access to the issues they can call the overloaded version
        return password_score;

    end calc_password_strength;

    procedure create_new_student
        (first_name         in      varchar,
         last_name          in      varchar,
         email              in      varchar,
         telephone          in      varchar,
         user_password      in      varchar,
         manager_id         in      integer,
         customer_id        in      integer,
         person_id          out     integer,
         my_issues_out      out     my_issues_table,
         my_issue_out_count out     integer) is
     
         my_issues                  my_issues_table;
         my_issue_count             integer := 0;
         my_row_count               integer;
         my_password_strength       integer;
     
         begin
     
            -- first and last names are required fields
            if length(create_new_student.first_name) = 0 then
                my_issue_count := my_issue_count + 1;
                my_issues(my_issue_count) := 'First name is null';
            end if;
            if length(create_new_student.last_name) = 0 then
                my_issue_count := my_issue_count + 1;
                my_issues(my_issue_count) := 'Last name is null';
            end if;
            
            -- if present, then manager_id and customer_id must be valid
            if create_new_student.manager_id is not null then
                select  count(*) into my_row_count
                from    persons
                where   person_id = create_new_student.manager_id;
            
                if my_row_count = 0 then
                    my_issue_count := my_issue_count + 1;
                    my_issues(my_issue_count) := 'Manager_ID is invalid.';
                end if;
            end if;                
            
            if create_new_student.customer_id is not null then
                select  count(*) into my_row_count
                from    customers
                where   customer_id = create_new_student.customer_id;
            
                if my_row_count = 0 then
                    my_issue_count := my_issue_count + 1;
                    my_issues(my_issue_count) := 'Customer_ID is invalid.';
                end if;
            end if;      

            -- how strong is this password
            select calc_password_strength(create_new_student.user_password) into my_password_strength from dual;
            
            -- if all minimum criterion are met calc_password_strength should return a value of 90
            if my_password_strength < 90 then
                select  calc_password_strength (create_new_student.user_password,my_issues,my_issue_count)
                into    my_password_strength
                from    dual;
            end if;

            -- if my_issue_count is zero then we can insert else return issues
            if my_issue_count = 0 then
            
                insert into persons
                    (person_id, first_name, last_name, email, telephone, 
                     password, password_update, manager_id, customer_id)
                select
                    nvl(max(person_id)+1,1), create_new_student.first_name, create_new_student.last_name,
                    create_new_student.email, create_new_student.telephone, create_new_student.user_password, sysdate,
                    create_new_student.manager_id, create_new_student.customer_id
                from
                    persons;
            
                select max(person_id) into create_new_student.person_id from persons;
                
            else
            
                create_new_student.my_issues_out := my_issues;
                create_new_student.my_issue_out_count := my_issue_count;
                
            end if;
            
        end create_new_student;

end new_student;

-- add in the enroll_student procedure
create or replace package new_student as

    type my_issues_table is table of varchar(200) index by binary_integer;

    function calc_password_strength(user_password varchar default 'nogood') return integer;
    
    function calc_password_strength
        (user_password      in      varchar     default 'nogood',
        my_issues_out       out     my_issues_table,
        my_issue_count_out  out     integer)    return integer;

    -- note the removal of the student_id column
    procedure create_new_student
        (first_name         in      varchar,
         last_name          in      varchar,
         email              in      varchar,
         telephone          in      varchar,
         user_password      in      varchar,
         manager_id         in      integer,
         customer_id        in      integer,
         person_id          out     integer,
         my_issues_out      out     my_issues_table,
         my_issue_out_count out     integer);
            
    procedure enroll_student
        (person_id          in      integer,
         course_id          in      integer,
         my_issues_out      out     my_issues_table,
         my_issue_out_count out     integer);
         
end new_student;

create or replace package body new_student as

    -- this is our function from chapter 16
    function calc_password_strength
        (user_password  in      varchar default 'nogood')
        return          integer     -- 0 through 100 inclusive wwith 100 max strength
        as
    
        type my_array is table of char(1) index by binary_integer;
        my_symbols      my_array;
        my_uletters     my_array;
        my_lletters     my_array;
        my_digits       my_array;

        my_symbol_count     integer := 0;
        my_uletter_count    integer := 0;
        my_lletter_count    integer := 0;
        my_digits_count     integer := 0;

        -- in our overloaded version of this function we will return this structure as an out parm
        -- type my_issues_table is table of varchar(200) index by binary_integer;
        my_issues           my_issues_table;
        my_issue_count      integer := 0;

        password_score      integer := 0;

        function test_for_gt_or_lt
            (user_password in   varchar)
            return boolean
            is
            found_one   boolean := false;
        begin
            for lcv in 1.. length(user_password) loop
                if substr(user_password, lcv, 1) = chr(60) or  -- ASCII <
                   substr(user_password, lcv, 1) = chr(62) then  -- ASCII >
                    found_one := true;
                end if;
            end loop;
            return found_one;
        end test_for_gt_or_lt;

        function test_for_symbol
            (user_password in   varchar)
            return boolean
            is
            symbol_found    boolean := false;
        begin
            for lcv1 in 1 .. my_symbol_count loop
                for lcv2 in 1 .. length(user_password) loop
                    if substr(user_password, lcv2, 1) = my_symbols(lcv1) then
                        symbol_found := true;
                    end if;
                end loop;
            end loop;
            return symbol_found;
        end test_for_symbol;

        function test_for_char_and_digit
            (user_password in   varchar)
            return boolean
            is
            char_found      boolean := false;
            digit_found     boolean := false;
        begin
            for lcv1 in 1 .. my_uletter_count loop
                for lcv2 in 1 .. length(user_password) loop
                    if (substr(user_password, lcv2, 1) = my_uletters(lcv1)) or
                        (substr(user_password, lcv2, 1) = my_lletters(lcv1)) then
                        char_found := true;
                    end if;
                end loop;
            end loop;

            for lcv1 in 1 .. my_digits_count loop
                for lcv2 in 1 .. length(user_password) loop
                    if substr(user_password, lcv2, 1) = my_digits(lcv1) then
                        digit_found := true;
                    end if;
                end loop;
            end loop;

            if digit_found and char_found then
                return true;
            else
                return false;
            end if;
        end test_for_char_and_digit;

        function test_for_upper_and_lower
            (user_password  in  varchar)
            return boolean
            is
            upper_found     boolean := false;
            lower_found     boolean := false;
        begin
            for lcv1 in 1 .. my_uletter_count loop  -- for each upper case letter
                for lcv2 in 1 .. length(user_password) loop -- for each letter in the password
                    if (substr(user_password, lcv2, 1) = my_uletters(lcv1)) then
                        -- if this upper case letter matches this character in the password
                        upper_found := true;    -- flag the ccondition as having been met
                    end if;
                end loop;
            end loop;

            for lcv1 in 1 .. my_lletter_count loop  -- for each lower case letter
                for lcv2 in 1 .. length(user_password) loop -- for each letter in the password
                    if (substr(user_password, lcv2, 1) = my_lletters(lcv1)) then
                        -- if this lower case letter matches this character in the password
                        lower_found := true;    -- flag the ccondition as having been met
                    end if;
                end loop;
            end loop;

            if upper_found and lower_found then
                return true;
            else
                return false;
            end if;
        end test_for_upper_and_lower;

       procedure check_length 
            (user_password  in  varchar)
        is
            -- this routine checks whether passsword length is accceptable; i.e. GE 8
            -- if not score zero and post an issue to the my_issues table
            -- if acceptable then score 15 plus one for each additional character length
            password_length integer;
        begin
            -- determine the length of the potential password
            select length(user_password) into password_length from dual;
            -- score that length
            if password_length < 8 then
                -- password is too short
                my_issue_count := my_issue_count + 1;
                my_issues(my_issue_count) := 'Password is too short.';
            else
                password_score := password_score + 15 + length(user_password) - 8;
            end if;
        end;

        procedure populate_arrays is
        begin
            -- keyboard symbols are ASCII 33 through 47 and 91 through 95 and 123 through 126
            for lcv in 33 .. 47 loop
                my_symbol_count := my_symbol_count + 1;
                my_symbols(my_symbol_count) := chr(lcv); 
            end loop;
            for lcv in 91 .. 95 loop
                my_symbol_count := my_symbol_count + 1;
                my_symbols(my_symbol_count) := chr(lcv); 
            end loop;
            for lcv in 123 .. 126 loop
                my_symbol_count := my_symbol_count + 1;
                my_symbols(my_symbol_count) := chr(lcv); 
            end loop;
            -- upper case letters are ASCII 65 through 90
            for lcv in 65 .. 90 loop
                my_uletter_count := lcv - 64;
                my_uletters(my_uletter_count) := chr(lcv);
            end loop;
            -- lower case letters are ASCII 97 through 122
            for lcv in 97 .. 122 loop
                my_lletter_count := my_lletter_count + 1;
                my_lletters(my_lletter_count) := chr(lcv);
            end loop;
            -- digits are ASCII values 48 through 57
            for lcv in 48 .. 57 loop
                my_digits_count := my_digits_count + 1;
                my_digits(my_digits_count) := chr(lcv);
            end loop;
        end populate_arrays;

    begin
        populate_arrays;

        -- length check is worth 25 + 1 for each char beyond 8
        check_length(user_password);

        -- if both upper and lower case characters exist add 25 to the running total
        if test_for_upper_and_lower(user_password) then
            password_score := password_score + 25;  -- fix the bug here
        else
            my_issue_count := my_issue_count + 1;
            my_issues(my_issue_count) := 'Missing both lower and upper case chars';
        end if;

        -- if both characters and digits exist add 25 to running total
        if test_for_char_and_digit(user_password) then
            password_score := password_score + 25;
        else
            my_issue_count := my_issue_count + 1;
            my_issues(my_issue_count) := 'Missing both char and digit combination.';
        end if;   

        -- if we have at least one embedded symbol add 25
        if test_for_symbol(user_password) then
            password_score := password_score + 25;
        else
            my_issue_count := my_issue_count + 1;
            my_issues(my_issue_count) := 'Missing at least one symbol.';
        end if;   

        -- if we have included either < or > set issue 
        if test_for_gt_or_lt(user_password) then
            password_score := 0;
            my_issue_count := my_issue_count + 1;
            my_issues(my_issue_count) := 'Illegal use of < or > symbol.';
        end if;

        if password_score < 0 then -- don't think can happen but we will play it safe
            password_score := 0;
        elsif password_score > 100 then
            password_score := 100;  -- this can definitely happend
        end if;

        -- if the user needs access to the issues they can call the overloaded version
        return password_score;

    end calc_password_strength;

    -- now the overloaded version
    function calc_password_strength
        (user_password          in      varchar default 'nogood',
         my_issues_out          out     my_issues_table,
         my_issue_count_out     out     integer)
        return          integer     -- 0 through 100 inclusive wwith 100 max strength
        as

        type my_array is table of char(1) index by binary_integer;
        my_symbols      my_array;
        my_uletters     my_array;
        my_lletters     my_array;
        my_digits       my_array;

        my_symbol_count     integer := 0;
        my_uletter_count    integer := 0;
        my_lletter_count    integer := 0;
        my_digits_count     integer := 0;

        -- in our overloaded version of this function we will return this structure as an out parm
        -- type my_issues_table is table of varchar(200) index by binary_integer; no longer needed
        my_issues           my_issues_table;
        my_issue_count      integer := 0;

        password_score      integer := 0;

        function test_for_gt_or_lt
            (user_password in   varchar)
            return boolean
            is
            found_one   boolean := false;
        begin
            for lcv in 1.. length(user_password) loop
                if substr(user_password, lcv, 1) = chr(60) or  -- ASCII <
                   substr(user_password, lcv, 1) = chr(62) then  -- ASCII >
                    found_one := true;
                end if;
            end loop;
            return found_one;
        end test_for_gt_or_lt;

        function test_for_symbol
            (user_password in   varchar)
            return boolean
            is
            symbol_found    boolean := false;
        begin
            for lcv1 in 1 .. my_symbol_count loop
                for lcv2 in 1 .. length(user_password) loop
                    if substr(user_password, lcv2, 1) = my_symbols(lcv1) then
                        symbol_found := true;
                    end if;
                end loop;
            end loop;
            return symbol_found;
        end test_for_symbol;

        function test_for_char_and_digit
            (user_password in   varchar)
            return boolean
            is
            char_found      boolean := false;
            digit_found     boolean := false;
        begin
            for lcv1 in 1 .. my_uletter_count loop
                for lcv2 in 1 .. length(user_password) loop
                    if (substr(user_password, lcv2, 1) = my_uletters(lcv1)) or
                        (substr(user_password, lcv2, 1) = my_lletters(lcv1)) then
                        char_found := true;
                    end if;
                end loop;
            end loop;

            for lcv1 in 1 .. my_digits_count loop
                for lcv2 in 1 .. length(user_password) loop
                    if substr(user_password, lcv2, 1) = my_digits(lcv1) then
                        digit_found := true;
                    end if;
                end loop;
            end loop;

            if digit_found and char_found then
                return true;
            else
                return false;
            end if;
        end test_for_char_and_digit;

        function test_for_upper_and_lower
            (user_password  in  varchar)
            return boolean
            is
            upper_found     boolean := false;
            lower_found     boolean := false;
        begin
            for lcv1 in 1 .. my_uletter_count loop  -- for each upper case letter
                for lcv2 in 1 .. length(user_password) loop -- for each letter in the password
                    if (substr(user_password, lcv2, 1) = my_uletters(lcv1)) then
                        -- if this upper case letter matches this character in the password
                        upper_found := true;    -- flag the ccondition as having been met
                    end if;
                end loop;
            end loop;

            for lcv1 in 1 .. my_lletter_count loop  -- for each lower case letter
                for lcv2 in 1 .. length(user_password) loop -- for each letter in the password
                    if (substr(user_password, lcv2, 1) = my_lletters(lcv1)) then
                        -- if this lower case letter matches this character in the password
                        lower_found := true;    -- flag the ccondition as having been met
                    end if;
                end loop;
            end loop;

            if upper_found and lower_found then
                return true;
            else
                return false;
            end if;
        end test_for_upper_and_lower;

       procedure check_length 
            (user_password  in  varchar)
        is
            -- this routine checks whether passsword length is accceptable; i.e. GE 8
            -- if not score zero and post an issue to the my_issues table
            -- if acceptable then score 15 plus one for each additional character length
            password_length integer;
        begin
            -- determine the length of the potential password
            select length(user_password) into password_length from dual;
            -- score that length
            if password_length < 8 then
                -- password is too short
                my_issue_count := my_issue_count + 1;
                my_issues(my_issue_count) := 'Password is too short.';
            else
                password_score := password_score + 15 + length(user_password) - 8;
            end if;
        end;

        procedure populate_arrays is
        begin
            -- keyboard symbols are ASCII 33 through 47 and 91 through 95 and 123 through 126
            for lcv in 33 .. 47 loop
                my_symbol_count := my_symbol_count + 1;
                my_symbols(my_symbol_count) := chr(lcv); 
            end loop;
            for lcv in 91 .. 95 loop
                my_symbol_count := my_symbol_count + 1;
                my_symbols(my_symbol_count) := chr(lcv); 
            end loop;
            for lcv in 123 .. 126 loop
                my_symbol_count := my_symbol_count + 1;
                my_symbols(my_symbol_count) := chr(lcv); 
            end loop;
            -- upper case letters are ASCII 65 through 90
            for lcv in 65 .. 90 loop
                my_uletter_count := lcv - 64;
                my_uletters(my_uletter_count) := chr(lcv);
            end loop;
            -- lower case letters are ASCII 97 through 122
            for lcv in 97 .. 122 loop
                my_lletter_count := my_lletter_count + 1;
                my_lletters(my_lletter_count) := chr(lcv);
            end loop;
            -- digits are ASCII values 48 through 57
            for lcv in 48 .. 57 loop
                my_digits_count := my_digits_count + 1;
                my_digits(my_digits_count) := chr(lcv);
            end loop;
        end populate_arrays;

    begin
        populate_arrays;

        -- length check is worth 25 + 1 for each char beyond 8
        check_length(user_password);

        -- if both upper and lower case characters exist add 25 to the running total
        if test_for_upper_and_lower(user_password) then
            password_score := password_score + 25;  -- fix the bug here
        else
            my_issue_count := my_issue_count + 1;
            my_issues(my_issue_count) := 'Missing both lower and upper case chars';
        end if;

        -- if both characters and digits exist add 25 to running total
        if test_for_char_and_digit(user_password) then
            password_score := password_score + 25;
        else
            my_issue_count := my_issue_count + 1;
            my_issues(my_issue_count) := 'Missing both char and digit combination.';
        end if;   

        -- if we have at least one embedded symbol add 25
        if test_for_symbol(user_password) then
            password_score := password_score + 25;
        else
            my_issue_count := my_issue_count + 1;
            my_issues(my_issue_count) := 'Missing at least one symbol.';
        end if;   

        -- if we have included either < or > set issue 
        if test_for_gt_or_lt(user_password) then
            password_score := 0;
            my_issue_count := my_issue_count + 1;
            my_issues(my_issue_count) := 'Illegal use of < or > symbol.';
        end if;

        if password_score < 0 then -- don't think can happen but we will play it safe
            password_score := 0;
        elsif password_score > 100 then
            password_score := 100;  -- this can definitely happend
        end if;


        my_issues_out := my_issues;
        my_issue_count_out := my_issue_count;

        -- if the user needs access to the issues they can call the overloaded version
        return password_score;

    end calc_password_strength;

    procedure create_new_student
        (first_name         in      varchar,
         last_name          in      varchar,
         email              in      varchar,
         telephone          in      varchar,
         user_password      in      varchar,
         manager_id         in      integer,
         customer_id        in      integer,
         person_id          out     integer,
         my_issues_out      out     my_issues_table,
         my_issue_out_count out     integer) is
     
         my_issues                  my_issues_table;
         my_issue_count             integer := 0;
         my_row_count               integer;
         my_password_strength       integer;
     
         begin
     
            -- first and last names are required fields
            if length(create_new_student.first_name) = 0 then
                my_issue_count := my_issue_count + 1;
                my_issues(my_issue_count) := 'First name is null';
            end if;
            if length(create_new_student.last_name) = 0 then
                my_issue_count := my_issue_count + 1;
                my_issues(my_issue_count) := 'Last name is null';
            end if;
            
            -- if present, then manager_id and customer_id must be valid
            if create_new_student.manager_id is not null then
                select  count(*) into my_row_count
                from    persons
                where   person_id = create_new_student.manager_id;
            
                if my_row_count = 0 then
                    my_issue_count := my_issue_count + 1;
                    my_issues(my_issue_count) := 'Manager_ID is invalid.';
                end if;
            end if;                
            
            if create_new_student.customer_id is not null then
                select  count(*) into my_row_count
                from    customers
                where   customer_id = create_new_student.customer_id;
            
                if my_row_count = 0 then
                    my_issue_count := my_issue_count + 1;
                    my_issues(my_issue_count) := 'Customer_ID is invalid.';
                end if;
            end if;      

            -- how strong is this password
            select calc_password_strength(create_new_student.user_password) into my_password_strength from dual;
            
            -- if all minimum criterion are met calc_password_strength should return a value of 90
            if my_password_strength < 90 then
                select  calc_password_strength (create_new_student.user_password,my_issues,my_issue_count)
                into    my_password_strength
                from    dual;
            end if;

            -- if my_issue_count is zero then we can insert else return issues
            if my_issue_count = 0 then
            
                insert into persons
                    (person_id, first_name, last_name, email, telephone, 
                     password, password_update, manager_id, customer_id)
                select
                    nvl(max(person_id)+1,1), create_new_student.first_name, create_new_student.last_name,
                    create_new_student.email, create_new_student.telephone, create_new_student.user_password, sysdate,
                    create_new_student.manager_id, create_new_student.customer_id
                from
                    persons;
            
                select max(person_id) into create_new_student.person_id from persons;
                
            else
            
                create_new_student.my_issues_out := my_issues;
                create_new_student.my_issue_out_count := my_issue_count;
                
            end if;
            
        end create_new_student;

    procedure enroll_student
        (person_id          in      integer,
         course_id          in      integer,
         my_issues_out      out     my_issues_table,
         my_issue_out_count out     integer) is
    
        my_issues           my_issues_table;
        my_issue_count      integer := 0;
        record_count        integer;
    
    begin

        -- does this person_id exist
        select  count(*) into record_count
        from    persons
        where   person_id = enroll_student.person_id;
    
        if record_count = 0 then
            my_issue_count := my_issue_count + 1;
            my_issues(my_issue_count) := 'Person_ID does not exist.';
        end if;
    
        -- does this course_id exist
        select  count(*) into record_count
        from    courses
        where   course_id = enroll_student.course_id;
    
        if record_count = 0 then
            my_issue_count := my_issue_count + 1;
            my_issues(my_issue_count) := 'Course_ID does not exist.';
        end if;

        -- do textbooks exist for this course
        select  count(*) into record_count
        from    courses a, textbooks b
        where   a.textbook_id = b.textbook_id
        and     a.course_id = enroll_student.course_id;
        
        if record_count = 0 then
            my_issue_count := my_issue_count + 1;
            my_issues(my_issue_count) := 'No textbooks exist for this course.';
        end if;
        
        if my_issue_count = 0 then
    
            insert into person_course_roles
                (person_id, course_id, role, action_type, action_type_date)
            values
                (enroll_student.person_id, enroll_student.course_id, 'Student','Enroll',sysdate);
         
         else
         
                enroll_student.my_issues_out := my_issues;
                enroll_student.my_issue_out_count := my_issue_count;
         
        end if;
    
    end enroll_student;

end new_student;

-- I don't want to delete persons records because those person_ids are all over the 
-- system as associated with audit tables (update_by_person_id) so let's just add
-- a status field to our persons table
alter table persons add status varchar(25) constraint check_person_status check (status in ('Active','Inactive'));
alter table persons modify status default 'Active';

-- add in the drop_student procedure
create or replace package new_student as

    type my_issues_table is table of varchar(200) index by binary_integer;

    function calc_password_strength(user_password varchar default 'nogood') return integer;
    
    function calc_password_strength
        (user_password      in      varchar     default 'nogood',
        my_issues_out       out     my_issues_table,
        my_issue_count_out  out     integer)    return integer;

    -- note the removal of the student_id column
    procedure create_new_student
        (first_name         in      varchar,
         last_name          in      varchar,
         email              in      varchar,
         telephone          in      varchar,
         user_password      in      varchar,
         manager_id         in      integer,
         customer_id        in      integer,
         person_id          out     integer,
         my_issues_out      out     my_issues_table,
         my_issue_out_count out     integer);
            
    procedure enroll_student
        (person_id          in      integer,
         course_id          in      integer,
         my_issues_out      out     my_issues_table,
         my_issue_out_count out     integer);
         
    procedure drop_student
        (person_id          in          integer,
         my_issues_out      out         my_issues_table,
         my_issue_out_count out     integer);

end new_student;

create or replace package body new_student as

    -- this is our function from chapter 16
    function calc_password_strength
        (user_password  in      varchar default 'nogood')
        return          integer     -- 0 through 100 inclusive wwith 100 max strength
        as
    
        type my_array is table of char(1) index by binary_integer;
        my_symbols      my_array;
        my_uletters     my_array;
        my_lletters     my_array;
        my_digits       my_array;

        my_symbol_count     integer := 0;
        my_uletter_count    integer := 0;
        my_lletter_count    integer := 0;
        my_digits_count     integer := 0;

        -- in our overloaded version of this function we will return this structure as an out parm
        -- type my_issues_table is table of varchar(200) index by binary_integer;
        my_issues           my_issues_table;
        my_issue_count      integer := 0;

        password_score      integer := 0;

        function test_for_gt_or_lt
            (user_password in   varchar)
            return boolean
            is
            found_one   boolean := false;
        begin
            for lcv in 1.. length(user_password) loop
                if substr(user_password, lcv, 1) = chr(60) or  -- ASCII <
                   substr(user_password, lcv, 1) = chr(62) then  -- ASCII >
                    found_one := true;
                end if;
            end loop;
            return found_one;
        end test_for_gt_or_lt;

        function test_for_symbol
            (user_password in   varchar)
            return boolean
            is
            symbol_found    boolean := false;
        begin
            for lcv1 in 1 .. my_symbol_count loop
                for lcv2 in 1 .. length(user_password) loop
                    if substr(user_password, lcv2, 1) = my_symbols(lcv1) then
                        symbol_found := true;
                    end if;
                end loop;
            end loop;
            return symbol_found;
        end test_for_symbol;

        function test_for_char_and_digit
            (user_password in   varchar)
            return boolean
            is
            char_found      boolean := false;
            digit_found     boolean := false;
        begin
            for lcv1 in 1 .. my_uletter_count loop
                for lcv2 in 1 .. length(user_password) loop
                    if (substr(user_password, lcv2, 1) = my_uletters(lcv1)) or
                        (substr(user_password, lcv2, 1) = my_lletters(lcv1)) then
                        char_found := true;
                    end if;
                end loop;
            end loop;

            for lcv1 in 1 .. my_digits_count loop
                for lcv2 in 1 .. length(user_password) loop
                    if substr(user_password, lcv2, 1) = my_digits(lcv1) then
                        digit_found := true;
                    end if;
                end loop;
            end loop;

            if digit_found and char_found then
                return true;
            else
                return false;
            end if;
        end test_for_char_and_digit;

        function test_for_upper_and_lower
            (user_password  in  varchar)
            return boolean
            is
            upper_found     boolean := false;
            lower_found     boolean := false;
        begin
            for lcv1 in 1 .. my_uletter_count loop  -- for each upper case letter
                for lcv2 in 1 .. length(user_password) loop -- for each letter in the password
                    if (substr(user_password, lcv2, 1) = my_uletters(lcv1)) then
                        -- if this upper case letter matches this character in the password
                        upper_found := true;    -- flag the ccondition as having been met
                    end if;
                end loop;
            end loop;

            for lcv1 in 1 .. my_lletter_count loop  -- for each lower case letter
                for lcv2 in 1 .. length(user_password) loop -- for each letter in the password
                    if (substr(user_password, lcv2, 1) = my_lletters(lcv1)) then
                        -- if this lower case letter matches this character in the password
                        lower_found := true;    -- flag the ccondition as having been met
                    end if;
                end loop;
            end loop;

            if upper_found and lower_found then
                return true;
            else
                return false;
            end if;
        end test_for_upper_and_lower;

       procedure check_length 
            (user_password  in  varchar)
        is
            -- this routine checks whether passsword length is accceptable; i.e. GE 8
            -- if not score zero and post an issue to the my_issues table
            -- if acceptable then score 15 plus one for each additional character length
            password_length integer;
        begin
            -- determine the length of the potential password
            select length(user_password) into password_length from dual;
            -- score that length
            if password_length < 8 then
                -- password is too short
                my_issue_count := my_issue_count + 1;
                my_issues(my_issue_count) := 'Password is too short.';
            else
                password_score := password_score + 15 + length(user_password) - 8;
            end if;
        end;

        procedure populate_arrays is
        begin
            -- keyboard symbols are ASCII 33 through 47 and 91 through 95 and 123 through 126
            for lcv in 33 .. 47 loop
                my_symbol_count := my_symbol_count + 1;
                my_symbols(my_symbol_count) := chr(lcv); 
            end loop;
            for lcv in 91 .. 95 loop
                my_symbol_count := my_symbol_count + 1;
                my_symbols(my_symbol_count) := chr(lcv); 
            end loop;
            for lcv in 123 .. 126 loop
                my_symbol_count := my_symbol_count + 1;
                my_symbols(my_symbol_count) := chr(lcv); 
            end loop;
            -- upper case letters are ASCII 65 through 90
            for lcv in 65 .. 90 loop
                my_uletter_count := lcv - 64;
                my_uletters(my_uletter_count) := chr(lcv);
            end loop;
            -- lower case letters are ASCII 97 through 122
            for lcv in 97 .. 122 loop
                my_lletter_count := my_lletter_count + 1;
                my_lletters(my_lletter_count) := chr(lcv);
            end loop;
            -- digits are ASCII values 48 through 57
            for lcv in 48 .. 57 loop
                my_digits_count := my_digits_count + 1;
                my_digits(my_digits_count) := chr(lcv);
            end loop;
        end populate_arrays;

    begin
        populate_arrays;

        -- length check is worth 25 + 1 for each char beyond 8
        check_length(user_password);

        -- if both upper and lower case characters exist add 25 to the running total
        if test_for_upper_and_lower(user_password) then
            password_score := password_score + 25;  -- fix the bug here
        else
            my_issue_count := my_issue_count + 1;
            my_issues(my_issue_count) := 'Missing both lower and upper case chars';
        end if;

        -- if both characters and digits exist add 25 to running total
        if test_for_char_and_digit(user_password) then
            password_score := password_score + 25;
        else
            my_issue_count := my_issue_count + 1;
            my_issues(my_issue_count) := 'Missing both char and digit combination.';
        end if;   

        -- if we have at least one embedded symbol add 25
        if test_for_symbol(user_password) then
            password_score := password_score + 25;
        else
            my_issue_count := my_issue_count + 1;
            my_issues(my_issue_count) := 'Missing at least one symbol.';
        end if;   

        -- if we have included either < or > set issue 
        if test_for_gt_or_lt(user_password) then
            password_score := 0;
            my_issue_count := my_issue_count + 1;
            my_issues(my_issue_count) := 'Illegal use of < or > symbol.';
        end if;

        if password_score < 0 then -- don't think can happen but we will play it safe
            password_score := 0;
        elsif password_score > 100 then
            password_score := 100;  -- this can definitely happend
        end if;

        -- if the user needs access to the issues they can call the overloaded version
        return password_score;

    end calc_password_strength;

    -- now the overloaded version
    function calc_password_strength
        (user_password          in      varchar default 'nogood',
         my_issues_out          out     my_issues_table,
         my_issue_count_out     out     integer)
        return          integer     -- 0 through 100 inclusive wwith 100 max strength
        as

        type my_array is table of char(1) index by binary_integer;
        my_symbols      my_array;
        my_uletters     my_array;
        my_lletters     my_array;
        my_digits       my_array;

        my_symbol_count     integer := 0;
        my_uletter_count    integer := 0;
        my_lletter_count    integer := 0;
        my_digits_count     integer := 0;

        -- in our overloaded version of this function we will return this structure as an out parm
        -- type my_issues_table is table of varchar(200) index by binary_integer; no longer needed
        my_issues           my_issues_table;
        my_issue_count      integer := 0;

        password_score      integer := 0;

        function test_for_gt_or_lt
            (user_password in   varchar)
            return boolean
            is
            found_one   boolean := false;
        begin
            for lcv in 1.. length(user_password) loop
                if substr(user_password, lcv, 1) = chr(60) or  -- ASCII <
                   substr(user_password, lcv, 1) = chr(62) then  -- ASCII >
                    found_one := true;
                end if;
            end loop;
            return found_one;
        end test_for_gt_or_lt;

        function test_for_symbol
            (user_password in   varchar)
            return boolean
            is
            symbol_found    boolean := false;
        begin
            for lcv1 in 1 .. my_symbol_count loop
                for lcv2 in 1 .. length(user_password) loop
                    if substr(user_password, lcv2, 1) = my_symbols(lcv1) then
                        symbol_found := true;
                    end if;
                end loop;
            end loop;
            return symbol_found;
        end test_for_symbol;

        function test_for_char_and_digit
            (user_password in   varchar)
            return boolean
            is
            char_found      boolean := false;
            digit_found     boolean := false;
        begin
            for lcv1 in 1 .. my_uletter_count loop
                for lcv2 in 1 .. length(user_password) loop
                    if (substr(user_password, lcv2, 1) = my_uletters(lcv1)) or
                        (substr(user_password, lcv2, 1) = my_lletters(lcv1)) then
                        char_found := true;
                    end if;
                end loop;
            end loop;

            for lcv1 in 1 .. my_digits_count loop
                for lcv2 in 1 .. length(user_password) loop
                    if substr(user_password, lcv2, 1) = my_digits(lcv1) then
                        digit_found := true;
                    end if;
                end loop;
            end loop;

            if digit_found and char_found then
                return true;
            else
                return false;
            end if;
        end test_for_char_and_digit;

        function test_for_upper_and_lower
            (user_password  in  varchar)
            return boolean
            is
            upper_found     boolean := false;
            lower_found     boolean := false;
        begin
            for lcv1 in 1 .. my_uletter_count loop  -- for each upper case letter
                for lcv2 in 1 .. length(user_password) loop -- for each letter in the password
                    if (substr(user_password, lcv2, 1) = my_uletters(lcv1)) then
                        -- if this upper case letter matches this character in the password
                        upper_found := true;    -- flag the ccondition as having been met
                    end if;
                end loop;
            end loop;

            for lcv1 in 1 .. my_lletter_count loop  -- for each lower case letter
                for lcv2 in 1 .. length(user_password) loop -- for each letter in the password
                    if (substr(user_password, lcv2, 1) = my_lletters(lcv1)) then
                        -- if this lower case letter matches this character in the password
                        lower_found := true;    -- flag the ccondition as having been met
                    end if;
                end loop;
            end loop;

            if upper_found and lower_found then
                return true;
            else
                return false;
            end if;
        end test_for_upper_and_lower;

       procedure check_length 
            (user_password  in  varchar)
        is
            -- this routine checks whether passsword length is accceptable; i.e. GE 8
            -- if not score zero and post an issue to the my_issues table
            -- if acceptable then score 15 plus one for each additional character length
            password_length integer;
        begin
            -- determine the length of the potential password
            select length(user_password) into password_length from dual;
            -- score that length
            if password_length < 8 then
                -- password is too short
                my_issue_count := my_issue_count + 1;
                my_issues(my_issue_count) := 'Password is too short.';
            else
                password_score := password_score + 15 + length(user_password) - 8;
            end if;
        end;

        procedure populate_arrays is
        begin
            -- keyboard symbols are ASCII 33 through 47 and 91 through 95 and 123 through 126
            for lcv in 33 .. 47 loop
                my_symbol_count := my_symbol_count + 1;
                my_symbols(my_symbol_count) := chr(lcv); 
            end loop;
            for lcv in 91 .. 95 loop
                my_symbol_count := my_symbol_count + 1;
                my_symbols(my_symbol_count) := chr(lcv); 
            end loop;
            for lcv in 123 .. 126 loop
                my_symbol_count := my_symbol_count + 1;
                my_symbols(my_symbol_count) := chr(lcv); 
            end loop;
            -- upper case letters are ASCII 65 through 90
            for lcv in 65 .. 90 loop
                my_uletter_count := lcv - 64;
                my_uletters(my_uletter_count) := chr(lcv);
            end loop;
            -- lower case letters are ASCII 97 through 122
            for lcv in 97 .. 122 loop
                my_lletter_count := my_lletter_count + 1;
                my_lletters(my_lletter_count) := chr(lcv);
            end loop;
            -- digits are ASCII values 48 through 57
            for lcv in 48 .. 57 loop
                my_digits_count := my_digits_count + 1;
                my_digits(my_digits_count) := chr(lcv);
            end loop;
        end populate_arrays;

    begin
        populate_arrays;

        -- length check is worth 25 + 1 for each char beyond 8
        check_length(user_password);

        -- if both upper and lower case characters exist add 25 to the running total
        if test_for_upper_and_lower(user_password) then
            password_score := password_score + 25;  -- fix the bug here
        else
            my_issue_count := my_issue_count + 1;
            my_issues(my_issue_count) := 'Missing both lower and upper case chars';
        end if;

        -- if both characters and digits exist add 25 to running total
        if test_for_char_and_digit(user_password) then
            password_score := password_score + 25;
        else
            my_issue_count := my_issue_count + 1;
            my_issues(my_issue_count) := 'Missing both char and digit combination.';
        end if;   

        -- if we have at least one embedded symbol add 25
        if test_for_symbol(user_password) then
            password_score := password_score + 25;
        else
            my_issue_count := my_issue_count + 1;
            my_issues(my_issue_count) := 'Missing at least one symbol.';
        end if;   

        -- if we have included either < or > set issue 
        if test_for_gt_or_lt(user_password) then
            password_score := 0;
            my_issue_count := my_issue_count + 1;
            my_issues(my_issue_count) := 'Illegal use of < or > symbol.';
        end if;

        if password_score < 0 then -- don't think can happen but we will play it safe
            password_score := 0;
        elsif password_score > 100 then
            password_score := 100;  -- this can definitely happend
        end if;


        my_issues_out := my_issues;
        my_issue_count_out := my_issue_count;

        -- if the user needs access to the issues they can call the overloaded version
        return password_score;

    end calc_password_strength;

    procedure create_new_student
        (first_name         in      varchar,
         last_name          in      varchar,
         email              in      varchar,
         telephone          in      varchar,
         user_password      in      varchar,
         manager_id         in      integer,
         customer_id        in      integer,
         person_id          out     integer,
         my_issues_out      out     my_issues_table,
         my_issue_out_count out     integer) is
     
         my_issues                  my_issues_table;
         my_issue_count             integer := 0;
         my_row_count               integer;
         my_password_strength       integer;
     
         begin
     
            -- first and last names are required fields
            if length(create_new_student.first_name) = 0 then
                my_issue_count := my_issue_count + 1;
                my_issues(my_issue_count) := 'First name is null';
            end if;
            if length(create_new_student.last_name) = 0 then
                my_issue_count := my_issue_count + 1;
                my_issues(my_issue_count) := 'Last name is null';
            end if;
            
            -- if present, then manager_id and customer_id must be valid
            if create_new_student.manager_id is not null then
                select  count(*) into my_row_count
                from    persons
                where   person_id = create_new_student.manager_id;
            
                if my_row_count = 0 then
                    my_issue_count := my_issue_count + 1;
                    my_issues(my_issue_count) := 'Manager_ID is invalid.';
                end if;
            end if;                
            
            if create_new_student.customer_id is not null then
                select  count(*) into my_row_count
                from    customers
                where   customer_id = create_new_student.customer_id;
            
                if my_row_count = 0 then
                    my_issue_count := my_issue_count + 1;
                    my_issues(my_issue_count) := 'Customer_ID is invalid.';
                end if;
            end if;      

            -- how strong is this password
            select calc_password_strength(create_new_student.user_password) into my_password_strength from dual;
            
            -- if all minimum criterion are met calc_password_strength should return a value of 90
            if my_password_strength < 90 then
                select  calc_password_strength (create_new_student.user_password,my_issues,my_issue_count)
                into    my_password_strength
                from    dual;
            end if;

            -- if my_issue_count is zero then we can insert else return issues
            if my_issue_count = 0 then
            
                insert into persons
                    (person_id, first_name, last_name, email, telephone, 
                     password, password_update, manager_id, customer_id)
                select
                    nvl(max(person_id)+1,1), create_new_student.first_name, create_new_student.last_name,
                    create_new_student.email, create_new_student.telephone, create_new_student.user_password, sysdate,
                    create_new_student.manager_id, create_new_student.customer_id
                from
                    persons;
            
                select max(person_id) into create_new_student.person_id from persons;
                
            else
            
                create_new_student.my_issues_out := my_issues;
                create_new_student.my_issue_out_count := my_issue_count;
                
            end if;
            
        end create_new_student;

    procedure enroll_student
        (person_id          in      integer,
         course_id          in      integer,
         my_issues_out      out     my_issues_table,
         my_issue_out_count out     integer) is
    
        my_issues           my_issues_table;
        my_issue_count      integer := 0;
        record_count        integer;
    
    begin

        -- does this person_id exist
        select  count(*) into record_count
        from    persons
        where   person_id = enroll_student.person_id;
    
        if record_count = 0 then
            my_issue_count := my_issue_count + 1;
            my_issues(my_issue_count) := 'Person_ID does not exist.';
        end if;
    
        -- does this course_id exist
        select  count(*) into record_count
        from    courses
        where   course_id = enroll_student.course_id;
    
        if record_count = 0 then
            my_issue_count := my_issue_count + 1;
            my_issues(my_issue_count) := 'Course_ID does not exist.';
        end if;

        -- do textbooks exist for this course
        select  count(*) into record_count
        from    courses a, textbooks b
        where   a.textbook_id = b.textbook_id
        and     a.course_id = enroll_student.course_id;
        
        if record_count = 0 then
            my_issue_count := my_issue_count + 1;
            my_issues(my_issue_count) := 'No textbooks exist for this course.';
        end if;
        
        if my_issue_count = 0 then
    
            insert into person_course_roles
                (person_id, course_id, role, action_type, action_type_date)
            values
                (enroll_student.person_id, enroll_student.course_id, 'Student','Enroll',sysdate);
                            
        end if;
    
    end enroll_student;

    procedure drop_student
        (person_id          in      integer,
         my_issues_out      out     my_issues_table,
         my_issue_out_count out     integer) is
    
        my_issues           my_issues_table;
        my_issue_count      integer := 0;
        record_count        integer;
    
    begin

        select  count(*) into record_count
        from    persons
        where   person_id = drop_student.person_id;
    
        if record_count = 0 then
            my_issue_count := my_issue_count + 1;
            my_issues(my_issue_count) := 'Person_ID does not exist.';
        end if;

        if my_issue_count > 0 then
    
            -- these updated records will go to audit table
            update  person_course_roles
            set     action_type = 'Drop Course',
                    action_type_date = sysdate
            where   person_id = drop_student.person_id;
    
            delete  from person_course_roles
            where   person_id = drop_student.person_id;
        
            update  persons
            set     status = 'Inactive'
            where   person_id = drop_student.person_id;
        else
    
            my_issues_out := my_issues;
            my_issue_out_count := my_issue_count;
        
        end if;
    
    end drop_student;

end new_student;

-- finally add in the change_password routine
create or replace package new_student as

    type my_issues_table is table of varchar(200) index by binary_integer;

    function calc_password_strength(user_password varchar default 'nogood') return integer;
    
    function calc_password_strength
        (user_password      in      varchar     default 'nogood',
        my_issues_out       out     my_issues_table,
        my_issue_count_out  out     integer)    return integer;

    -- note the removal of the student_id column
    procedure create_new_student
        (first_name         in      varchar,
         last_name          in      varchar,
         email              in      varchar,
         telephone          in      varchar,
         user_password      in      varchar,
         manager_id         in      integer,
         customer_id        in      integer,
         person_id          out     integer,
         my_issues_out      out     my_issues_table,
         my_issue_out_count out     integer);
            
    procedure enroll_student
        (person_id          in      integer,
         course_id          in      integer,
         my_issues_out      out     my_issues_table,
         my_issue_out_count out     integer);
         
    procedure drop_student
        (person_id          in          integer,
         my_issues_out      out         my_issues_table,
         my_issue_out_count out     integer);

    procedure change_password
            (person_id          in          integer,
            new_password        in          varchar default 'nogood',
            my_issues_out       out         my_issues_table,
            my_issue_out_count  out         integer);
            
end new_student;

create or replace package body new_student as

    -- this is our function from chapter 16
    function calc_password_strength
        (user_password  in      varchar default 'nogood')
        return          integer     -- 0 through 100 inclusive wwith 100 max strength
        as
    
        type my_array is table of char(1) index by binary_integer;
        my_symbols      my_array;
        my_uletters     my_array;
        my_lletters     my_array;
        my_digits       my_array;

        my_symbol_count     integer := 0;
        my_uletter_count    integer := 0;
        my_lletter_count    integer := 0;
        my_digits_count     integer := 0;

        -- in our overloaded version of this function we will return this structure as an out parm
        -- type my_issues_table is table of varchar(200) index by binary_integer;
        my_issues           my_issues_table;
        my_issue_count      integer := 0;

        password_score      integer := 0;

        function test_for_gt_or_lt
            (user_password in   varchar)
            return boolean
            is
            found_one   boolean := false;
        begin
            for lcv in 1.. length(user_password) loop
                if substr(user_password, lcv, 1) = chr(60) or  -- ASCII <
                   substr(user_password, lcv, 1) = chr(62) then  -- ASCII >
                    found_one := true;
                end if;
            end loop;
            return found_one;
        end test_for_gt_or_lt;

        function test_for_symbol
            (user_password in   varchar)
            return boolean
            is
            symbol_found    boolean := false;
        begin
            for lcv1 in 1 .. my_symbol_count loop
                for lcv2 in 1 .. length(user_password) loop
                    if substr(user_password, lcv2, 1) = my_symbols(lcv1) then
                        symbol_found := true;
                    end if;
                end loop;
            end loop;
            return symbol_found;
        end test_for_symbol;

        function test_for_char_and_digit
            (user_password in   varchar)
            return boolean
            is
            char_found      boolean := false;
            digit_found     boolean := false;
        begin
            for lcv1 in 1 .. my_uletter_count loop
                for lcv2 in 1 .. length(user_password) loop
                    if (substr(user_password, lcv2, 1) = my_uletters(lcv1)) or
                        (substr(user_password, lcv2, 1) = my_lletters(lcv1)) then
                        char_found := true;
                    end if;
                end loop;
            end loop;

            for lcv1 in 1 .. my_digits_count loop
                for lcv2 in 1 .. length(user_password) loop
                    if substr(user_password, lcv2, 1) = my_digits(lcv1) then
                        digit_found := true;
                    end if;
                end loop;
            end loop;

            if digit_found and char_found then
                return true;
            else
                return false;
            end if;
        end test_for_char_and_digit;

        function test_for_upper_and_lower
            (user_password  in  varchar)
            return boolean
            is
            upper_found     boolean := false;
            lower_found     boolean := false;
        begin
            for lcv1 in 1 .. my_uletter_count loop  -- for each upper case letter
                for lcv2 in 1 .. length(user_password) loop -- for each letter in the password
                    if (substr(user_password, lcv2, 1) = my_uletters(lcv1)) then
                        -- if this upper case letter matches this character in the password
                        upper_found := true;    -- flag the ccondition as having been met
                    end if;
                end loop;
            end loop;

            for lcv1 in 1 .. my_lletter_count loop  -- for each lower case letter
                for lcv2 in 1 .. length(user_password) loop -- for each letter in the password
                    if (substr(user_password, lcv2, 1) = my_lletters(lcv1)) then
                        -- if this lower case letter matches this character in the password
                        lower_found := true;    -- flag the ccondition as having been met
                    end if;
                end loop;
            end loop;

            if upper_found and lower_found then
                return true;
            else
                return false;
            end if;
        end test_for_upper_and_lower;

       procedure check_length 
            (user_password  in  varchar)
        is
            -- this routine checks whether passsword length is accceptable; i.e. GE 8
            -- if not score zero and post an issue to the my_issues table
            -- if acceptable then score 15 plus one for each additional character length
            password_length integer;
        begin
            -- determine the length of the potential password
            select length(user_password) into password_length from dual;
            -- score that length
            if password_length < 8 then
                -- password is too short
                my_issue_count := my_issue_count + 1;
                my_issues(my_issue_count) := 'Password is too short.';
            else
                password_score := password_score + 15 + length(user_password) - 8;
            end if;
        end;

        procedure populate_arrays is
        begin
            -- keyboard symbols are ASCII 33 through 47 and 91 through 95 and 123 through 126
            for lcv in 33 .. 47 loop
                my_symbol_count := my_symbol_count + 1;
                my_symbols(my_symbol_count) := chr(lcv); 
            end loop;
            for lcv in 91 .. 95 loop
                my_symbol_count := my_symbol_count + 1;
                my_symbols(my_symbol_count) := chr(lcv); 
            end loop;
            for lcv in 123 .. 126 loop
                my_symbol_count := my_symbol_count + 1;
                my_symbols(my_symbol_count) := chr(lcv); 
            end loop;
            -- upper case letters are ASCII 65 through 90
            for lcv in 65 .. 90 loop
                my_uletter_count := lcv - 64;
                my_uletters(my_uletter_count) := chr(lcv);
            end loop;
            -- lower case letters are ASCII 97 through 122
            for lcv in 97 .. 122 loop
                my_lletter_count := my_lletter_count + 1;
                my_lletters(my_lletter_count) := chr(lcv);
            end loop;
            -- digits are ASCII values 48 through 57
            for lcv in 48 .. 57 loop
                my_digits_count := my_digits_count + 1;
                my_digits(my_digits_count) := chr(lcv);
            end loop;
        end populate_arrays;

    begin
        populate_arrays;

        -- length check is worth 25 + 1 for each char beyond 8
        check_length(user_password);

        -- if both upper and lower case characters exist add 25 to the running total
        if test_for_upper_and_lower(user_password) then
            password_score := password_score + 25;  -- fix the bug here
        else
            my_issue_count := my_issue_count + 1;
            my_issues(my_issue_count) := 'Missing both lower and upper case chars';
        end if;

        -- if both characters and digits exist add 25 to running total
        if test_for_char_and_digit(user_password) then
            password_score := password_score + 25;
        else
            my_issue_count := my_issue_count + 1;
            my_issues(my_issue_count) := 'Missing both char and digit combination.';
        end if;   

        -- if we have at least one embedded symbol add 25
        if test_for_symbol(user_password) then
            password_score := password_score + 25;
        else
            my_issue_count := my_issue_count + 1;
            my_issues(my_issue_count) := 'Missing at least one symbol.';
        end if;   

        -- if we have included either < or > set issue 
        if test_for_gt_or_lt(user_password) then
            password_score := 0;
            my_issue_count := my_issue_count + 1;
            my_issues(my_issue_count) := 'Illegal use of < or > symbol.';
        end if;

        if password_score < 0 then -- don't think can happen but we will play it safe
            password_score := 0;
        elsif password_score > 100 then
            password_score := 100;  -- this can definitely happend
        end if;

        -- if the user needs access to the issues they can call the overloaded version
        return password_score;

    end calc_password_strength;

    -- now the overloaded version
    function calc_password_strength
        (user_password          in      varchar default 'nogood',
         my_issues_out          out     my_issues_table,
         my_issue_count_out     out     integer)
        return          integer     -- 0 through 100 inclusive wwith 100 max strength
        as

        type my_array is table of char(1) index by binary_integer;
        my_symbols      my_array;
        my_uletters     my_array;
        my_lletters     my_array;
        my_digits       my_array;

        my_symbol_count     integer := 0;
        my_uletter_count    integer := 0;
        my_lletter_count    integer := 0;
        my_digits_count     integer := 0;

        -- in our overloaded version of this function we will return this structure as an out parm
        -- type my_issues_table is table of varchar(200) index by binary_integer; no longer needed
        my_issues           my_issues_table;
        my_issue_count      integer := 0;

        password_score      integer := 0;

        function test_for_gt_or_lt
            (user_password in   varchar)
            return boolean
            is
            found_one   boolean := false;
        begin
            for lcv in 1.. length(user_password) loop
                if substr(user_password, lcv, 1) = chr(60) or  -- ASCII <
                   substr(user_password, lcv, 1) = chr(62) then  -- ASCII >
                    found_one := true;
                end if;
            end loop;
            return found_one;
        end test_for_gt_or_lt;

        function test_for_symbol
            (user_password in   varchar)
            return boolean
            is
            symbol_found    boolean := false;
        begin
            for lcv1 in 1 .. my_symbol_count loop
                for lcv2 in 1 .. length(user_password) loop
                    if substr(user_password, lcv2, 1) = my_symbols(lcv1) then
                        symbol_found := true;
                    end if;
                end loop;
            end loop;
            return symbol_found;
        end test_for_symbol;

        function test_for_char_and_digit
            (user_password in   varchar)
            return boolean
            is
            char_found      boolean := false;
            digit_found     boolean := false;
        begin
            for lcv1 in 1 .. my_uletter_count loop
                for lcv2 in 1 .. length(user_password) loop
                    if (substr(user_password, lcv2, 1) = my_uletters(lcv1)) or
                        (substr(user_password, lcv2, 1) = my_lletters(lcv1)) then
                        char_found := true;
                    end if;
                end loop;
            end loop;

            for lcv1 in 1 .. my_digits_count loop
                for lcv2 in 1 .. length(user_password) loop
                    if substr(user_password, lcv2, 1) = my_digits(lcv1) then
                        digit_found := true;
                    end if;
                end loop;
            end loop;

            if digit_found and char_found then
                return true;
            else
                return false;
            end if;
        end test_for_char_and_digit;

        function test_for_upper_and_lower
            (user_password  in  varchar)
            return boolean
            is
            upper_found     boolean := false;
            lower_found     boolean := false;
        begin
            for lcv1 in 1 .. my_uletter_count loop  -- for each upper case letter
                for lcv2 in 1 .. length(user_password) loop -- for each letter in the password
                    if (substr(user_password, lcv2, 1) = my_uletters(lcv1)) then
                        -- if this upper case letter matches this character in the password
                        upper_found := true;    -- flag the ccondition as having been met
                    end if;
                end loop;
            end loop;

            for lcv1 in 1 .. my_lletter_count loop  -- for each lower case letter
                for lcv2 in 1 .. length(user_password) loop -- for each letter in the password
                    if (substr(user_password, lcv2, 1) = my_lletters(lcv1)) then
                        -- if this lower case letter matches this character in the password
                        lower_found := true;    -- flag the ccondition as having been met
                    end if;
                end loop;
            end loop;

            if upper_found and lower_found then
                return true;
            else
                return false;
            end if;
        end test_for_upper_and_lower;

       procedure check_length 
            (user_password  in  varchar)
        is
            -- this routine checks whether passsword length is accceptable; i.e. GE 8
            -- if not score zero and post an issue to the my_issues table
            -- if acceptable then score 15 plus one for each additional character length
            password_length integer;
        begin
            -- determine the length of the potential password
            select length(user_password) into password_length from dual;
            -- score that length
            if password_length < 8 then
                -- password is too short
                my_issue_count := my_issue_count + 1;
                my_issues(my_issue_count) := 'Password is too short.';
            else
                password_score := password_score + 15 + length(user_password) - 8;
            end if;
        end;

        procedure populate_arrays is
        begin
            -- keyboard symbols are ASCII 33 through 47 and 91 through 95 and 123 through 126
            for lcv in 33 .. 47 loop
                my_symbol_count := my_symbol_count + 1;
                my_symbols(my_symbol_count) := chr(lcv); 
            end loop;
            for lcv in 91 .. 95 loop
                my_symbol_count := my_symbol_count + 1;
                my_symbols(my_symbol_count) := chr(lcv); 
            end loop;
            for lcv in 123 .. 126 loop
                my_symbol_count := my_symbol_count + 1;
                my_symbols(my_symbol_count) := chr(lcv); 
            end loop;
            -- upper case letters are ASCII 65 through 90
            for lcv in 65 .. 90 loop
                my_uletter_count := lcv - 64;
                my_uletters(my_uletter_count) := chr(lcv);
            end loop;
            -- lower case letters are ASCII 97 through 122
            for lcv in 97 .. 122 loop
                my_lletter_count := my_lletter_count + 1;
                my_lletters(my_lletter_count) := chr(lcv);
            end loop;
            -- digits are ASCII values 48 through 57
            for lcv in 48 .. 57 loop
                my_digits_count := my_digits_count + 1;
                my_digits(my_digits_count) := chr(lcv);
            end loop;
        end populate_arrays;

    begin
        populate_arrays;

        -- length check is worth 25 + 1 for each char beyond 8
        check_length(user_password);

        -- if both upper and lower case characters exist add 25 to the running total
        if test_for_upper_and_lower(user_password) then
            password_score := password_score + 25;  -- fix the bug here
        else
            my_issue_count := my_issue_count + 1;
            my_issues(my_issue_count) := 'Missing both lower and upper case chars';
        end if;

        -- if both characters and digits exist add 25 to running total
        if test_for_char_and_digit(user_password) then
            password_score := password_score + 25;
        else
            my_issue_count := my_issue_count + 1;
            my_issues(my_issue_count) := 'Missing both char and digit combination.';
        end if;   

        -- if we have at least one embedded symbol add 25
        if test_for_symbol(user_password) then
            password_score := password_score + 25;
        else
            my_issue_count := my_issue_count + 1;
            my_issues(my_issue_count) := 'Missing at least one symbol.';
        end if;   

        -- if we have included either < or > set issue 
        if test_for_gt_or_lt(user_password) then
            password_score := 0;
            my_issue_count := my_issue_count + 1;
            my_issues(my_issue_count) := 'Illegal use of < or > symbol.';
        end if;

        if password_score < 0 then -- don't think can happen but we will play it safe
            password_score := 0;
        elsif password_score > 100 then
            password_score := 100;  -- this can definitely happend
        end if;


        my_issues_out := my_issues;
        my_issue_count_out := my_issue_count;

        -- if the user needs access to the issues they can call the overloaded version
        return password_score;

    end calc_password_strength;

    procedure create_new_student
        (first_name         in      varchar,
         last_name          in      varchar,
         email              in      varchar,
         telephone          in      varchar,
         user_password      in      varchar,
         manager_id         in      integer,
         customer_id        in      integer,
         person_id          out     integer,
         my_issues_out      out     my_issues_table,
         my_issue_out_count out     integer) is
     
         my_issues                  my_issues_table;
         my_issue_count             integer := 0;
         my_row_count               integer;
         my_password_strength       integer;
     
         begin
     
            -- first and last names are required fields
            if length(create_new_student.first_name) = 0 then
                my_issue_count := my_issue_count + 1;
                my_issues(my_issue_count) := 'First name is null';
            end if;
            if length(create_new_student.last_name) = 0 then
                my_issue_count := my_issue_count + 1;
                my_issues(my_issue_count) := 'Last name is null';
            end if;
            
            -- if present, then manager_id and customer_id must be valid
            if create_new_student.manager_id is not null then
                select  count(*) into my_row_count
                from    persons
                where   person_id = create_new_student.manager_id;
            
                if my_row_count = 0 then
                    my_issue_count := my_issue_count + 1;
                    my_issues(my_issue_count) := 'Manager_ID is invalid.';
                end if;
            end if;                
            
            if create_new_student.customer_id is not null then
                select  count(*) into my_row_count
                from    customers
                where   customer_id = create_new_student.customer_id;
            
                if my_row_count = 0 then
                    my_issue_count := my_issue_count + 1;
                    my_issues(my_issue_count) := 'Customer_ID is invalid.';
                end if;
            end if;      

            -- how strong is this password
            select calc_password_strength(create_new_student.user_password) into my_password_strength from dual;
            
            -- if all minimum criterion are met calc_password_strength should return a value of 90
            if my_password_strength < 90 then
                select  calc_password_strength (create_new_student.user_password,my_issues,my_issue_count)
                into    my_password_strength
                from    dual;
            end if;

            -- if my_issue_count is zero then we can insert else return issues
            if my_issue_count = 0 then
            
                insert into persons
                    (person_id, first_name, last_name, email, telephone, 
                     password, password_update, manager_id, customer_id)
                select
                    nvl(max(person_id)+1,1), create_new_student.first_name, create_new_student.last_name,
                    create_new_student.email, create_new_student.telephone, create_new_student.user_password, sysdate,
                    create_new_student.manager_id, create_new_student.customer_id
                from
                    persons;
            
                select max(person_id) into create_new_student.person_id from persons;
                
            else
            
                create_new_student.my_issues_out := my_issues;
                create_new_student.my_issue_out_count := my_issue_count;
                
            end if;
            
        end create_new_student;

    procedure enroll_student
        (person_id          in      integer,
         course_id          in      integer,
         my_issues_out      out     my_issues_table,
         my_issue_out_count out     integer) is
    
        my_issues           my_issues_table;
        my_issue_count      integer := 0;
        record_count        integer;
    
    begin

        -- does this person_id exist
        select  count(*) into record_count
        from    persons
        where   person_id = enroll_student.person_id;
    
        if record_count = 0 then
            my_issue_count := my_issue_count + 1;
            my_issues(my_issue_count) := 'Person_ID does not exist.';
        end if;
    
        -- does this course_id exist
        select  count(*) into record_count
        from    courses
        where   course_id = enroll_student.course_id;
    
        if record_count = 0 then
            my_issue_count := my_issue_count + 1;
            my_issues(my_issue_count) := 'Course_ID does not exist.';
        end if;

        -- do textbooks exist for this course
        select  count(*) into record_count
        from    courses a, textbooks b
        where   a.textbook_id = b.textbook_id
        and     a.course_id = enroll_student.course_id;
        
        if record_count = 0 then
            my_issue_count := my_issue_count + 1;
            my_issues(my_issue_count) := 'No textbooks exist for this course.';
        end if;
        
        if my_issue_count = 0 then
    
            insert into person_course_roles
                (person_id, course_id, role, action_type, action_type_date)
            values
                (enroll_student.person_id, enroll_student.course_id, 'Student','Enroll',sysdate);
                            
        end if;
    
    end enroll_student;

    procedure drop_student
        (person_id          in      integer,
         my_issues_out      out     my_issues_table,
         my_issue_out_count out     integer) is
    
        my_issues           my_issues_table;
        my_issue_count      integer;
        record_count        integer;
    
    begin

        select  count(*) into record_count
        from    persons
        where   person_id = drop_student.person_id;
    
        if record_count = 0 then
            my_issue_count := my_issue_count + 1;
            my_issues(my_issue_count) := 'Person_ID does not exist.';
        end if;

        if my_issue_count > 0 then
    
            -- these updated records will go to audit table
            update  person_course_roles
            set     action_type = 'Drop Course',
                    action_type_date = sysdate
            where   person_id = drop_student.person_id;
    
            delete  from person_course_roles
            where   person_id = drop_student.person_id;
        
            update  persons
            set     status = 'Inactive'
            where   person_id = drop_student.person_id;
        else
    
            my_issues_out := my_issues;
            my_issue_out_count := my_issue_count;
        
        end if;
    
    end drop_student;

    procedure change_password
            (person_id          in          integer,
            new_password        in          varchar default 'nogood',
            my_issues_out       out         my_issues_table,
            my_issue_out_count  out         integer) is

            my_issues           my_issues_table;
            my_issue_count      integer := 0;
            password_strength   integer;
            record_count        integer;
    begin
            
            -- does this person exist
            select  count(*) into record_count
            from    persons
            where   person_id = change_password.new_password
            and     status = 'Active';
            
            if record_count = 0 then
                my_issue_count := my_issue_count + 1;
                my_issues(my_issue_count) := 'Persons record does not exist.';
            end if;
                
            password_strength := calc_password_strength (change_password.new_password);
            
            if password_strength < 90  or record_count = 0 then
            
                password_strength := calc_password_strength (
                    user_password       =>      change_password.new_password,
                    my_issues_out       =>      my_issues,
                    my_issue_count_out  =>      my_issue_count);
                 
                 -- output the issues   
                my_issues_out := my_issues;
                my_issue_out_count := my_issue_count;
                
            else
            
                -- go ahead and make the password change
                update  persons
                set     password = change_password.new_password,
                        password_update = sysdate
                where   person_id = change_password.person_id;

            end if;                    
    end change_password;

end new_student;

-- time to run some alpha tests
create or replace procedure test_new_student_package as

    password_strength       integer := 0;

    --type my_issues_table is table of varchar(200) index by binary_integer;
    my_issues       new_student.my_issues_table;
    my_issue_count  integer;
    
begin

    -- pass none of the password_strength criteria
    password_strength := new_student.calc_password_strength ('nogood');
    dbms_output.put_line ('password strength of nogood = ' || password_strength);

    -- pass the length test
    password_strength := new_student.calc_password_strength ('isbetterthansome');
    dbms_output.put_line ('password strength of nogood = ' || password_strength);
    
    -- pass the upper and lower case tests
    password_strength := new_student.calc_password_strength ('ISbetter');
    dbms_output.put_line ('password strength of nogood = ' || password_strength);

    -- characters and digits
    password_strength := new_student.calc_password_strength ('ISbe12er');
    dbms_output.put_line ('password strength of nogood = ' || password_strength);

    -- at least one symbol
    password_strength := new_student.calc_password_strength ('ISb*12er');
    dbms_output.put_line ('password strength of nogood = ' || password_strength);

    -- all wrong show issues
    password_strength := new_student.calc_password_strength(
        user_password           =>      'nogood',
        my_issues_out           =>      my_issues,
        my_issue_count_out      =>      my_issue_count);
        
    for lcv in 1..my_issue_count loop
        dbms_output.put_line ('issue number ' || lcv || ' = ' || my_issues(lcv));
    end loop;
    
end;

create or replace NONEDITIONABLE procedure test_new_student_package_v2 as

    my_issues       new_student.my_issues_table;
    my_issue_count  integer;
    my_person_id    integer;

    cursor  get_persons is
    select  first_name, last_name, person_id
    from    persons
    order by last_name, first_name;

    this_person     get_persons%rowtype;

begin

    open get_persons;

    fetch get_persons into this_person;

    while get_persons%FOUND loop
        dbms_output.put_line ('person id ' || this_person.person_id || ' is named ' || this_person.first_name || ' ' || this_person.last_name);
        fetch get_persons into this_person;
    end loop;

    close get_persons;

    -- this should be a good student record
    new_student.create_new_student (
        first_name          =>      'New',
        last_name           =>      'Student',
        email               =>      'test432@gmail.com',
        telephone           =>      '800 123 4567',
        user_password       =>      'Good$Pass12',
        manager_id          =>      1,
        customer_id         =>      1,
        person_id           =>      my_person_id,
        my_issues_out       =>      my_issues,
        my_issue_out_count  =>      my_issue_count);

    open get_persons;

    fetch get_persons into this_person;

    while get_persons%FOUND loop
        dbms_output.put_line ('person id ' || this_person.person_id || ' is named ' || this_person.first_name || ' ' || this_person.last_name);
        fetch get_persons into this_person;
    end loop;

    close get_persons;

    -- this should be a bad student record
    new_student.create_new_student (
        first_name          =>      'New',
        last_name           =>      'Student',
        email               =>      'test432@gmail.com',
        telephone           =>      '800 123 4567',
        user_password       =>      'GoodPass',
        manager_id          =>      -1,
        customer_id         =>      -1,
        person_id           =>      my_person_id,
        my_issues_out       =>      my_issues,
        my_issue_out_count  =>      my_issue_count);

    for lcv in 1 .. my_issue_count loop
        dbms_output.put_line ('issue number ' || lcv || ' was ' || my_issues(lcv));
    end loop;

end;

-- make the update to the create_new_student routine
create or replace package body new_student as

    -- this is our function from chapter 16
    function calc_password_strength
        (user_password  in      varchar default 'nogood')
        return          integer     -- 0 through 100 inclusive wwith 100 max strength
        as
    
        type my_array is table of char(1) index by binary_integer;
        my_symbols      my_array;
        my_uletters     my_array;
        my_lletters     my_array;
        my_digits       my_array;

        my_symbol_count     integer := 0;
        my_uletter_count    integer := 0;
        my_lletter_count    integer := 0;
        my_digits_count     integer := 0;

        -- in our overloaded version of this function we will return this structure as an out parm
        -- type my_issues_table is table of varchar(200) index by binary_integer;
        my_issues           my_issues_table;
        my_issue_count      integer := 0;

        password_score      integer := 0;

        function test_for_gt_or_lt
            (user_password in   varchar)
            return boolean
            is
            found_one   boolean := false;
        begin
            for lcv in 1.. length(user_password) loop
                if substr(user_password, lcv, 1) = chr(60) or  -- ASCII <
                   substr(user_password, lcv, 1) = chr(62) then  -- ASCII >
                    found_one := true;
                end if;
            end loop;
            return found_one;
        end test_for_gt_or_lt;

        function test_for_symbol
            (user_password in   varchar)
            return boolean
            is
            symbol_found    boolean := false;
        begin
            for lcv1 in 1 .. my_symbol_count loop
                for lcv2 in 1 .. length(user_password) loop
                    if substr(user_password, lcv2, 1) = my_symbols(lcv1) then
                        symbol_found := true;
                    end if;
                end loop;
            end loop;
            return symbol_found;
        end test_for_symbol;

        function test_for_char_and_digit
            (user_password in   varchar)
            return boolean
            is
            char_found      boolean := false;
            digit_found     boolean := false;
        begin
            for lcv1 in 1 .. my_uletter_count loop
                for lcv2 in 1 .. length(user_password) loop
                    if (substr(user_password, lcv2, 1) = my_uletters(lcv1)) or
                        (substr(user_password, lcv2, 1) = my_lletters(lcv1)) then
                        char_found := true;
                    end if;
                end loop;
            end loop;

            for lcv1 in 1 .. my_digits_count loop
                for lcv2 in 1 .. length(user_password) loop
                    if substr(user_password, lcv2, 1) = my_digits(lcv1) then
                        digit_found := true;
                    end if;
                end loop;
            end loop;

            if digit_found and char_found then
                return true;
            else
                return false;
            end if;
        end test_for_char_and_digit;

        function test_for_upper_and_lower
            (user_password  in  varchar)
            return boolean
            is
            upper_found     boolean := false;
            lower_found     boolean := false;
        begin
            for lcv1 in 1 .. my_uletter_count loop  -- for each upper case letter
                for lcv2 in 1 .. length(user_password) loop -- for each letter in the password
                    if (substr(user_password, lcv2, 1) = my_uletters(lcv1)) then
                        -- if this upper case letter matches this character in the password
                        upper_found := true;    -- flag the ccondition as having been met
                    end if;
                end loop;
            end loop;

            for lcv1 in 1 .. my_lletter_count loop  -- for each lower case letter
                for lcv2 in 1 .. length(user_password) loop -- for each letter in the password
                    if (substr(user_password, lcv2, 1) = my_lletters(lcv1)) then
                        -- if this lower case letter matches this character in the password
                        lower_found := true;    -- flag the ccondition as having been met
                    end if;
                end loop;
            end loop;

            if upper_found and lower_found then
                return true;
            else
                return false;
            end if;
        end test_for_upper_and_lower;

       procedure check_length 
            (user_password  in  varchar)
        is
            -- this routine checks whether passsword length is accceptable; i.e. GE 8
            -- if not score zero and post an issue to the my_issues table
            -- if acceptable then score 15 plus one for each additional character length
            password_length integer;
        begin
            -- determine the length of the potential password
            select length(user_password) into password_length from dual;
            -- score that length
            if password_length < 8 then
                -- password is too short
                my_issue_count := my_issue_count + 1;
                my_issues(my_issue_count) := 'Password is too short.';
            else
                password_score := password_score + 15 + length(user_password) - 8;
            end if;
        end;

        procedure populate_arrays is
        begin
            -- keyboard symbols are ASCII 33 through 47 and 91 through 95 and 123 through 126
            for lcv in 33 .. 47 loop
                my_symbol_count := my_symbol_count + 1;
                my_symbols(my_symbol_count) := chr(lcv); 
            end loop;
            for lcv in 91 .. 95 loop
                my_symbol_count := my_symbol_count + 1;
                my_symbols(my_symbol_count) := chr(lcv); 
            end loop;
            for lcv in 123 .. 126 loop
                my_symbol_count := my_symbol_count + 1;
                my_symbols(my_symbol_count) := chr(lcv); 
            end loop;
            -- upper case letters are ASCII 65 through 90
            for lcv in 65 .. 90 loop
                my_uletter_count := lcv - 64;
                my_uletters(my_uletter_count) := chr(lcv);
            end loop;
            -- lower case letters are ASCII 97 through 122
            for lcv in 97 .. 122 loop
                my_lletter_count := my_lletter_count + 1;
                my_lletters(my_lletter_count) := chr(lcv);
            end loop;
            -- digits are ASCII values 48 through 57
            for lcv in 48 .. 57 loop
                my_digits_count := my_digits_count + 1;
                my_digits(my_digits_count) := chr(lcv);
            end loop;
        end populate_arrays;

    begin
        populate_arrays;

        -- length check is worth 25 + 1 for each char beyond 8
        check_length(user_password);

        -- if both upper and lower case characters exist add 25 to the running total
        if test_for_upper_and_lower(user_password) then
            password_score := password_score + 25;  -- fix the bug here
        else
            my_issue_count := my_issue_count + 1;
            my_issues(my_issue_count) := 'Missing both lower and upper case chars';
        end if;

        -- if both characters and digits exist add 25 to running total
        if test_for_char_and_digit(user_password) then
            password_score := password_score + 25;
        else
            my_issue_count := my_issue_count + 1;
            my_issues(my_issue_count) := 'Missing both char and digit combination.';
        end if;   

        -- if we have at least one embedded symbol add 25
        if test_for_symbol(user_password) then
            password_score := password_score + 25;
        else
            my_issue_count := my_issue_count + 1;
            my_issues(my_issue_count) := 'Missing at least one symbol.';
        end if;   

        -- if we have included either < or > set issue 
        if test_for_gt_or_lt(user_password) then
            password_score := 0;
            my_issue_count := my_issue_count + 1;
            my_issues(my_issue_count) := 'Illegal use of < or > symbol.';
        end if;

        if password_score < 0 then -- don't think can happen but we will play it safe
            password_score := 0;
        elsif password_score > 100 then
            password_score := 100;  -- this can definitely happend
        end if;

        -- if the user needs access to the issues they can call the overloaded version
        return password_score;

    end calc_password_strength;

    -- now the overloaded version
    function calc_password_strength
        (user_password          in      varchar default 'nogood',
         my_issues_out          out     my_issues_table,
         my_issue_count_out     out     integer)
        return          integer     -- 0 through 100 inclusive wwith 100 max strength
        as

        type my_array is table of char(1) index by binary_integer;
        my_symbols      my_array;
        my_uletters     my_array;
        my_lletters     my_array;
        my_digits       my_array;

        my_symbol_count     integer := 0;
        my_uletter_count    integer := 0;
        my_lletter_count    integer := 0;
        my_digits_count     integer := 0;

        -- in our overloaded version of this function we will return this structure as an out parm
        -- type my_issues_table is table of varchar(200) index by binary_integer; no longer needed
        my_issues           my_issues_table;
        my_issue_count      integer := 0;

        password_score      integer := 0;

        function test_for_gt_or_lt
            (user_password in   varchar)
            return boolean
            is
            found_one   boolean := false;
        begin
            for lcv in 1.. length(user_password) loop
                if substr(user_password, lcv, 1) = chr(60) or  -- ASCII <
                   substr(user_password, lcv, 1) = chr(62) then  -- ASCII >
                    found_one := true;
                end if;
            end loop;
            return found_one;
        end test_for_gt_or_lt;

        function test_for_symbol
            (user_password in   varchar)
            return boolean
            is
            symbol_found    boolean := false;
        begin
            for lcv1 in 1 .. my_symbol_count loop
                for lcv2 in 1 .. length(user_password) loop
                    if substr(user_password, lcv2, 1) = my_symbols(lcv1) then
                        symbol_found := true;
                    end if;
                end loop;
            end loop;
            return symbol_found;
        end test_for_symbol;

        function test_for_char_and_digit
            (user_password in   varchar)
            return boolean
            is
            char_found      boolean := false;
            digit_found     boolean := false;
        begin
            for lcv1 in 1 .. my_uletter_count loop
                for lcv2 in 1 .. length(user_password) loop
                    if (substr(user_password, lcv2, 1) = my_uletters(lcv1)) or
                        (substr(user_password, lcv2, 1) = my_lletters(lcv1)) then
                        char_found := true;
                    end if;
                end loop;
            end loop;

            for lcv1 in 1 .. my_digits_count loop
                for lcv2 in 1 .. length(user_password) loop
                    if substr(user_password, lcv2, 1) = my_digits(lcv1) then
                        digit_found := true;
                    end if;
                end loop;
            end loop;

            if digit_found and char_found then
                return true;
            else
                return false;
            end if;
        end test_for_char_and_digit;

        function test_for_upper_and_lower
            (user_password  in  varchar)
            return boolean
            is
            upper_found     boolean := false;
            lower_found     boolean := false;
        begin
            for lcv1 in 1 .. my_uletter_count loop  -- for each upper case letter
                for lcv2 in 1 .. length(user_password) loop -- for each letter in the password
                    if (substr(user_password, lcv2, 1) = my_uletters(lcv1)) then
                        -- if this upper case letter matches this character in the password
                        upper_found := true;    -- flag the ccondition as having been met
                    end if;
                end loop;
            end loop;

            for lcv1 in 1 .. my_lletter_count loop  -- for each lower case letter
                for lcv2 in 1 .. length(user_password) loop -- for each letter in the password
                    if (substr(user_password, lcv2, 1) = my_lletters(lcv1)) then
                        -- if this lower case letter matches this character in the password
                        lower_found := true;    -- flag the ccondition as having been met
                    end if;
                end loop;
            end loop;

            if upper_found and lower_found then
                return true;
            else
                return false;
            end if;
        end test_for_upper_and_lower;

       procedure check_length 
            (user_password  in  varchar)
        is
            -- this routine checks whether passsword length is accceptable; i.e. GE 8
            -- if not score zero and post an issue to the my_issues table
            -- if acceptable then score 15 plus one for each additional character length
            password_length integer;
        begin
            -- determine the length of the potential password
            select length(user_password) into password_length from dual;
            -- score that length
            if password_length < 8 then
                -- password is too short
                my_issue_count := my_issue_count + 1;
                my_issues(my_issue_count) := 'Password is too short.';
            else
                password_score := password_score + 15 + length(user_password) - 8;
            end if;
        end;

        procedure populate_arrays is
        begin
            -- keyboard symbols are ASCII 33 through 47 and 91 through 95 and 123 through 126
            for lcv in 33 .. 47 loop
                my_symbol_count := my_symbol_count + 1;
                my_symbols(my_symbol_count) := chr(lcv); 
            end loop;
            for lcv in 91 .. 95 loop
                my_symbol_count := my_symbol_count + 1;
                my_symbols(my_symbol_count) := chr(lcv); 
            end loop;
            for lcv in 123 .. 126 loop
                my_symbol_count := my_symbol_count + 1;
                my_symbols(my_symbol_count) := chr(lcv); 
            end loop;
            -- upper case letters are ASCII 65 through 90
            for lcv in 65 .. 90 loop
                my_uletter_count := lcv - 64;
                my_uletters(my_uletter_count) := chr(lcv);
            end loop;
            -- lower case letters are ASCII 97 through 122
            for lcv in 97 .. 122 loop
                my_lletter_count := my_lletter_count + 1;
                my_lletters(my_lletter_count) := chr(lcv);
            end loop;
            -- digits are ASCII values 48 through 57
            for lcv in 48 .. 57 loop
                my_digits_count := my_digits_count + 1;
                my_digits(my_digits_count) := chr(lcv);
            end loop;
        end populate_arrays;

    begin
        populate_arrays;

        -- length check is worth 25 + 1 for each char beyond 8
        check_length(user_password);

        -- if both upper and lower case characters exist add 25 to the running total
        if test_for_upper_and_lower(user_password) then
            password_score := password_score + 25;  -- fix the bug here
        else
            my_issue_count := my_issue_count + 1;
            my_issues(my_issue_count) := 'Missing both lower and upper case chars';
        end if;

        -- if both characters and digits exist add 25 to running total
        if test_for_char_and_digit(user_password) then
            password_score := password_score + 25;
        else
            my_issue_count := my_issue_count + 1;
            my_issues(my_issue_count) := 'Missing both char and digit combination.';
        end if;   

        -- if we have at least one embedded symbol add 25
        if test_for_symbol(user_password) then
            password_score := password_score + 25;
        else
            my_issue_count := my_issue_count + 1;
            my_issues(my_issue_count) := 'Missing at least one symbol.';
        end if;   

        -- if we have included either < or > set issue 
        if test_for_gt_or_lt(user_password) then
            password_score := 0;
            my_issue_count := my_issue_count + 1;
            my_issues(my_issue_count) := 'Illegal use of < or > symbol.';
        end if;

        if password_score < 0 then -- don't think can happen but we will play it safe
            password_score := 0;
        elsif password_score > 100 then
            password_score := 100;  -- this can definitely happend
        end if;


        my_issues_out := my_issues;
        my_issue_count_out := my_issue_count;

        -- if the user needs access to the issues they can call the overloaded version
        return password_score;

    end calc_password_strength;

    procedure create_new_student
        (first_name         in      varchar,
         last_name          in      varchar,
         email              in      varchar,
         telephone          in      varchar,
         user_password      in      varchar,
         manager_id         in      integer,
         customer_id        in      integer,
         person_id          out     integer,
         my_issues_out      out     my_issues_table,
         my_issue_out_count out     integer) is

         my_issues                  my_issues_table;
         my_issue_count             integer := 0;
         my_row_count               integer;
         my_password_strength       integer;

         begin

            -- first and last names are required fields
            if length(create_new_student.first_name) = 0 then
                my_issue_count := my_issue_count + 1;
                my_issues(my_issue_count) := 'First name is null';
            end if;
            if length(create_new_student.last_name) = 0 then
                my_issue_count := my_issue_count + 1;
                my_issues(my_issue_count) := 'Last name is null';
            end if;

            -- if present, then manager_id and customer_id must be valid
            if create_new_student.manager_id is not null then
                select  count(*) into my_row_count
                from    persons
                where   person_id = create_new_student.manager_id;

                if my_row_count = 0 then
                    my_issue_count := my_issue_count + 1;
                    my_issues(my_issue_count) := 'Manager_ID is invalid.';
                end if;
            end if;                

            if create_new_student.customer_id is not null then
                select  count(*) into my_row_count
                from    customers
                where   customer_id = create_new_student.customer_id;

                if my_row_count = 0 then
                    my_issue_count := my_issue_count + 1;
                    my_issues(my_issue_count) := 'Customer_ID is invalid.';
                end if;
            end if;      

            -- how strong is this password
            select calc_password_strength(create_new_student.user_password) into my_password_strength from dual;

            -- if all minimum criterion are met calc_password_strength should return a value of 90
            if my_password_strength < 90 then
                my_password_strength := calc_password_strength (
                                            user_password       =>      create_new_student.user_password,
                                            my_issues_out       =>      my_issues,
                                            my_issue_count_out  =>      my_issue_count);
            end if;

            -- if my_issue_count is zero then we can insert else return issues
            if my_issue_count = 0 then

                insert into persons
                    (person_id, first_name, last_name, email, telephone, 
                     password, password_update, manager_id, customer_id)
                select
                    nvl(max(person_id)+1,1), create_new_student.first_name, create_new_student.last_name,
                    create_new_student.email, create_new_student.telephone, create_new_student.user_password, sysdate,
                    create_new_student.manager_id, create_new_student.customer_id
                from
                    persons;

                select max(person_id) into create_new_student.person_id from persons;

            else

                create_new_student.my_issues_out := my_issues;
                create_new_student.my_issue_out_count := my_issue_count;

            end if;

        end create_new_student;

    procedure enroll_student
        (person_id          in      integer,
         course_id          in      integer,
         my_issues_out      out     my_issues_table,
         my_issue_out_count out     integer) is

        my_issues           my_issues_table;
        my_issue_count      integer := 0;
        record_count        integer;

    begin

        -- does this person_id exist
        select  count(*) into record_count
        from    persons
        where   person_id = enroll_student.person_id;

        if record_count = 0 then
            my_issue_count := my_issue_count + 1;
            my_issues(my_issue_count) := 'Person_ID does not exist.';
        end if;

        -- does this course_id exist
        select  count(*) into record_count
        from    courses
        where   course_id = enroll_student.course_id;

        if record_count = 0 then
            my_issue_count := my_issue_count + 1;
            my_issues(my_issue_count) := 'Course_ID does not exist.';
        end if;

        -- do textbooks exist for this course
        select  count(*) into record_count
        from    courses a, textbooks b
        where   a.textbook_id = b.textbook_id
        and     a.course_id = enroll_student.course_id;

        if record_count = 0 then
            my_issue_count := my_issue_count + 1;
            my_issues(my_issue_count) := 'No textbooks exist for this course.';
        end if;

        if my_issue_count = 0 then

            insert into person_course_roles
                (person_id, course_id, role, action_type, action_type_date)
            values
                (enroll_student.person_id, enroll_student.course_id, 'Student','Enroll',sysdate);

        end if;

    end enroll_student;

    procedure drop_student
        (person_id          in      integer,
         my_issues_out      out     my_issues_table,
         my_issue_out_count out     integer) is

        my_issues           my_issues_table;
        my_issue_count      integer;
        record_count        integer;

    begin

        select  count(*) into record_count
        from    persons
        where   person_id = drop_student.person_id;

        if record_count = 0 then
            my_issue_count := my_issue_count + 1;
            my_issues(my_issue_count) := 'Person_ID does not exist.';
        end if;

        if my_issue_count > 0 then

            -- these updated records will go to audit table
            update  person_course_roles
            set     action_type = 'Drop Course',
                    action_type_date = sysdate
            where   person_id = drop_student.person_id;

            delete  from person_course_roles
            where   person_id = drop_student.person_id;

            update  persons
            set     status = 'Inactive'
            where   person_id = drop_student.person_id;
        else

            my_issues_out := my_issues;
            my_issue_out_count := my_issue_count;

        end if;

    end drop_student;

    procedure change_password
            (person_id          in          integer,
            new_password        in          varchar default 'nogood',
            my_issues_out       out         my_issues_table,
            my_issue_out_count  out         integer) is

            my_issues           my_issues_table;
            my_issue_count      integer := 0;
            password_strength   integer;
            record_count        integer;
    begin

            -- does this person exist
            select  count(*) into record_count
            from    persons
            where   person_id = change_password.new_password
            and     status = 'Active';

            if record_count = 0 then
                my_issue_count := my_issue_count + 1;
                my_issues(my_issue_count) := 'Persons record does not exist.';
            end if;

            password_strength := calc_password_strength (change_password.new_password);

            if password_strength < 90  or record_count = 0 then

                password_strength := calc_password_strength (
                    user_password       =>      change_password.new_password,
                    my_issues_out       =>      my_issues,
                    my_issue_count_out  =>      my_issue_count);

                 -- output the issues   
                my_issues_out := my_issues;
                my_issue_out_count := my_issue_count;

            else

                -- go ahead and make the password change
                update  persons
                set     password = change_password.new_password,
                        password_update = sysdate
                where   person_id = change_password.person_id;

            end if;                    
    end change_password;

end new_student;

-- make the next change to create_new_student
create or replace NONEDITIONABLE package body new_student as

    -- this is our function from chapter 16
    function calc_password_strength
        (user_password  in      varchar default 'nogood')
        return          integer     -- 0 through 100 inclusive wwith 100 max strength
        as
    
        type my_array is table of char(1) index by binary_integer;
        my_symbols      my_array;
        my_uletters     my_array;
        my_lletters     my_array;
        my_digits       my_array;

        my_symbol_count     integer := 0;
        my_uletter_count    integer := 0;
        my_lletter_count    integer := 0;
        my_digits_count     integer := 0;

        -- in our overloaded version of this function we will return this structure as an out parm
        -- type my_issues_table is table of varchar(200) index by binary_integer;
        my_issues           my_issues_table;
        my_issue_count      integer := 0;

        password_score      integer := 0;

        function test_for_gt_or_lt
            (user_password in   varchar)
            return boolean
            is
            found_one   boolean := false;
        begin
            for lcv in 1.. length(user_password) loop
                if substr(user_password, lcv, 1) = chr(60) or  -- ASCII <
                   substr(user_password, lcv, 1) = chr(62) then  -- ASCII >
                    found_one := true;
                end if;
            end loop;
            return found_one;
        end test_for_gt_or_lt;

        function test_for_symbol
            (user_password in   varchar)
            return boolean
            is
            symbol_found    boolean := false;
        begin
            for lcv1 in 1 .. my_symbol_count loop
                for lcv2 in 1 .. length(user_password) loop
                    if substr(user_password, lcv2, 1) = my_symbols(lcv1) then
                        symbol_found := true;
                    end if;
                end loop;
            end loop;
            return symbol_found;
        end test_for_symbol;

        function test_for_char_and_digit
            (user_password in   varchar)
            return boolean
            is
            char_found      boolean := false;
            digit_found     boolean := false;
        begin
            for lcv1 in 1 .. my_uletter_count loop
                for lcv2 in 1 .. length(user_password) loop
                    if (substr(user_password, lcv2, 1) = my_uletters(lcv1)) or
                        (substr(user_password, lcv2, 1) = my_lletters(lcv1)) then
                        char_found := true;
                    end if;
                end loop;
            end loop;

            for lcv1 in 1 .. my_digits_count loop
                for lcv2 in 1 .. length(user_password) loop
                    if substr(user_password, lcv2, 1) = my_digits(lcv1) then
                        digit_found := true;
                    end if;
                end loop;
            end loop;

            if digit_found and char_found then
                return true;
            else
                return false;
            end if;
        end test_for_char_and_digit;

        function test_for_upper_and_lower
            (user_password  in  varchar)
            return boolean
            is
            upper_found     boolean := false;
            lower_found     boolean := false;
        begin
            for lcv1 in 1 .. my_uletter_count loop  -- for each upper case letter
                for lcv2 in 1 .. length(user_password) loop -- for each letter in the password
                    if (substr(user_password, lcv2, 1) = my_uletters(lcv1)) then
                        -- if this upper case letter matches this character in the password
                        upper_found := true;    -- flag the ccondition as having been met
                    end if;
                end loop;
            end loop;

            for lcv1 in 1 .. my_lletter_count loop  -- for each lower case letter
                for lcv2 in 1 .. length(user_password) loop -- for each letter in the password
                    if (substr(user_password, lcv2, 1) = my_lletters(lcv1)) then
                        -- if this lower case letter matches this character in the password
                        lower_found := true;    -- flag the ccondition as having been met
                    end if;
                end loop;
            end loop;

            if upper_found and lower_found then
                return true;
            else
                return false;
            end if;
        end test_for_upper_and_lower;

       procedure check_length 
            (user_password  in  varchar)
        is
            -- this routine checks whether passsword length is accceptable; i.e. GE 8
            -- if not score zero and post an issue to the my_issues table
            -- if acceptable then score 15 plus one for each additional character length
            password_length integer;
        begin
            -- determine the length of the potential password
            select length(user_password) into password_length from dual;
            -- score that length
            if password_length < 8 then
                -- password is too short
                my_issue_count := my_issue_count + 1;
                my_issues(my_issue_count) := 'Password is too short.';
            else
                password_score := password_score + 15 + length(user_password) - 8;
            end if;
        end;

        procedure populate_arrays is
        begin
            -- keyboard symbols are ASCII 33 through 47 and 91 through 95 and 123 through 126
            for lcv in 33 .. 47 loop
                my_symbol_count := my_symbol_count + 1;
                my_symbols(my_symbol_count) := chr(lcv); 
            end loop;
            for lcv in 91 .. 95 loop
                my_symbol_count := my_symbol_count + 1;
                my_symbols(my_symbol_count) := chr(lcv); 
            end loop;
            for lcv in 123 .. 126 loop
                my_symbol_count := my_symbol_count + 1;
                my_symbols(my_symbol_count) := chr(lcv); 
            end loop;
            -- upper case letters are ASCII 65 through 90
            for lcv in 65 .. 90 loop
                my_uletter_count := lcv - 64;
                my_uletters(my_uletter_count) := chr(lcv);
            end loop;
            -- lower case letters are ASCII 97 through 122
            for lcv in 97 .. 122 loop
                my_lletter_count := my_lletter_count + 1;
                my_lletters(my_lletter_count) := chr(lcv);
            end loop;
            -- digits are ASCII values 48 through 57
            for lcv in 48 .. 57 loop
                my_digits_count := my_digits_count + 1;
                my_digits(my_digits_count) := chr(lcv);
            end loop;
        end populate_arrays;

    begin
        populate_arrays;

        -- length check is worth 25 + 1 for each char beyond 8
        check_length(user_password);

        -- if both upper and lower case characters exist add 25 to the running total
        if test_for_upper_and_lower(user_password) then
            password_score := password_score + 25;  -- fix the bug here
        else
            my_issue_count := my_issue_count + 1;
            my_issues(my_issue_count) := 'Missing both lower and upper case chars';
        end if;

        -- if both characters and digits exist add 25 to running total
        if test_for_char_and_digit(user_password) then
            password_score := password_score + 25;
        else
            my_issue_count := my_issue_count + 1;
            my_issues(my_issue_count) := 'Missing both char and digit combination.';
        end if;   

        -- if we have at least one embedded symbol add 25
        if test_for_symbol(user_password) then
            password_score := password_score + 25;
        else
            my_issue_count := my_issue_count + 1;
            my_issues(my_issue_count) := 'Missing at least one symbol.';
        end if;   

        -- if we have included either < or > set issue 
        if test_for_gt_or_lt(user_password) then
            password_score := 0;
            my_issue_count := my_issue_count + 1;
            my_issues(my_issue_count) := 'Illegal use of < or > symbol.';
        end if;

        if password_score < 0 then -- don't think can happen but we will play it safe
            password_score := 0;
        elsif password_score > 100 then
            password_score := 100;  -- this can definitely happend
        end if;

        -- if the user needs access to the issues they can call the overloaded version
        return password_score;

    end calc_password_strength;

    -- now the overloaded version
    function calc_password_strength
        (user_password          in      varchar default 'nogood',
         my_issues_out          out     my_issues_table,
         my_issue_count_out     out     integer)
        return          integer     -- 0 through 100 inclusive wwith 100 max strength
        as

        type my_array is table of char(1) index by binary_integer;
        my_symbols      my_array;
        my_uletters     my_array;
        my_lletters     my_array;
        my_digits       my_array;

        my_symbol_count     integer := 0;
        my_uletter_count    integer := 0;
        my_lletter_count    integer := 0;
        my_digits_count     integer := 0;

        -- in our overloaded version of this function we will return this structure as an out parm
        -- type my_issues_table is table of varchar(200) index by binary_integer; no longer needed
        my_issues           my_issues_table;
        my_issue_count      integer := 0;

        password_score      integer := 0;

        function test_for_gt_or_lt
            (user_password in   varchar)
            return boolean
            is
            found_one   boolean := false;
        begin
            for lcv in 1.. length(user_password) loop
                if substr(user_password, lcv, 1) = chr(60) or  -- ASCII <
                   substr(user_password, lcv, 1) = chr(62) then  -- ASCII >
                    found_one := true;
                end if;
            end loop;
            return found_one;
        end test_for_gt_or_lt;

        function test_for_symbol
            (user_password in   varchar)
            return boolean
            is
            symbol_found    boolean := false;
        begin
            for lcv1 in 1 .. my_symbol_count loop
                for lcv2 in 1 .. length(user_password) loop
                    if substr(user_password, lcv2, 1) = my_symbols(lcv1) then
                        symbol_found := true;
                    end if;
                end loop;
            end loop;
            return symbol_found;
        end test_for_symbol;

        function test_for_char_and_digit
            (user_password in   varchar)
            return boolean
            is
            char_found      boolean := false;
            digit_found     boolean := false;
        begin
            for lcv1 in 1 .. my_uletter_count loop
                for lcv2 in 1 .. length(user_password) loop
                    if (substr(user_password, lcv2, 1) = my_uletters(lcv1)) or
                        (substr(user_password, lcv2, 1) = my_lletters(lcv1)) then
                        char_found := true;
                    end if;
                end loop;
            end loop;

            for lcv1 in 1 .. my_digits_count loop
                for lcv2 in 1 .. length(user_password) loop
                    if substr(user_password, lcv2, 1) = my_digits(lcv1) then
                        digit_found := true;
                    end if;
                end loop;
            end loop;

            if digit_found and char_found then
                return true;
            else
                return false;
            end if;
        end test_for_char_and_digit;

        function test_for_upper_and_lower
            (user_password  in  varchar)
            return boolean
            is
            upper_found     boolean := false;
            lower_found     boolean := false;
        begin
            for lcv1 in 1 .. my_uletter_count loop  -- for each upper case letter
                for lcv2 in 1 .. length(user_password) loop -- for each letter in the password
                    if (substr(user_password, lcv2, 1) = my_uletters(lcv1)) then
                        -- if this upper case letter matches this character in the password
                        upper_found := true;    -- flag the ccondition as having been met
                    end if;
                end loop;
            end loop;

            for lcv1 in 1 .. my_lletter_count loop  -- for each lower case letter
                for lcv2 in 1 .. length(user_password) loop -- for each letter in the password
                    if (substr(user_password, lcv2, 1) = my_lletters(lcv1)) then
                        -- if this lower case letter matches this character in the password
                        lower_found := true;    -- flag the ccondition as having been met
                    end if;
                end loop;
            end loop;

            if upper_found and lower_found then
                return true;
            else
                return false;
            end if;
        end test_for_upper_and_lower;

       procedure check_length 
            (user_password  in  varchar)
        is
            -- this routine checks whether passsword length is accceptable; i.e. GE 8
            -- if not score zero and post an issue to the my_issues table
            -- if acceptable then score 15 plus one for each additional character length
            password_length integer;
        begin
            -- determine the length of the potential password
            select length(user_password) into password_length from dual;
            -- score that length
            if password_length < 8 then
                -- password is too short
                my_issue_count := my_issue_count + 1;
                my_issues(my_issue_count) := 'Password is too short.';
            else
                password_score := password_score + 15 + length(user_password) - 8;
            end if;
        end;

        procedure populate_arrays is
        begin
            -- keyboard symbols are ASCII 33 through 47 and 91 through 95 and 123 through 126
            for lcv in 33 .. 47 loop
                my_symbol_count := my_symbol_count + 1;
                my_symbols(my_symbol_count) := chr(lcv); 
            end loop;
            for lcv in 91 .. 95 loop
                my_symbol_count := my_symbol_count + 1;
                my_symbols(my_symbol_count) := chr(lcv); 
            end loop;
            for lcv in 123 .. 126 loop
                my_symbol_count := my_symbol_count + 1;
                my_symbols(my_symbol_count) := chr(lcv); 
            end loop;
            -- upper case letters are ASCII 65 through 90
            for lcv in 65 .. 90 loop
                my_uletter_count := lcv - 64;
                my_uletters(my_uletter_count) := chr(lcv);
            end loop;
            -- lower case letters are ASCII 97 through 122
            for lcv in 97 .. 122 loop
                my_lletter_count := my_lletter_count + 1;
                my_lletters(my_lletter_count) := chr(lcv);
            end loop;
            -- digits are ASCII values 48 through 57
            for lcv in 48 .. 57 loop
                my_digits_count := my_digits_count + 1;
                my_digits(my_digits_count) := chr(lcv);
            end loop;
        end populate_arrays;

    begin
        populate_arrays;

        -- length check is worth 25 + 1 for each char beyond 8
        check_length(user_password);

        -- if both upper and lower case characters exist add 25 to the running total
        if test_for_upper_and_lower(user_password) then
            password_score := password_score + 25;  -- fix the bug here
        else
            my_issue_count := my_issue_count + 1;
            my_issues(my_issue_count) := 'Missing both lower and upper case chars';
        end if;

        -- if both characters and digits exist add 25 to running total
        if test_for_char_and_digit(user_password) then
            password_score := password_score + 25;
        else
            my_issue_count := my_issue_count + 1;
            my_issues(my_issue_count) := 'Missing both char and digit combination.';
        end if;   

        -- if we have at least one embedded symbol add 25
        if test_for_symbol(user_password) then
            password_score := password_score + 25;
        else
            my_issue_count := my_issue_count + 1;
            my_issues(my_issue_count) := 'Missing at least one symbol.';
        end if;   

        -- if we have included either < or > set issue 
        if test_for_gt_or_lt(user_password) then
            password_score := 0;
            my_issue_count := my_issue_count + 1;
            my_issues(my_issue_count) := 'Illegal use of < or > symbol.';
        end if;

        if password_score < 0 then -- don't think can happen but we will play it safe
            password_score := 0;
        elsif password_score > 100 then
            password_score := 100;  -- this can definitely happend
        end if;


        my_issues_out := my_issues;
        my_issue_count_out := my_issue_count;

        -- if the user needs access to the issues they can call the overloaded version
        return password_score;

    end calc_password_strength;

    procedure create_new_student
        (first_name         in      varchar,
         last_name          in      varchar,
         email              in      varchar,
         telephone          in      varchar,
         user_password      in      varchar,
         manager_id         in      integer,
         customer_id        in      integer,
         person_id          out     integer,
         my_issues_out      out     my_issues_table,
         my_issue_out_count out     integer) is

         my_issues                  my_issues_table;
         my_issue_count             integer := 0;
         my_issues2                 my_issues_table;
         my_issue_count2            integer := 0;
         my_row_count               integer;
         my_password_strength       integer;

         begin

            -- first and last names are required fields
            if length(create_new_student.first_name) = 0 then
                my_issue_count := my_issue_count + 1;
                my_issues(my_issue_count) := 'First name is null';
            end if;
            if length(create_new_student.last_name) = 0 then
                my_issue_count := my_issue_count + 1;
                my_issues(my_issue_count) := 'Last name is null';
            end if;

            -- if present, then manager_id and customer_id must be valid
            if create_new_student.manager_id is not null then
                select  count(*) into my_row_count
                from    persons
                where   person_id = create_new_student.manager_id;

                if my_row_count = 0 then
                    my_issue_count := my_issue_count + 1;
                    my_issues(my_issue_count) := 'Manager_ID is invalid.';
                end if;
            end if;                

            if create_new_student.customer_id is not null then
                select  count(*) into my_row_count
                from    customers
                where   customer_id = create_new_student.customer_id;

                if my_row_count = 0 then
                    my_issue_count := my_issue_count + 1;
                    my_issues(my_issue_count) := 'Customer_ID is invalid.';
                end if;
            end if;      

            -- how strong is this password
            select calc_password_strength(create_new_student.user_password) into my_password_strength from dual;

            -- if all minimum criterion are met calc_password_strength should return a value of 90
            if my_password_strength < 90 then
                my_password_strength := calc_password_strength (
                                            user_password       =>      create_new_student.user_password,
                                            my_issues_out       =>      my_issues2,
                                            my_issue_count_out  =>      my_issue_count2);
                for lcv in 1 .. my_issue_count2 loop
                    my_issue_count := my_issue_count + 1;
                    my_issues(my_issue_count) := my_issues2(lcv);
                end loop;

            end if;

            -- if my_issue_count is zero then we can insert else return issues
            if my_issue_count = 0 then

                insert into persons
                    (person_id, first_name, last_name, email, telephone, 
                     password, password_update, manager_id, customer_id)
                select
                    nvl(max(person_id)+1,1), create_new_student.first_name, create_new_student.last_name,
                    create_new_student.email, create_new_student.telephone, create_new_student.user_password, sysdate,
                    create_new_student.manager_id, create_new_student.customer_id
                from
                    persons;

                select max(person_id) into create_new_student.person_id from persons;

            else

                create_new_student.my_issues_out := my_issues;
                create_new_student.my_issue_out_count := my_issue_count;

            end if;

        end create_new_student;

    procedure enroll_student
        (person_id          in      integer,
         course_id          in      integer,
         my_issues_out      out     my_issues_table,
         my_issue_out_count out     integer) is

        my_issues           my_issues_table;
        my_issue_count      integer := 0;
        record_count        integer;

    begin

        -- does this person_id exist
        select  count(*) into record_count
        from    persons
        where   person_id = enroll_student.person_id;

        if record_count = 0 then
            my_issue_count := my_issue_count + 1;
            my_issues(my_issue_count) := 'Person_ID does not exist.';
        end if;

        -- does this course_id exist
        select  count(*) into record_count
        from    courses
        where   course_id = enroll_student.course_id;

        if record_count = 0 then
            my_issue_count := my_issue_count + 1;
            my_issues(my_issue_count) := 'Course_ID does not exist.';
        end if;

        -- do textbooks exist for this course
        select  count(*) into record_count
        from    courses a, textbooks b
        where   a.textbook_id = b.textbook_id
        and     a.course_id = enroll_student.course_id;

        if record_count = 0 then
            my_issue_count := my_issue_count + 1;
            my_issues(my_issue_count) := 'No textbooks exist for this course.';
        end if;

        if my_issue_count = 0 then

            insert into person_course_roles
                (person_id, course_id, role, action_type, action_type_date)
            values
                (enroll_student.person_id, enroll_student.course_id, 'Student','Enroll',sysdate);

        end if;

    end enroll_student;

    procedure drop_student
        (person_id          in      integer,
         my_issues_out      out     my_issues_table,
         my_issue_out_count out     integer) is

        my_issues           my_issues_table;
        my_issue_count      integer := 0;
        record_count        integer;

    begin

        select  count(*) into record_count
        from    persons
        where   person_id = drop_student.person_id;

        if record_count = 0 then
            my_issue_count := my_issue_count + 1;
            my_issues(my_issue_count) := 'Person_ID does not exist.';
        end if;

        if my_issue_count > 0 then

            -- these updated records will go to audit table
            update  person_course_roles
            set     action_type = 'Drop Course',
                    action_type_date = sysdate
            where   person_id = drop_student.person_id;

            delete  from person_course_roles
            where   person_id = drop_student.person_id;

            update  persons
            set     status = 'Inactive'
            where   person_id = drop_student.person_id;
        else

            my_issues_out := my_issues;
            my_issue_out_count := my_issue_count;

        end if;

    end drop_student;

    procedure change_password
            (person_id          in          integer,
            new_password        in          varchar default 'nogood',
            my_issues_out       out         my_issues_table,
            my_issue_out_count  out         integer) is

            my_issues           my_issues_table;
            my_issue_count      integer := 0;
            password_strength   integer;
            record_count        integer;
    begin

            -- does this person exist
            select  count(*) into record_count
            from    persons
            where   person_id = change_password.person_id
            and     status = 'Active';

            if record_count = 0 then
                my_issue_count := my_issue_count + 1;
                my_issues(my_issue_count) := 'Persons record does not exist.';
            end if;

            password_strength := calc_password_strength (change_password.new_password);

            if password_strength < 90  or record_count = 0 then

                password_strength := calc_password_strength (
                    user_password       =>      change_password.new_password,
                    my_issues_out       =>      my_issues,
                    my_issue_count_out  =>      my_issue_count);

                 -- output the issues   
                my_issues_out := my_issues;
                my_issue_out_count := my_issue_count;

            else

                -- go ahead and make the password change
                update  persons
                set     password = change_password.new_password,
                        password_update = sysdate
                where   person_id = change_password.person_id;

            end if;                    
    end change_password;

end new_student;

-- ready to test drop student routine
create or replace procedure test_new_student_package_v4 as

    my_password     varchar(30);
    my_issues       new_student.my_issues_table;
    my_issue_count  integer;

begin

    select  password into my_password
    from    persons
    where   person_id = 3;

    dbms_output.put_line ('Original password = ' || my_password);

    -- start by testing a valid password
    my_password := 'This1$Valid';

    new_student.change_password (
        person_id           =>      3,
        new_password        =>      my_password,
        my_issues_out       =>      my_issues,
        my_issue_out_count  =>      my_issue_count);

    select  password into my_password
    from    persons
    where   person_id = 3;

    dbms_output.put_line ('New password = ' || my_password);

    my_password := 'nogood';
    new_student.change_password(
        person_id           =>      3,
        new_password        =>      my_password,
        my_issues_out       =>      my_issues,
        my_issue_out_count  =>      my_issue_count);
    
    for lcv in 1..my_issue_count loop
        dbms_output.put_line ('issue # ' || lcv || ' was ' || my_issues(lcv));
    end loop;
end;
create or replace procedure test_new_student_package_v3 as

    my_issues       new_student.my_issues_table;
    my_issue_count  integer := 0;
    my_person_id    integer;

    cursor          get_persons is
    select          first_name, last_name, person_id, status
    from            persons
    order by        last_name, first_name;
    this_person     get_persons%rowtype;

    cursor          get_person_course_roles is
    select          *
    from            person_course_roles
    where           role = 'Student'
    order by        person_id, course_id;
    this_person_course_role     get_person_course_roles%rowtype;

    cursor          get_person_course_roles_audit is
    select          *
    from            person_course_roles_audit
    where           role = 'Student'
    order by        person_id, course_id;
    this_person_course_roles_audit get_person_course_roles_audit%rowtype;

begin

    dbms_output.put_line ('DB tables of interest prior to dropping person_id = 1');

    open get_persons;
    fetch get_persons into this_person;
    while get_persons%FOUND loop
        dbms_output.put_line ('person id ' || this_person.person_id || ' is named ' || this_person.first_name || ' ' || this_person.last_name || ' with a status of ' || this_person.status);
        fetch get_persons into this_person;
    end loop;
    close get_persons;

    open get_person_course_roles;
    fetch get_person_course_roles into this_person_course_role;
    while get_person_course_roles%FOUND loop
        dbms_output.put_line ('Person ID = ' || this_person_course_role.person_id || ' Course ID = ' || this_person_course_role.course_id || ' action_type = ' || this_person_course_role.action_type);
    end loop;
    close get_person_course_roles;

    open get_person_course_roles_audit;
    fetch get_person_course_roles_audit into this_person_course_roles_audit;
    while get_person_course_roles_audit%FOUND loop
        dbms_output.put_line ('Person ID = ' || this_person_course_roles_audit.person_id || ' Course ID = ' || this_person_course_roles_audit.course_id || ' action_type = ' || 
            this_person_course_roles_audit.action_type);
    end loop;
    close get_person_course_roles_audit;

    -- this should be a valid person_id
    new_student.drop_student (3, my_issues, my_issue_count);

   dbms_output.put_line (' ' );
   dbms_output.put_line ('DB tables of interest after to dropping person_id = 1');

    open get_persons;
    fetch get_persons into this_person;
    while get_persons%FOUND loop
        dbms_output.put_line ('person id ' || this_person.person_id || ' is named ' || this_person.first_name || ' ' || this_person.last_name || ' with a status of ' || this_person.status);
        fetch get_persons into this_person;
    end loop;
    close get_persons;

    open get_person_course_roles;
    fetch get_person_course_roles into this_person_course_role;
    while get_person_course_roles%FOUND loop
        dbms_output.put_line ('Person ID = ' || this_person_course_role.person_id || ' Course ID = ' || this_person_course_role.course_id || ' action_type = ' || this_person_course_role.action_type);
    end loop;
    close get_person_course_roles;

    open get_person_course_roles_audit;
    fetch get_person_course_roles_audit into this_person_course_roles_audit;
    while get_person_course_roles_audit%FOUND loop
        dbms_output.put_line ('Person ID = ' || this_person_course_roles_audit.person_id || ' Course ID = ' || this_person_course_roles_audit.course_id || ' action_type = ' || 
            this_person_course_roles_audit.action_type);
    end loop;
    close get_person_course_roles_audit;

    -- this should be an invalid person_id
    new_student.drop_student (-1, my_issues, my_issue_count);

   dbms_output.put_line (' ' );
   dbms_output.put_line ('Issues associated with dropping person_id = -1');
    for lcv in 1..my_issue_count loop
        dbms_output.put_line ('issue number ' || lcv || ' reads ' || my_issues(lcv));
    end loop;

end test_new_student_package_v3;
