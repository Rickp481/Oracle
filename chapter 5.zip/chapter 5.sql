/****************************************************************************************/
/*											*/
/*	Rick Phillips									*/
/*	3-12-2021									*/
/*	Chapter 5 DML and Single Table Queries						*/
/*											*/
/****************************************************************************************/


-- as SYSTEM
grant unlimited tablespace to online_training_testing; -- allow our schema unlimited disk space
commit;

-- all the rest as online_training_testing

-- Oracle default date format is DD-MON-YY
insert into customers
    (customer_id, name, short_name, contract_start, contract_end)
values
    (1, 'Badger Mountain Publishing', 'BMP', '12-MAR-21', '31-DEC-21'); 

-- verify that our insert statement worked properly
select * from customers;

-- change to another date literal format
insert into customers
    (customer_id, name, short_name, contract_start, contract_end)
values
    (2, 'Second Customer Name', 'SCN', 
	to_date('03-12-2021', 'MM-DD-YYYY'), 
	to_date('2021-31-12', 'YYYY-DD-MM')); 

select * from customers;

-- dealing with nulls and defaults
insert into customers
    (customer_id, name, short_name)
values
    (3, 'Third Customer Name','TCN');
    
select * from customers;

-- omitting a nonnullable column throws an error
insert into customers
    (customer_id, name)
values
    (3, 'Third Customer Name');
    
-- string literal with embedded apostrophe
insert into customers
    (customer_id, name, short_name, contract_start, contract_end)
values
    (4, 'Forth Customer ''Embedded Apostrophe ','FCN', sysdate, sysdate);

select * from customers;

-- write all these insert commands to hard drive with commit
commit;

-- simple update statement
update	customers
set	contract_start = sysdate,
	contract_end = sysdate + 364;

select * from customers;

-- where clause
update	customers
set	short_name = 'NEW'
where	customer_id > 2
and	short_name = 'TCN';

select * from customers;

-- logic vs syntax errors
update	customers
set	short_name = 'NEW'
where	customer_id >= 2
or	short_name = 'TCN';

select * from customers;

-- the magic of rollback
rollback;

select * from customers;

-- get back to last correct update
update	customers
set	contract_start = sysdate,
	contract_end = sysdate + 364;

update	customers
set	short_name = 'NEW'
where	customer_id > 2
and	short_name = 'TCN';

select * from customers;

-- the delete command
delete from customers
where  customer_id < 1;

select * from customers;

-- the select command
select name, short_name, to_char(contract_start, 'DD-MON-YYYY HH24:MI:SS')
from   customers;

-- column alias
select name, short_name, to_char(contract_start, 'DD-MON-YYYY HH24:MI:SS') as "Contract Start Datetime"
from   customers
where  customer_id > 2;

-- order by clause
select name, short_name, to_char(contract_start, 'DD-MON-YYYY HH24:MI:SS') as "Contract Start Datetime"
from   customers
where  short_name is not null
order by short_name desc;

