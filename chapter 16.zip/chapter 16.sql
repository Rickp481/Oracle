/****************************************************************************************/
/*											*/
/*	Chapter 16 Functions								*/
/*	Rick Phillips									*/
/*	2/24/2022									*/
/*											*/
/****************************************************************************************/


-- Let's create a password strength testing function based on some criterion found
-- on the web.  We begin by setting up some record structures corresponding to the various
-- subsets of keyboard characters; i.e. lower case letters, upper case letters, digits and symbols
  
create or replace function calc_password_strength
    (user_password  in      varchar default 'nogood')
    return          integer     -- 0 through 100 inclusive wwith 100 max strength
    as
    
    type my_array is table of char(1) index by binary_integer;
    my_symbols      my_array;
    my_uletters     my_array;
    my_lletters     my_array;
    my_digits       my_array;
    
    my_symbol_count     integer := 0;
    my_uletter_count    integer := 0;
    my_lletter_count    integer := 0;
    my_digits_count      integer := 0;
    
    procedure populate_arrays is
    begin
       
        -- keyboard symbols are ASCII 33 through 47 and 91 through 95 and 123 through 126
        for lcv in 33 .. 47 loop
            my_symbol_count := my_symbol_count + 1;
            my_symbols(my_symbol_count) := chr(lcv); 
        end loop;
        for lcv in 91 .. 95 loop
            my_symbol_count := my_symbol_count + 1;
            my_symbols(my_symbol_count) := chr(lcv); 
        end loop;
        for lcv in 123 .. 126 loop
            my_symbol_count := my_symbol_count + 1;
            my_symbols(my_symbol_count) := chr(lcv); 
        end loop;
    
        -- upper case letters are ASCII 65 through 90
        for lcv in 65 .. 90 loop
            my_uletter_count := lcv - 64;
            my_uletters(my_uletter_count) := chr(lcv);
        end loop;

        -- lower case letters are ASCII 97 through 122
        for lcv in 97 .. 122 loop
            my_lletter_count := my_lletter_count + 1;
            my_lletters(my_lletter_count) := chr(lcv);
        end loop;

        -- digits are ASCII values 48 through 57
        for lcv in 48 .. 57 loop
            my_digits_count := my_digits_count + 1;
            my_digits(my_digits_count) := chr(lcv);
        end loop;
        
    end populate_arrays;
    
begin
    populate_arrays;
end;

-- in our next version of the code we add in the check_length procedure
create or replace function calc_password_strength
    (user_password  in      varchar default 'nogood')
    return          integer     -- 0 through 100 inclusive wwith 100 max strength
    as
    
    type my_array is table of char(1) index by binary_integer;
    my_symbols      my_array;
    my_uletters     my_array;
    my_lletters     my_array;
    my_digits       my_array;
    
    my_symbol_count     integer := 0;
    my_uletter_count    integer := 0;
    my_lletter_count    integer := 0;
    my_digits_count     integer := 0;

    -- how do we get this information back to the front-end calling routine
    -- functions can have out parms but it is not good practice because then they can not
    -- be used in select statements so I would normally store to a table or XML file
    type my_issues_table is table of varchar(200) index by binary_integer;
    my_issues           my_issues_table;
    my_issue_count      integer := 0;
    
    password_score      integer := 0;
    
    procedure check_length 
        (user_password  in  varchar)
    is
    
        -- this routine checks whether passsword length is accceptable; i.e. GE 8
        -- if not score zero and post an issue to the my_issues table
        -- if acceptable then score 15 plus one for each additional character length
        password_length integer;
        
    begin
        -- determine the length of the potential password
        select length(user_password) into password_length from dual;
        
        -- score that length
        if password_length < 8 then
            -- password is too short
            my_issue_count := my_issue_count + 1;
            my_issues(my_issue_count) := 'Password is too short.';
        else
            password_score := password_score + 15 + length(user_password) - 8;
        end if;
    end;
    
    procedure populate_arrays is
    begin
       
        -- keyboard symbols are ASCII 33 through 47 and 91 through 95 and 123 through 126
        for lcv in 33 .. 47 loop
            my_symbol_count := my_symbol_count + 1;
            my_symbols(my_symbol_count) := chr(lcv); 
        end loop;
        for lcv in 91 .. 95 loop
            my_symbol_count := my_symbol_count + 1;
            my_symbols(my_symbol_count) := chr(lcv); 
        end loop;
        for lcv in 123 .. 126 loop
            my_symbol_count := my_symbol_count + 1;
            my_symbols(my_symbol_count) := chr(lcv); 
        end loop;
    
        -- upper case letters are ASCII 65 through 90
        for lcv in 65 .. 90 loop
            my_uletter_count := lcv - 64;
            my_uletters(my_uletter_count) := chr(lcv);
        end loop;

        -- lower case letters are ASCII 97 through 122
        for lcv in 97 .. 122 loop
            my_lletter_count := my_lletter_count + 1;
            my_lletters(my_lletter_count) := chr(lcv);
        end loop;

        -- digits are ASCII values 48 through 57
        for lcv in 48 .. 57 loop
            my_digits_count := my_digits_count + 1;
            my_digits(my_digits_count) := chr(lcv);
        end loop;
        
    end populate_arrays;
    
begin
    populate_arrays;
    check_length(user_password);
end;

-- in our next version of the code we add in the test for upper and lower case characters
create or replace NONEDITIONABLE function calc_password_strength
    (user_password  in      varchar default 'nogood')
    return          integer     -- 0 through 100 inclusive wwith 100 max strength
    as
    
    type my_array is table of char(1) index by binary_integer;
    my_symbols      my_array;
    my_uletters     my_array;
    my_lletters     my_array;
    my_digits       my_array;

    my_symbol_count     integer := 0;
    my_uletter_count    integer := 0;
    my_lletter_count    integer := 0;
    my_digits_count     integer := 0;

    -- how do we get this information back to the front-end calling routine
    -- functions can have out parms but it is not good practice because then they can not
    -- be used in select statements so I would normally store to a table or XML file
    type my_issues_table is table of varchar(200) index by binary_integer;
    my_issues           my_issues_table;
    my_issue_count      integer := 0;

    password_score      integer := 0;

    function test_for_upper_and_lower
        (user_password  in  varchar)
        return boolean
        is

        upper_found     boolean := false;
        lower_found     boolean := false;

    begin

        for lcv1 in 1 .. my_uletter_count loop  -- for each upper case letter
            for lcv2 in 1 .. length(user_password) loop -- for each letter in the password
                if (substr(user_password, lcv2, 1) = my_uletters(lcv1)) then
                    -- if this upper case letter matches this character in the password
                    upper_found := true;    -- flag the ccondition as having been met
                end if;
            end loop;
        end loop;

        for lcv1 in 1 .. my_lletter_count loop  -- for each lower case letter
            for lcv2 in 1 .. length(user_password) loop -- for each letter in the password
                if (substr(user_password, lcv2, 1) = my_lletters(lcv1)) then
                    -- if this lower case letter matches this character in the password
                    lower_found := true;    -- flag the ccondition as having been met
                end if;
            end loop;
        end loop;

        if upper_found and lower_found then
            return true;
        else
            return false;
        end if;

    end test_for_upper_and_lower;

    procedure check_length 
        (user_password  in  varchar)
    is

        -- this routine checks whether passsword length is accceptable; i.e. GE 8
        -- if not score zero and post an issue to the my_issues table
        -- if acceptable then score 15 plus one for each additional character length
        password_length integer;

    begin
        -- determine the length of the potential password
        select length(user_password) into password_length from dual;

        -- score that length
        if password_length < 8 then
            -- password is too short
            my_issue_count := my_issue_count + 1;
            my_issues(my_issue_count) := 'Password is too short.';
        else
            password_score := password_score + 15 + length(user_password) - 8;
        end if;
    end;

    procedure populate_arrays is
    begin

        -- keyboard symbols are ASCII 33 through 47 and 91 through 95 and 123 through 126
        for lcv in 33 .. 47 loop
            my_symbol_count := my_symbol_count + 1;
            my_symbols(my_symbol_count) := chr(lcv); 
        end loop;
        for lcv in 91 .. 95 loop
            my_symbol_count := my_symbol_count + 1;
            my_symbols(my_symbol_count) := chr(lcv); 
        end loop;
        for lcv in 123 .. 126 loop
            my_symbol_count := my_symbol_count + 1;
            my_symbols(my_symbol_count) := chr(lcv); 
        end loop;

        -- upper case letters are ASCII 65 through 90
        for lcv in 65 .. 90 loop
            my_uletter_count := lcv - 64;
            my_uletters(my_uletter_count) := chr(lcv);
        end loop;

        -- lower case letters are ASCII 97 through 122
        for lcv in 97 .. 122 loop
            my_lletter_count := my_lletter_count + 1;
            my_lletters(my_lletter_count) := chr(lcv);
        end loop;

        -- digits are ASCII values 48 through 57
        for lcv in 48 .. 57 loop
            my_digits_count := my_digits_count + 1;
            my_digits(my_digits_count) := chr(lcv);
        end loop;

    end populate_arrays;

begin
    populate_arrays;
    check_length(user_password);

    -- if both upper and lower case characters exist add 25 to the running total
    if test_for_upper_and_lower(user_password) then
        password_score := password_score + 25;
    else
        my_issue_count := my_issue_count + 1;
        my_issues(my_issue_count) := 'Missing both lower and upper case chars';
    end if;
end;

-- next we add a test for both char and digit
create or replace function calc_password_strength
    (user_password  in      varchar default 'nogood')
    return          integer     -- 0 through 100 inclusive wwith 100 max strength
    as
    
    type my_array is table of char(1) index by binary_integer;
    my_symbols      my_array;
    my_uletters     my_array;
    my_lletters     my_array;
    my_digits       my_array;

    my_symbol_count     integer := 0;
    my_uletter_count    integer := 0;
    my_lletter_count    integer := 0;
    my_digits_count     integer := 0;

    -- how do we get this information back to the front-end calling routine
    -- functions can have out parms but it is not good practice because then they can not
    -- be used in select statements so I would normally store to a table or XML file
    type my_issues_table is table of varchar(200) index by binary_integer;
    my_issues           my_issues_table;
    my_issue_count      integer := 0;

    password_score      integer := 0;

    function test_for_char_and_digit
        (user_password in   varchar)
        return boolean
        is
        
        char_found      boolean := false;
        digit_found     boolean := false;
    begin
    
        for lcv1 in 1 .. my_uletter_count loop
            for lcv2 in 1 .. length(user_password) loop
                if (substr(user_password, lcv2, 1) = my_uletters(lcv1)) or
                    (substr(user_password, lcv2, 1) = my_lletters(lcv1)) then
                    char_found := true;
                end if;
            end loop;
        end loop;

        for lcv1 in 1 .. my_digits_count loop
            for lcv2 in 1 .. length(user_password) loop
                if substr(user_password, lcv2, 1) = my_digits(lcv1) then
                    digit_found := true;
                end if;
            end loop;
        end loop;
        
        if digit_found and char_found then
            return true;
        else
            return false;
        end if;
        
    end test_for_char_and_digit;
    
    function test_for_upper_and_lower
        (user_password  in  varchar)
        return boolean
        is

        upper_found     boolean := false;
        lower_found     boolean := false;

    begin

        for lcv1 in 1 .. my_uletter_count loop  -- for each upper case letter
            for lcv2 in 1 .. length(user_password) loop -- for each letter in the password
                if (substr(user_password, lcv2, 1) = my_uletters(lcv1)) then
                    -- if this upper case letter matches this character in the password
                    upper_found := true;    -- flag the ccondition as having been met
                end if;
            end loop;
        end loop;

        for lcv1 in 1 .. my_lletter_count loop  -- for each lower case letter
            for lcv2 in 1 .. length(user_password) loop -- for each letter in the password
                if (substr(user_password, lcv2, 1) = my_lletters(lcv1)) then
                    -- if this lower case letter matches this character in the password
                    lower_found := true;    -- flag the ccondition as having been met
                end if;
            end loop;
        end loop;

        if upper_found and lower_found then
            return true;
        else
            return false;
        end if;

    end test_for_upper_and_lower;

    procedure check_length 
        (user_password  in  varchar)
    is

        -- this routine checks whether passsword length is accceptable; i.e. GE 8
        -- if not score zero and post an issue to the my_issues table
        -- if acceptable then score 15 plus one for each additional character length
        password_length integer;

    begin
        -- determine the length of the potential password
        select length(user_password) into password_length from dual;

        -- score that length
        if password_length < 8 then
            -- password is too short
            my_issue_count := my_issue_count + 1;
            my_issues(my_issue_count) := 'Password is too short.';
        else
            password_score := password_score + 15 + length(user_password) - 8;
        end if;
    end;

    procedure populate_arrays is
    begin

        -- keyboard symbols are ASCII 33 through 47 and 91 through 95 and 123 through 126
        for lcv in 33 .. 47 loop
            my_symbol_count := my_symbol_count + 1;
            my_symbols(my_symbol_count) := chr(lcv); 
        end loop;
        for lcv in 91 .. 95 loop
            my_symbol_count := my_symbol_count + 1;
            my_symbols(my_symbol_count) := chr(lcv); 
        end loop;
        for lcv in 123 .. 126 loop
            my_symbol_count := my_symbol_count + 1;
            my_symbols(my_symbol_count) := chr(lcv); 
        end loop;

        -- upper case letters are ASCII 65 through 90
        for lcv in 65 .. 90 loop
            my_uletter_count := lcv - 64;
            my_uletters(my_uletter_count) := chr(lcv);
        end loop;

        -- lower case letters are ASCII 97 through 122
        for lcv in 97 .. 122 loop
            my_lletter_count := my_lletter_count + 1;
            my_lletters(my_lletter_count) := chr(lcv);
        end loop;

        -- digits are ASCII values 48 through 57
        for lcv in 48 .. 57 loop
            my_digits_count := my_digits_count + 1;
            my_digits(my_digits_count) := chr(lcv);
        end loop;

    end populate_arrays;

begin
    populate_arrays;
    check_length(user_password);

    -- if both upper and lower case characters exist add 25 to the running total
    if test_for_upper_and_lower(user_password) then
        password_score := password_score + 25;
    else
        my_issue_count := my_issue_count + 1;
        my_issues(my_issue_count) := 'Missing both lower and upper case chars';
    end if;

    -- if both characters and digits exist add 25 to running total
    if test_for_char_and_digit(user_password) then
        password_score := password_score + 25;
    else
        my_issue_count := my_issue_count + 1;
        my_issues(my_issue_count) := 'Missing both char and digit combination.';
    end if;    
end;

-- add in the check for at least one symbol
create or replace function calc_password_strength
    (user_password  in      varchar default 'nogood')
    return          integer     -- 0 through 100 inclusive wwith 100 max strength
    as
    
    type my_array is table of char(1) index by binary_integer;
    my_symbols      my_array;
    my_uletters     my_array;
    my_lletters     my_array;
    my_digits       my_array;

    my_symbol_count     integer := 0;
    my_uletter_count    integer := 0;
    my_lletter_count    integer := 0;
    my_digits_count     integer := 0;

    -- how do we get this information back to the front-end calling routine
    -- functions can have out parms but it is not good practice because then they can not
    -- be used in select statements so I would normally store to a table or XML file
    type my_issues_table is table of varchar(200) index by binary_integer;
    my_issues           my_issues_table;
    my_issue_count      integer := 0;

    password_score      integer := 0;

    function test_for_symbol
        (user_password in   varchar)
        return boolean
        is
        
        symbol_found    boolean := false;
        
    begin
    
            for lcv1 in 1 .. my_symbol_count loop
                for lcv2 in 1 .. length(user_password) loop
                    if substr(user_password, lcv2, 1) = my_symbols(lcv1) then
                        symbol_found := true;
                    end if;
                end loop;
            end loop;

            -- we really don't need that if here we can just return our boolean var
            return symbol_found;
            
    end test_for_symbol;

    function test_for_char_and_digit
        (user_password in   varchar)
        return boolean
        is
        
        char_found      boolean := false;
        digit_found     boolean := false;
    begin
    
        for lcv1 in 1 .. my_uletter_count loop
            for lcv2 in 1 .. length(user_password) loop
                if (substr(user_password, lcv2, 1) = my_uletters(lcv1)) or
                    (substr(user_password, lcv2, 1) = my_lletters(lcv1)) then
                    char_found := true;
                end if;
            end loop;
        end loop;

        for lcv1 in 1 .. my_digits_count loop
            for lcv2 in 1 .. length(user_password) loop
                if substr(user_password, lcv2, 1) = my_digits(lcv1) then
                    digit_found := true;
                end if;
            end loop;
        end loop;
        
        if digit_found and char_found then
            return true;
        else
            return false;
        end if;
        
    end test_for_char_and_digit;
    
    function test_for_upper_and_lower
        (user_password  in  varchar)
        return boolean
        is

        upper_found     boolean := false;
        lower_found     boolean := false;

    begin

        for lcv1 in 1 .. my_uletter_count loop  -- for each upper case letter
            for lcv2 in 1 .. length(user_password) loop -- for each letter in the password
                if (substr(user_password, lcv2, 1) = my_uletters(lcv1)) then
                    -- if this upper case letter matches this character in the password
                    upper_found := true;    -- flag the ccondition as having been met
                end if;
            end loop;
        end loop;

        for lcv1 in 1 .. my_lletter_count loop  -- for each lower case letter
            for lcv2 in 1 .. length(user_password) loop -- for each letter in the password
                if (substr(user_password, lcv2, 1) = my_lletters(lcv1)) then
                    -- if this lower case letter matches this character in the password
                    lower_found := true;    -- flag the ccondition as having been met
                end if;
            end loop;
        end loop;

        if upper_found and lower_found then
            return true;
        else
            return false;
        end if;

    end test_for_upper_and_lower;

    procedure check_length 
        (user_password  in  varchar)
    is

        -- this routine checks whether passsword length is accceptable; i.e. GE 8
        -- if not score zero and post an issue to the my_issues table
        -- if acceptable then score 15 plus one for each additional character length
        password_length integer;

    begin
        -- determine the length of the potential password
        select length(user_password) into password_length from dual;

        -- score that length
        if password_length < 8 then
            -- password is too short
            my_issue_count := my_issue_count + 1;
            my_issues(my_issue_count) := 'Password is too short.';
        else
            password_score := password_score + 15 + length(user_password) - 8;
        end if;
    end;

    procedure populate_arrays is
    begin

        -- keyboard symbols are ASCII 33 through 47 and 91 through 95 and 123 through 126
        for lcv in 33 .. 47 loop
            my_symbol_count := my_symbol_count + 1;
            my_symbols(my_symbol_count) := chr(lcv); 
        end loop;
        for lcv in 91 .. 95 loop
            my_symbol_count := my_symbol_count + 1;
            my_symbols(my_symbol_count) := chr(lcv); 
        end loop;
        for lcv in 123 .. 126 loop
            my_symbol_count := my_symbol_count + 1;
            my_symbols(my_symbol_count) := chr(lcv); 
        end loop;

        -- upper case letters are ASCII 65 through 90
        for lcv in 65 .. 90 loop
            my_uletter_count := lcv - 64;
            my_uletters(my_uletter_count) := chr(lcv);
        end loop;

        -- lower case letters are ASCII 97 through 122
        for lcv in 97 .. 122 loop
            my_lletter_count := my_lletter_count + 1;
            my_lletters(my_lletter_count) := chr(lcv);
        end loop;

        -- digits are ASCII values 48 through 57
        for lcv in 48 .. 57 loop
            my_digits_count := my_digits_count + 1;
            my_digits(my_digits_count) := chr(lcv);
        end loop;

    end populate_arrays;

begin
    populate_arrays;
    
    -- length check is worth 15 + 1 for each char beyond 8
    check_length(user_password);

    -- if both upper and lower case characters exist add 25 to the running total
    if test_for_upper_and_lower(user_password) then
        password_score := password_score + 20;
    else
        my_issue_count := my_issue_count + 1;
        my_issues(my_issue_count) := 'Missing both lower and upper case chars';
    end if;

    -- if both characters and digits exist add 25 to running total
    if test_for_char_and_digit(user_password) then
        password_score := password_score + 25;
    else
        my_issue_count := my_issue_count + 1;
        my_issues(my_issue_count) := 'Missing both char and digit combination.';
    end if;   
    
    -- if we have at least one embedded symbol add 25
    if test_for_symbol(user_password) then
        password_score := password_score + 25;
    else
        my_issue_count := my_issue_count + 1;
        my_issues(my_issue_count) := 'Missing at least one symbol.';
    end if;   
    
    return password_score;
end;

-- check for those problematic symbols > and <
create or replace function calc_password_strength
    (user_password  in      varchar default 'nogood')
    return          integer     -- 0 through 100 inclusive wwith 100 max strength
    as
    
    type my_array is table of char(1) index by binary_integer;
    my_symbols      my_array;
    my_uletters     my_array;
    my_lletters     my_array;
    my_digits       my_array;

    my_symbol_count     integer := 0;
    my_uletter_count    integer := 0;
    my_lletter_count    integer := 0;
    my_digits_count     integer := 0;

    -- how do we get this information back to the front-end calling routine
    -- functions can have out parms but it is not good practice because then they can not
    -- be used in select statements so I would normally store to a table or XML file
    type my_issues_table is table of varchar(200) index by binary_integer;
    my_issues           my_issues_table;
    my_issue_count      integer := 0;

    password_score      integer := 0;


    function test_for_gt_or_lt
        (user_password in   varchar)
        return boolean
        is
        
        found_one   boolean := false;
    begin
    
        for lcv in 1.. length(user_password) loop
            if substr(user_password, lcv, 1) = chr(60) or  -- ASCII <
               substr(user_password, lcv, 1) = chr(62) then  -- ASCII >
                found_one := true;
            end if;
        end loop;
        
        return found_one;
        
    end test_for_gt_or_lt;

    function test_for_symbol
        (user_password in   varchar)
        return boolean
        is
        
        symbol_found    boolean := false;
        
    begin
    
            for lcv1 in 1 .. my_symbol_count loop
                for lcv2 in 1 .. length(user_password) loop
                    if substr(user_password, lcv2, 1) = my_symbols(lcv1) then
                        symbol_found := true;
                    end if;
                end loop;
            end loop;

            -- we really don't need that if here we can just return our boolean var
            return symbol_found;
            
    end test_for_symbol;

    function test_for_char_and_digit
        (user_password in   varchar)
        return boolean
        is
        
        char_found      boolean := false;
        digit_found     boolean := false;
    begin
    
        for lcv1 in 1 .. my_uletter_count loop
            for lcv2 in 1 .. length(user_password) loop
                if (substr(user_password, lcv2, 1) = my_uletters(lcv1)) or
                    (substr(user_password, lcv2, 1) = my_lletters(lcv1)) then
                    char_found := true;
                end if;
            end loop;
        end loop;

        for lcv1 in 1 .. my_digits_count loop
            for lcv2 in 1 .. length(user_password) loop
                if substr(user_password, lcv2, 1) = my_digits(lcv1) then
                    digit_found := true;
                end if;
            end loop;
        end loop;
        
        if digit_found and char_found then
            return true;
        else
            return false;
        end if;
        
    end test_for_char_and_digit;
    
    function test_for_upper_and_lower
        (user_password  in  varchar)
        return boolean
        is

        upper_found     boolean := false;
        lower_found     boolean := false;

    begin

        for lcv1 in 1 .. my_uletter_count loop  -- for each upper case letter
            for lcv2 in 1 .. length(user_password) loop -- for each letter in the password
                if (substr(user_password, lcv2, 1) = my_uletters(lcv1)) then
                    -- if this upper case letter matches this character in the password
                    upper_found := true;    -- flag the ccondition as having been met
                end if;
            end loop;
        end loop;

        for lcv1 in 1 .. my_lletter_count loop  -- for each lower case letter
            for lcv2 in 1 .. length(user_password) loop -- for each letter in the password
                if (substr(user_password, lcv2, 1) = my_lletters(lcv1)) then
                    -- if this lower case letter matches this character in the password
                    lower_found := true;    -- flag the ccondition as having been met
                end if;
            end loop;
        end loop;

        if upper_found and lower_found then
            return true;
        else
            return false;
        end if;

    end test_for_upper_and_lower;

    procedure check_length 
        (user_password  in  varchar)
    is

        -- this routine checks whether passsword length is accceptable; i.e. GE 8
        -- if not score zero and post an issue to the my_issues table
        -- if acceptable then score 15 plus one for each additional character length
        password_length integer;

    begin
        -- determine the length of the potential password
        select length(user_password) into password_length from dual;

        -- score that length
        if password_length < 8 then
            -- password is too short
            my_issue_count := my_issue_count + 1;
            my_issues(my_issue_count) := 'Password is too short.';
        else
            password_score := password_score + 15 + length(user_password) - 8;
        end if;
    end;

    procedure populate_arrays is
    begin

        -- keyboard symbols are ASCII 33 through 47 and 91 through 95 and 123 through 126
        for lcv in 33 .. 47 loop
            my_symbol_count := my_symbol_count + 1;
            my_symbols(my_symbol_count) := chr(lcv); 
        end loop;
        for lcv in 91 .. 95 loop
            my_symbol_count := my_symbol_count + 1;
            my_symbols(my_symbol_count) := chr(lcv); 
        end loop;
        for lcv in 123 .. 126 loop
            my_symbol_count := my_symbol_count + 1;
            my_symbols(my_symbol_count) := chr(lcv); 
        end loop;

        -- upper case letters are ASCII 65 through 90
        for lcv in 65 .. 90 loop
            my_uletter_count := lcv - 64;
            my_uletters(my_uletter_count) := chr(lcv);
        end loop;

        -- lower case letters are ASCII 97 through 122
        for lcv in 97 .. 122 loop
            my_lletter_count := my_lletter_count + 1;
            my_lletters(my_lletter_count) := chr(lcv);
        end loop;

        -- digits are ASCII values 48 through 57
        for lcv in 48 .. 57 loop
            my_digits_count := my_digits_count + 1;
            my_digits(my_digits_count) := chr(lcv);
        end loop;

    end populate_arrays;

begin
    populate_arrays;
    
    -- length check is worth 25 + 1 for each char beyond 8
    check_length(user_password);

    -- if both upper and lower case characters exist add 25 to the running total
    if test_for_upper_and_lower(user_password) then
        password_score := password_score + 20;
    else
        my_issue_count := my_issue_count + 1;
        my_issues(my_issue_count) := 'Missing both lower and upper case chars';
    end if;

    -- if both characters and digits exist add 25 to running total
    if test_for_char_and_digit(user_password) then
        password_score := password_score + 25;
    else
        my_issue_count := my_issue_count + 1;
        my_issues(my_issue_count) := 'Missing both char and digit combination.';
    end if;   
    
    -- if we have at least one embedded symbol add 25
    if test_for_symbol(user_password) then
        password_score := password_score + 25;
    else
        my_issue_count := my_issue_count + 1;
        my_issues(my_issue_count) := 'Missing at least one symbol.';
    end if;   
    
        -- if we have included either < or > set issue 
    if test_for_gt_or_lt(user_password) then
        password_score := 0;
        my_issue_count := my_issue_count + 1;
        my_issues(my_issue_count) := 'Illegal use of < or > symbol.';
    end if;
    
    if password_score < 0 then -- don't think can happen but we will play it safe
        password_score := 0;
    elsif password_score > 100 then
        password_score := 100;  -- this can definitely happend
    end if;

    return password_score;
end;

-- oops fix the bug in the body of the code
-- check for those problematic symbols > and <
create or replace function calc_password_strength
    (user_password  in      varchar default 'nogood')
    return          integer     -- 0 through 100 inclusive wwith 100 max strength
    as
    
    type my_array is table of char(1) index by binary_integer;
    my_symbols      my_array;
    my_uletters     my_array;
    my_lletters     my_array;
    my_digits       my_array;

    my_symbol_count     integer := 0;
    my_uletter_count    integer := 0;
    my_lletter_count    integer := 0;
    my_digits_count     integer := 0;

    -- how do we get this information back to the front-end calling routine
    -- functions can have out parms but it is not good practice because then they can not
    -- be used in select statements so I would normally store to a table or XML file
    type my_issues_table is table of varchar(200) index by binary_integer;
    my_issues           my_issues_table;
    my_issue_count      integer := 0;

    password_score      integer := 0;


    function test_for_gt_or_lt
        (user_password in   varchar)
        return boolean
        is
        
        found_one   boolean := false;
    begin
    
        for lcv in 1.. length(user_password) loop
            if substr(user_password, lcv, 1) = chr(60) or  -- ASCII <
               substr(user_password, lcv, 1) = chr(62) then  -- ASCII >
                found_one := true;
            end if;
        end loop;
        
        return found_one;
        
    end test_for_gt_or_lt;

    function test_for_symbol
        (user_password in   varchar)
        return boolean
        is
        
        symbol_found    boolean := false;
        
    begin
    
            for lcv1 in 1 .. my_symbol_count loop
                for lcv2 in 1 .. length(user_password) loop
                    if substr(user_password, lcv2, 1) = my_symbols(lcv1) then
                        symbol_found := true;
                    end if;
                end loop;
            end loop;

            -- we really don't need that if here we can just return our boolean var
            return symbol_found;
            
    end test_for_symbol;

    function test_for_char_and_digit
        (user_password in   varchar)
        return boolean
        is
        
        char_found      boolean := false;
        digit_found     boolean := false;
    begin
    
        for lcv1 in 1 .. my_uletter_count loop
            for lcv2 in 1 .. length(user_password) loop
                if (substr(user_password, lcv2, 1) = my_uletters(lcv1)) or
                    (substr(user_password, lcv2, 1) = my_lletters(lcv1)) then
                    char_found := true;
                end if;
            end loop;
        end loop;

        for lcv1 in 1 .. my_digits_count loop
            for lcv2 in 1 .. length(user_password) loop
                if substr(user_password, lcv2, 1) = my_digits(lcv1) then
                    digit_found := true;
                end if;
            end loop;
        end loop;
        
        if digit_found and char_found then
            return true;
        else
            return false;
        end if;
        
    end test_for_char_and_digit;
    
    function test_for_upper_and_lower
        (user_password  in  varchar)
        return boolean
        is

        upper_found     boolean := false;
        lower_found     boolean := false;

    begin

        for lcv1 in 1 .. my_uletter_count loop  -- for each upper case letter
            for lcv2 in 1 .. length(user_password) loop -- for each letter in the password
                if (substr(user_password, lcv2, 1) = my_uletters(lcv1)) then
                    -- if this upper case letter matches this character in the password
                    upper_found := true;    -- flag the ccondition as having been met
                end if;
            end loop;
        end loop;

        for lcv1 in 1 .. my_lletter_count loop  -- for each lower case letter
            for lcv2 in 1 .. length(user_password) loop -- for each letter in the password
                if (substr(user_password, lcv2, 1) = my_lletters(lcv1)) then
                    -- if this lower case letter matches this character in the password
                    lower_found := true;    -- flag the ccondition as having been met
                end if;
            end loop;
        end loop;

        if upper_found and lower_found then
            return true;
        else
            return false;
        end if;

    end test_for_upper_and_lower;

    procedure check_length 
        (user_password  in  varchar)
    is

        -- this routine checks whether passsword length is accceptable; i.e. GE 8
        -- if not score zero and post an issue to the my_issues table
        -- if acceptable then score 15 plus one for each additional character length
        password_length integer;

    begin
        -- determine the length of the potential password
        select length(user_password) into password_length from dual;

        -- score that length
        if password_length < 8 then
            -- password is too short
            my_issue_count := my_issue_count + 1;
            my_issues(my_issue_count) := 'Password is too short.';
        else
            password_score := password_score + 15 + length(user_password) - 8;
        end if;
    end;

    procedure populate_arrays is
    begin

        -- keyboard symbols are ASCII 33 through 47 and 91 through 95 and 123 through 126
        for lcv in 33 .. 47 loop
            my_symbol_count := my_symbol_count + 1;
            my_symbols(my_symbol_count) := chr(lcv); 
        end loop;
        for lcv in 91 .. 95 loop
            my_symbol_count := my_symbol_count + 1;
            my_symbols(my_symbol_count) := chr(lcv); 
        end loop;
        for lcv in 123 .. 126 loop
            my_symbol_count := my_symbol_count + 1;
            my_symbols(my_symbol_count) := chr(lcv); 
        end loop;

        -- upper case letters are ASCII 65 through 90
        for lcv in 65 .. 90 loop
            my_uletter_count := lcv - 64;
            my_uletters(my_uletter_count) := chr(lcv);
        end loop;

        -- lower case letters are ASCII 97 through 122
        for lcv in 97 .. 122 loop
            my_lletter_count := my_lletter_count + 1;
            my_lletters(my_lletter_count) := chr(lcv);
        end loop;

        -- digits are ASCII values 48 through 57
        for lcv in 48 .. 57 loop
            my_digits_count := my_digits_count + 1;
            my_digits(my_digits_count) := chr(lcv);
        end loop;

    end populate_arrays;

begin
    populate_arrays;
    
    -- length check is worth 25 + 1 for each char beyond 8
    check_length(user_password);

    -- if both upper and lower case characters exist add 25 to the running total
    if test_for_upper_and_lower(user_password) then
        password_score := password_score + 25;  -- fix the bug here
    else
        my_issue_count := my_issue_count + 1;
        my_issues(my_issue_count) := 'Missing both lower and upper case chars';
    end if;

    -- if both characters and digits exist add 25 to running total
    if test_for_char_and_digit(user_password) then
        password_score := password_score + 25;
    else
        my_issue_count := my_issue_count + 1;
        my_issues(my_issue_count) := 'Missing both char and digit combination.';
    end if;   
    
    -- if we have at least one embedded symbol add 25
    if test_for_symbol(user_password) then
        password_score := password_score + 25;
    else
        my_issue_count := my_issue_count + 1;
        my_issues(my_issue_count) := 'Missing at least one symbol.';
    end if;   
    
        -- if we have included either < or > set issue 
    if test_for_gt_or_lt(user_password) then
        password_score := 0;
        my_issue_count := my_issue_count + 1;
        my_issues(my_issue_count) := 'Illegal use of < or > symbol.';
    end if;
    
    if password_score < 0 then -- don't think can happen but we will play it safe
        password_score := 0;
    elsif password_score > 100 then
        password_score := 100;  -- this can definitely happend
    end if;

    return password_score;
end;

-- test a password which should pass every test
-- length = 17 pts
-- upper and lower = 25 pts
-- chars and digits = 25 pts
-- at least one symbol = 25 pts
-- no invalid symbols

select calc_password_strength('Abcd4#Lkjh') from dual;

create table temp_issues
(issue_id       int,
 issue          varchar(200),
 constraint pk_temp_issues primary key (issue_id));

